
import ast

import pytest

from aceitacao import (
    TESTES_ACEITACAO,
    obter_testes_aceitacao,
    validar_testes_aceitacao
)
from cenarios import CENARIOS


def test_todos_cenarios_tem_testes():
    ids_cenarios = {
        cenario["id"]
        for cenario in CENARIOS
    }

    assert set(TESTES_ACEITACAO) == ids_cenarios


def test_sintaxe_testes_valida():
    assert validar_testes_aceitacao() is True


def test_cada_cenario_tem_tres_testes():
    for identificador in TESTES_ACEITACAO:
        codigo = obter_testes_aceitacao(identificador)

        arvore = ast.parse(codigo)

        funcoes = [
            no
            for no in arvore.body
            if isinstance(no, ast.FunctionDef)
            and no.name.startswith("test_")
        ]

        assert len(funcoes) >= 3


def test_fatorial_cobre_entrada_negativa():
    codigo = obter_testes_aceitacao("C01")

    assert "fatorial(-1)" in codigo
    assert "pytest.raises(ValueError)" in codigo


def test_media_cobre_lista_vazia():
    codigo = obter_testes_aceitacao("C03")

    assert "calcular_media([])" in codigo


def test_rejeita_cenario_desconhecido():
    with pytest.raises(ValueError):
        obter_testes_aceitacao("C99")
