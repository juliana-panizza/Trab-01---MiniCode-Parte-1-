
from types import SimpleNamespace

import executor_isolado
from pathlib import Path

def test_docker_nao_instalado(monkeypatch):
    monkeypatch.setattr(
        executor_isolado.shutil,
        "which",
        lambda nome: None
    )

    def subprocess_proibido(*args, **kwargs):
        raise AssertionError(
            "Não deveria consultar o Docker."
        )

    monkeypatch.setattr(
        executor_isolado.subprocess,
        "run",
        subprocess_proibido
    )

    resultado = executor_isolado.verificar_docker()

    assert resultado == {
        "available": False,
        "reason": "Docker não encontrado."
    }


def test_docker_instalado_e_acessivel(monkeypatch):
    monkeypatch.setattr(
        executor_isolado.shutil,
        "which",
        lambda nome: "docker"
    )

    def docker_simulado(comando, **kwargs):
        assert comando == [
            "docker",
            "info",
            "--format",
            "{{.ServerVersion}}"
        ]

        return SimpleNamespace(
            returncode=0,
            stdout="28.0.0\n",
            stderr=""
        )

    monkeypatch.setattr(
        executor_isolado.subprocess,
        "run",
        docker_simulado
    )

    resultado = executor_isolado.verificar_docker()

    assert resultado == {
        "available": True,
        "reason": None
    }


def test_docker_instalado_mas_indisponivel(monkeypatch):
    monkeypatch.setattr(
        executor_isolado.shutil,
        "which",
        lambda nome: "docker"
    )

    monkeypatch.setattr(
        executor_isolado.subprocess,
        "run",
        lambda comando, **kwargs: SimpleNamespace(
            returncode=1,
            stdout="",
            stderr="Serviço indisponível."
        )
    )

    resultado = executor_isolado.verificar_docker()

    assert resultado == {
        "available": False,
        "reason": "Docker não está acessível."
    }


import pytest


def test_comando_docker_tem_restricoes(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()
    (projeto / "tests").mkdir()

    comando = (
        executor_isolado.construir_comando_docker(
            projeto
        )
    )

    assert comando[:3] == [
        "docker", "run", "--rm"
    ]

    assert "--network" in comando
    assert comando[
        comando.index("--network") + 1
    ] == "none"

    assert "--memory" in comando
    assert "256m" in comando

    assert "--cpus" in comando
    assert "1" in comando

    assert "--pids-limit" in comando
    assert "64" in comando

    assert "--cap-drop" in comando
    assert "ALL" in comando

    assert "--read-only" in comando
    assert "--user" in comando
    assert "65534:65534" in comando

    assert "--security-opt" in comando
    assert "no-new-privileges" in comando

    assert "--mount" in comando

    montagem = comando[
        comando.index("--mount") + 1
    ]

    assert "target=/app" in montagem
    assert "readonly" in montagem

    assert comando[-7:] == [
        "python",
        "-m",
        "pytest",
        "tests",
        "-q",
        "-p",
        "no:cacheprovider"
    ]


@pytest.mark.parametrize(
    "timeout",
    [0, -1, 121, True, 1.5, "30"]
)
def test_comando_docker_rejeita_timeout(
    tmp_path, timeout
):
    projeto = tmp_path / "projeto"
    projeto.mkdir()
    (projeto / "tests").mkdir()

    with pytest.raises(ValueError):
        executor_isolado.construir_comando_docker(
            projeto,
            timeout=timeout
        )


def test_comando_docker_exige_tests(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    with pytest.raises(
        ValueError,
        match="Pasta tests não encontrada"
    ):
        executor_isolado.construir_comando_docker(
            projeto
        )

def test_dockerfile_instala_pytest():
    raiz = Path(__file__).resolve().parents[1]

    dockerfile = (
        raiz / "sandbox" / "Dockerfile"
    ).read_text(encoding="utf-8")

    requisitos = (
        raiz / "sandbox" / "requirements.txt"
    ).read_text(encoding="utf-8")

    assert "FROM python:3.12-slim" in dockerfile
    assert "COPY requirements.txt" in dockerfile
    assert "pip install" in dockerfile
    assert "pytest==9.0.2" in requisitos


def test_comando_usa_imagem_minicode(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()
    (projeto / "tests").mkdir()

    comando = (
        executor_isolado.construir_comando_docker(
            projeto
        )
    )

    assert "minicode-pytest:local" in comando
    assert "python:3.12-slim" not in comando


def test_preparacao_copia_apenas_python(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    pasta_testes = projeto / "tests"
    pasta_testes.mkdir()

    (projeto / "codigo.py").write_text(
        "def resposta():\n    return 42\n",
        encoding="utf-8"
    )

    (pasta_testes / "test_codigo.py").write_text(
        "def test_resposta():\n    assert True\n",
        encoding="utf-8"
    )

    (projeto / ".env").write_text(
        "MINICODE_API_KEY=segredo",
        encoding="utf-8"
    )

    pasta_interna = projeto / ".minicode"
    pasta_interna.mkdir()

    (pasta_interna / "state.json").write_text(
        '{"state": "DONE"}',
        encoding="utf-8"
    )

    destino = tmp_path / "sandbox_copia"

    resultado = (
        executor_isolado.preparar_arquivos_isolados(
            projeto,
            destino
        )
    )

    assert resultado == destino
    assert (destino / "codigo.py").is_file()
    assert (
        destino / "tests" / "test_codigo.py"
    ).is_file()

    assert not (destino / ".env").exists()
    assert not (destino / ".minicode").exists()


def test_preparacao_rejeita_destino_existente(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    destino = tmp_path / "destino"
    destino.mkdir()

    with pytest.raises(FileExistsError):
        executor_isolado.preparar_arquivos_isolados(
            projeto,
            destino
        )


def test_preparacao_exige_testes_python(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    (projeto / "codigo.py").write_text(
        "x = 1\n",
        encoding="utf-8"
    )

    destino = tmp_path / "destino"

    with pytest.raises(
        ValueError,
        match="Nenhum teste Python"
    ):
        executor_isolado.preparar_arquivos_isolados(
            projeto,
            destino
        )

    assert not destino.exists()


def test_area_temporaria_e_removida(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    pasta_testes = projeto / "tests"
    pasta_testes.mkdir()

    (pasta_testes / "test_exemplo.py").write_text(
        "def test_exemplo():\n"
        "    assert True\n",
        encoding="utf-8"
    )

    with executor_isolado.area_temporaria_isolada(
        projeto
    ) as destino:
        assert destino.exists()
        assert (
            destino / "tests" / "test_exemplo.py"
        ).exists()

    # Ao sair do with, a cópia deve desaparecer.
    assert not destino.exists()


def test_area_temporaria_removida_apos_erro(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    pasta_testes = projeto / "tests"
    pasta_testes.mkdir()

    (pasta_testes / "test_exemplo.py").write_text(
        "def test_exemplo():\n"
        "    assert True\n",
        encoding="utf-8"
    )

    destino_criado = None

    with pytest.raises(
        RuntimeError,
        match="Falha simulada"
    ):
        with executor_isolado.area_temporaria_isolada(
            projeto
        ) as destino:
            destino_criado = destino

            assert destino.exists()

            # Simula um erro durante a avaliação.
            raise RuntimeError("Falha simulada")

    # A exceção ocorreu, mas a pasta foi removida.
    assert destino_criado is not None
    assert not destino_criado.exists()


def test_preparacao_rejeita_link_simbolico(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    pasta_testes = projeto / "tests"
    pasta_testes.mkdir()

    (pasta_testes / "test_exemplo.py").write_text(
        "def test_exemplo():\n"
        "    assert True\n",
        encoding="utf-8"
    )

    # Arquivo localizado fora do projeto.
    arquivo_externo = tmp_path / "segredo.py"
    arquivo_externo.write_text(
        "SEGREDO = 'nao_copiar'\n",
        encoding="utf-8"
    )

    # Cria um link dentro do projeto.
    link = projeto / "externo.py"

    try:
        link.symlink_to(arquivo_externo)
    except (OSError, NotImplementedError):
        pytest.skip(
            "Links simbólicos indisponíveis no Windows."
        )

    destino = tmp_path / "copia"

    with pytest.raises(
        ValueError,
        match="Links simbólicos"
    ):
        executor_isolado.preparar_arquivos_isolados(
            projeto,
            destino
        )

    # Nenhuma cópia deve ser criada.
    assert not destino.exists()


def test_preparacao_exige_tests_na_raiz(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    # Cria uma pasta tests, mas no lugar errado.
    pasta_testes = projeto / "biblioteca" / "tests"
    pasta_testes.mkdir(parents=True)

    (pasta_testes / "test_exemplo.py").write_text(
        "def test_exemplo():\n"
        "    assert True\n",
        encoding="utf-8"
    )

    destino = tmp_path / "copia"

    with pytest.raises(
        ValueError,
        match="Nenhum teste Python encontrado"
    ):
        executor_isolado.preparar_arquivos_isolados(
            projeto,
            destino
        )

    # Não deve criar a cópia.
    assert not destino.exists()


def test_preparacao_rejeita_link_em_diretorio(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    # Pasta de testes válida na raiz.
    pasta_testes = projeto / "tests"
    pasta_testes.mkdir()

    (pasta_testes / "test_exemplo.py").write_text(
        "def test_exemplo():\n"
        "    assert True\n",
        encoding="utf-8"
    )

    # Cria uma pasta externa ao projeto.
    pasta_externa = tmp_path / "pasta_externa"
    pasta_externa.mkdir()

    (pasta_externa / "segredo.py").write_text(
        "SEGREDO = 'nao_copiar'\n",
        encoding="utf-8"
    )

    # Cria um link de diretório dentro do projeto.
    link = projeto / "arquivos_externos"

    try:
        link.symlink_to(
            pasta_externa,
            target_is_directory=True
        )
    except (OSError, NotImplementedError):
        pytest.skip(
            "Links simbólicos de diretórios indisponíveis."
        )

    destino = tmp_path / "copia"

    with pytest.raises(
        ValueError,
        match="Links simbólicos"
    ):
        executor_isolado.preparar_arquivos_isolados(
            projeto,
            destino
        )

    # Não deve copiar nenhum arquivo externo.
    assert not destino.exists()


def test_preparacao_preserva_conteudo_python(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    testes = projeto / "tests"
    testes.mkdir()

    conteudo_codigo = (
        "def resposta():\n"
        "    return 42\n"
    )

    conteudo_teste = (
        "def test_resposta():\n"
        "    assert True\n"
    )

    (projeto / "codigo.py").write_text(
        conteudo_codigo,
        encoding="utf-8"
    )

    (testes / "test_codigo.py").write_text(
        conteudo_teste,
        encoding="utf-8"
    )

    destino = tmp_path / "copia"

    executor_isolado.preparar_arquivos_isolados(
        projeto,
        destino
    )

    assert (
        destino / "codigo.py"
    ).read_text(encoding="utf-8") == conteudo_codigo

    assert (
        destino / "tests" / "test_codigo.py"
    ).read_text(encoding="utf-8") == conteudo_teste
