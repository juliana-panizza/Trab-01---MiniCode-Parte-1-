
from uuid import uuid4

from logger import RegistroEventos
from metricas import calcular_metricas


def test_contagem_chamadas_llm(tmp_path):
    run_id = str(uuid4())

    logger = RegistroEventos(
        tmp_path,
        run_id=run_id
    )

    logger.registrar_chamada_llm("spec", True)
    logger.registrar_chamada_llm("plan", True)
    logger.registrar_chamada_llm("implementation", True)
    logger.registrar_chamada_llm("repair", False)

    metricas = calcular_metricas(
        tmp_path,
        run_id=run_id
    )

    assert metricas["llm_calls"] == 4
    assert metricas["successful_llm_calls"] == 3
    assert metricas["failed_llm_calls"] == 1

    # Sem verificações, não houve ciclos completos.
    assert metricas["iterations"] == 0


def test_chamadas_llm_separadas_por_run_id(tmp_path):
    run_id_a = str(uuid4())
    run_id_b = str(uuid4())

    logger_a = RegistroEventos(
        tmp_path,
        run_id=run_id_a
    )
    logger_b = RegistroEventos(
        tmp_path,
        run_id=run_id_b
    )

    logger_a.registrar_chamada_llm("spec", True)
    logger_a.registrar_chamada_llm("plan", True)

    logger_b.registrar_chamada_llm("implementation", False)

    metricas_a = calcular_metricas(
        tmp_path,
        run_id=run_id_a
    )

    metricas_b = calcular_metricas(
        tmp_path,
        run_id=run_id_b
    )

    assert metricas_a["llm_calls"] == 2
    assert metricas_a["successful_llm_calls"] == 2
    assert metricas_a["failed_llm_calls"] == 0

    assert metricas_b["llm_calls"] == 1
    assert metricas_b["successful_llm_calls"] == 0
    assert metricas_b["failed_llm_calls"] == 1


def test_chamadas_llm_nao_sao_ferramentas(tmp_path):
    run_id = str(uuid4())

    logger = RegistroEventos(
        tmp_path,
        run_id=run_id
    )

    logger.registrar_chamada_llm("spec", True)
    logger.registrar_chamada_llm("plan", True)

    metricas = calcular_metricas(
        tmp_path,
        run_id=run_id
    )

    assert metricas["llm_calls"] == 2
    assert metricas["tool_calls"] == 0
