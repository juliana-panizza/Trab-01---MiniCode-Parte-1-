
import pytest

from tools import FerramentasProjeto


def test_criar_e_ler_arquivo(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    resultado = ferramentas.write_file(
        "exemplo.py",
        "print('Olá, MiniCode!')"
    )

    assert resultado["success"] is True

    conteudo = ferramentas.read_file("exemplo.py")

    assert conteudo == "print('Olá, MiniCode!')"


def test_listar_arquivos(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    ferramentas.write_file(
        "calculadora.py",
        "def somar(a, b): return a + b"
    )

    arquivos = ferramentas.list_files()

    assert "calculadora.py" in arquivos


def test_bloquear_acesso_fora_do_projeto(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    ferramentas = FerramentasProjeto(projeto)

    with pytest.raises(PermissionError):
        ferramentas.write_file(
            "../arquivo_externo.py",
            "print('não permitido')"
        )


def test_bloquear_diretorio_protegido(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    with pytest.raises(PermissionError):
        ferramentas.write_file(
            ".git/config",
            "conteudo"
        )


def test_arquivo_inexistente(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    with pytest.raises(FileNotFoundError):
        ferramentas.read_file("inexistente.py")



def test_bloquear_arquivo_env(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    with pytest.raises(PermissionError):
        ferramentas.write_file(
            ".env",
            "TOKEN=exemplo"
        )


def test_bloquear_env_local(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    with pytest.raises(PermissionError):
        ferramentas.read_file(".env.local")


def test_bloquear_caminho_absoluto(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    arquivo = tmp_path / "arquivo.py"

    with pytest.raises(PermissionError):
        ferramentas.write_file(
            str(arquivo),
            "print('teste')"
        )


def test_bloquear_chave_privada(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    with pytest.raises(PermissionError):
        ferramentas.write_file(
            "private.pem",
            "conteudo sensivel"
        )




def test_run_tests_bloqueia_teste_valido(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    pasta_testes = projeto / "tests"
    pasta_testes.mkdir()

    (pasta_testes / "test_exemplo.py").write_text(
        "def test_soma():\n"
        "    assert 2 + 2 == 4\n",
        encoding="utf-8"
    )

    ferramentas = FerramentasProjeto(projeto)
    resultado = ferramentas.run_tests()

    assert resultado == {
        "executed": False,
        "passed": False,
        "exit_code": None,
        "output": (
            "Execução bloqueada: ambiente "
            "isolado indisponível."
        )
    }




def test_run_tests_bloqueia_teste_incorreto(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    pasta_testes = projeto / "tests"
    pasta_testes.mkdir()

    (pasta_testes / "test_exemplo.py").write_text(
        "def test_soma():\n"
        "    assert 2 + 2 == 5\n",
        encoding="utf-8"
    )

    ferramentas = FerramentasProjeto(projeto)
    resultado = ferramentas.run_tests()

    assert resultado == {
        "executed": False,
        "passed": False,
        "exit_code": None,
        "output": (
            "Execução bloqueada: ambiente "
            "isolado indisponível."
        )
    }



def test_run_tests_sem_pasta_tests(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    resultado = ferramentas.run_tests()

    assert resultado["executed"] is False
    assert resultado["passed"] is False
