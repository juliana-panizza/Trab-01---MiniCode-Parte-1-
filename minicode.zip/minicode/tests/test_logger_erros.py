
import json
from uuid import uuid4

import pytest

from logger import RegistroEventos


def ler_eventos(projeto):
    arquivo = projeto / ".minicode" / "events.jsonl"

    if not arquivo.exists():
        return []

    return [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]


def test_registrar_erro_permissao(tmp_path):
    run_id = str(uuid4())

    logger = RegistroEventos(
        tmp_path,
        run_id=run_id
    )

    logger.registrar_erro(
        "implementation",
        PermissionError("Caminho secreto proibido")
    )

    eventos = ler_eventos(tmp_path)

    assert len(eventos) == 1

    evento = eventos[0]

    assert evento["type"] == "execution_error"
    assert evento["run_id"] == run_id
    assert evento["data"] == {
        "stage": "implementation",
        "error_type": "PermissionError"
    }

    # A mensagem da exceção não pode aparecer no log.
    conteudo_log = (
        tmp_path / ".minicode" / "events.jsonl"
    ).read_text(encoding="utf-8")

    assert "Caminho secreto proibido" not in conteudo_log


def test_registrar_erro_timeout(tmp_path):
    logger = RegistroEventos(tmp_path)

    logger.registrar_erro(
        "verification",
        TimeoutError("Tempo esgotado")
    )

    eventos = ler_eventos(tmp_path)

    assert eventos[0]["data"] == {
        "stage": "verification",
        "error_type": "TimeoutError"
    }


def test_registrar_erro_desconhecido(tmp_path):
    class ErroPersonalizado(Exception):
        pass

    logger = RegistroEventos(tmp_path)

    logger.registrar_erro(
        "repair",
        ErroPersonalizado("Informação sensível")
    )

    eventos = ler_eventos(tmp_path)

    assert eventos[0]["data"]["error_type"] == "OtherError"

    texto = (
        tmp_path / ".minicode" / "events.jsonl"
    ).read_text(encoding="utf-8")

    assert "Informação sensível" not in texto
    assert "ErroPersonalizado" not in texto


@pytest.mark.parametrize(
    "etapa",
    ["", "unknown", None, 123]
)
def test_rejeitar_etapa_invalida(tmp_path, etapa):
    logger = RegistroEventos(tmp_path)

    with pytest.raises(ValueError):
        logger.registrar_erro(
            etapa,
            RuntimeError("Erro")
        )

    assert ler_eventos(tmp_path) == []


def test_rejeitar_objeto_sem_excecao(tmp_path):
    logger = RegistroEventos(tmp_path)

    with pytest.raises(TypeError):
        logger.registrar_erro(
            "implementation",
            "Isso não é uma exceção"
        )

    assert ler_eventos(tmp_path) == []
