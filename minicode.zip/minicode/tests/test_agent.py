
import json

import pytest

from agent import MiniCodeAgent
from states import Estado
from executor import Executor


@pytest.fixture
def spec_exemplo():
    return {
        "objective": "Criar uma função de fatorial",
        "requirements": [
            "Receber um inteiro não negativo"
        ],
        "acceptance_criteria": [
            "fatorial(0) deve retornar 1"
        ]
    }


@pytest.fixture
def plan_exemplo():
    return {
        "summary": "Implementar o fatorial",
        "steps": [
            {
                "step": 1,
                "description": "Criar a função",
                "files": ["calculadora.py"]
            }
        ],
        "tests": [
            "Testar fatorial(0)"
        ]
    }


def test_preparar_com_sucesso(
    tmp_path, monkeypatch, spec_exemplo, plan_exemplo
):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    (projeto / "calculadora.py").write_text(
        "# arquivo de teste",
        encoding="utf-8"
    )

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec_exemplo
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan_exemplo
    )

    agente = MiniCodeAgent(projeto)
    resultado = agente.preparar("Crie um fatorial")

    assert resultado["status"] == "prepared"
    assert resultado["state"] == "PLANNED"
    assert agente.maquina.estado == Estado.PLANNED

    assert (
        projeto / ".minicode" / "specification.md"
    ).exists()

    assert (
        projeto / ".minicode" / "plan.md"
    ).exists()

    estado_salvo = json.loads(
        (projeto / ".minicode" / "state.json").read_text(
            encoding="utf-8"
        )
    )

    assert estado_salvo["state"] == "PLANNED"
    assert estado_salvo["spec_valid"] is True
    assert estado_salvo["plan_valid"] is True
    assert estado_salvo["tests_executed"] is False


def test_falha_na_spec(tmp_path, monkeypatch):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    def gerar_spec_com_erro(tarefa):
        raise ValueError("SPEC inválida")

    monkeypatch.setattr(
        "agent.gerar_spec",
        gerar_spec_com_erro
    )

    agente = MiniCodeAgent(projeto)

    with pytest.raises(ValueError):
        agente.preparar("Tarefa de teste")

    assert agente.maquina.estado == Estado.FAILED

    estado_salvo = json.loads(
        (projeto / ".minicode" / "state.json").read_text(
            encoding="utf-8"
        )
    )

    assert estado_salvo["state"] == "FAILED"
    assert estado_salvo["spec_valid"] is False


def test_falha_no_plan(
    tmp_path, monkeypatch, spec_exemplo
):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec_exemplo
    )

    def gerar_plan_com_erro(spec, arquivos):
        raise ValueError("PLAN inválido")

    monkeypatch.setattr(
        "agent.gerar_plan",
        gerar_plan_com_erro
    )

    agente = MiniCodeAgent(projeto)

    with pytest.raises(ValueError):
        agente.preparar("Tarefa de teste")

    assert agente.maquina.estado == Estado.FAILED
    assert agente.maquina.spec_valida is True
    assert agente.maquina.plan_valido is False


def test_nao_preparar_duas_vezes(
    tmp_path, monkeypatch, spec_exemplo, plan_exemplo
):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec_exemplo
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan_exemplo
    )

    agente = MiniCodeAgent(projeto)

    agente.preparar("Primeira tarefa")

    with pytest.raises(RuntimeError):
        agente.preparar("Segunda tarefa")

    assert agente.maquina.estado == Estado.PLANNED


def test_listar_arquivos_ignora_metadados(tmp_path):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    (projeto / "codigo.py").write_text(
        "print('teste')",
        encoding="utf-8"
    )

    pasta_git = projeto / ".git"
    pasta_git.mkdir()

    (pasta_git / "config").write_text(
        "configuracao",
        encoding="utf-8"
    )

    agente = MiniCodeAgent(projeto)

    arquivos = agente.listar_arquivos()

    assert "codigo.py" in arquivos
    assert ".git/config" not in arquivos


def test_integracao_implementacao(
    tmp_path, monkeypatch, spec_exemplo, plan_exemplo
):
    from agent import MiniCodeAgent

    projeto = tmp_path / "projeto"
    projeto.mkdir()

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec_exemplo
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan_exemplo
    )

    agente = MiniCodeAgent(projeto)
    agente.preparar("Criar função de fatorial")

    def implementar_simulado(
        executor, spec, plan, max_passos=8
    ):
        resultado = executor.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": "calculadora.py",
                "conteudo": (
                    "def fatorial(n):\n"
                    "    if n == 0:\n"
                    "        return 1\n"
                    "    resultado = 1\n"
                    "    for i in range(1, n + 1):\n"
                    "        resultado *= i\n"
                    "    return resultado\n"
                )
            }
        })

        return {
            "finished": True,
            "summary": "Função implementada.",
            "actions": [resultado],
            "writes": 1
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    resultado = agente.executar_implementacao()

    assert resultado["finished"] is True
    assert agente.maquina.estado == Estado.IMPLEMENTING

    arquivo = projeto / "calculadora.py"

    assert arquivo.exists()
    assert "def fatorial" in arquivo.read_text(
        encoding="utf-8"
    )

    estado_salvo = json.loads(
        (projeto / ".minicode" / "state.json").read_text(
            encoding="utf-8"
        )
    )

    assert estado_salvo["state"] == "IMPLEMENTING"
    assert estado_salvo["tests_executed"] is False



def test_impedir_implementacao_sem_plan(tmp_path):
    from agent import MiniCodeAgent

    agente = MiniCodeAgent(tmp_path)

    with pytest.raises(RuntimeError):
        agente.executar_implementacao()

    assert agente.maquina.estado == Estado.RECEIVED
    assert not (tmp_path / "calculadora.py").exists()


def test_verificacao_integrada_aprovada(
    tmp_path, monkeypatch
):
    agente = MiniCodeAgent(tmp_path)

    agente.maquina.registrar_spec({
        "objective": "Criar função",
        "requirements": ["Implementar função"],
        "acceptance_criteria": ["Passar nos testes"]
    })

    agente.maquina.registrar_plan({
        "summary": "Criar função",
        "steps": [{
            "step": 1,
            "description": "Implementar função",
            "files": ["codigo.py"]
        }],
        "tests": ["Executar pytest"]
    })

    agente.maquina.transicionar(Estado.IMPLEMENTING)

    def verificar_simulado(diretorio, maquina):
        maquina.registrar_testes(
            executados=True,
            aprovados=True
        )

        return {
            "executed": True,
            "passed": True,
            "exit_code": 0,
            "output": "2 passed"
        }

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    resultado = agente.executar_verificacao()

    assert resultado["status"] == "DONE"
    assert agente.maquina.estado == Estado.DONE
    assert agente.maquina.testes_aprovados is True


def test_verificacao_integrada_reprovada(
    tmp_path, monkeypatch
):
    agente = MiniCodeAgent(tmp_path)

    agente.maquina.registrar_spec({
        "objective": "Criar função",
        "requirements": ["Implementar função"],
        "acceptance_criteria": ["Passar nos testes"]
    })

    agente.maquina.registrar_plan({
        "summary": "Criar função",
        "steps": [{
            "step": 1,
            "description": "Implementar função",
            "files": ["codigo.py"]
        }],
        "tests": ["Executar pytest"]
    })

    agente.maquina.transicionar(Estado.IMPLEMENTING)

    def verificar_simulado(diretorio, maquina):
        maquina.registrar_testes(
            executados=True,
            aprovados=False
        )

        return {
            "executed": True,
            "passed": False,
            "exit_code": 1,
            "output": "1 failed"
        }

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    resultado = agente.executar_verificacao()

    assert resultado["status"] == "REPAIRING"
    assert agente.maquina.estado == Estado.REPAIRING
    assert agente.maquina.testes_aprovados is False
    # A verificação falhou, mas nenhum reparo começou.
    assert agente.maquina.tentativas_reparo == 0



def test_verificacao_sem_testes_executados(
    tmp_path, monkeypatch
):
    agente = MiniCodeAgent(tmp_path)

    agente.maquina.registrar_spec({
        "objective": "Criar função",
        "requirements": ["Implementar função"],
        "acceptance_criteria": ["Passar nos testes"]
    })

    agente.maquina.registrar_plan({
        "summary": "Criar função",
        "steps": [{
            "step": 1,
            "description": "Implementar função",
            "files": ["codigo.py"]
        }],
        "tests": ["Executar pytest"]
    })

    agente.maquina.transicionar(Estado.IMPLEMENTING)

    def verificar_simulado(diretorio, maquina):
        maquina.registrar_testes(
            executados=False,
            aprovados=False
        )

        return {
            "executed": False,
            "passed": False,
            "exit_code": None,
            "output": "Nenhum teste executado"
        }

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    resultado = agente.executar_verificacao()

    assert resultado["status"] == "FAILED"
    assert agente.maquina.estado == Estado.FAILED
    assert agente.maquina.testes_executados is False


def criar_agente_em_reparo(tmp_path):
    agente = MiniCodeAgent(tmp_path)

    agente.spec = {
        "objective": "Corrigir função",
        "requirements": ["Retornar 42"],
        "acceptance_criteria": [
            "O teste deve passar"
        ]
    }

    agente.plan = {
        "summary": "Corrigir codigo.py",
        "steps": [{
            "step": 1,
            "description": "Corrigir função",
            "files": ["codigo.py"]
        }],
        "tests": ["Executar pytest"]
    }

    agente.maquina.registrar_spec(agente.spec)
    agente.maquina.registrar_plan(agente.plan)

    agente.maquina.transicionar(Estado.IMPLEMENTING)
    agente.maquina.transicionar(Estado.VERIFYING)

    agente.maquina.registrar_testes(
        executados=True,
        aprovados=False
    )

    agente.maquina.transicionar(Estado.REPAIRING)

    return agente


def test_reparo_integrado_aprovado(
    tmp_path, monkeypatch
):
    agente = criar_agente_em_reparo(tmp_path)

    feedback = {
        "executed": True,
        "passed": False,
        "exit_code": 1,
        "output": "AssertionError: esperado 42"
    }

    def implementar_simulado(
        executor, spec, plan,
        max_passos=8, feedback_testes=None
    ):
        assert feedback_testes == feedback

        executor.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": "codigo.py",
                "conteudo": (
                    "def resposta():\n"
                    "    return 42\n"
                )
            }
        })

        return {
            "finished": True,
            "summary": "Função corrigida.",
            "actions": [],
            "writes": 1
        }

    def verificar_simulado(diretorio, maquina):
        maquina.registrar_testes(
            executados=True,
            aprovados=True
        )

        return {
            "executed": True,
            "passed": True,
            "exit_code": 0,
            "output": "1 passed"
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    resultado = agente.executar_reparo(feedback)

    assert resultado["status"] == "DONE"
    assert agente.maquina.estado == Estado.DONE

    assert (
        tmp_path / "codigo.py"
    ).read_text(encoding="utf-8") == (
        "def resposta():\n"
        "    return 42\n"
    )


def test_reparo_continua_reprovado(
    tmp_path, monkeypatch
):
    agente = criar_agente_em_reparo(tmp_path)

    feedback = {
        "executed": True,
        "passed": False,
        "exit_code": 1,
        "output": "1 failed"
    }

    def implementar_simulado(
        executor, spec, plan,
        max_passos=8, feedback_testes=None
    ):
        return {
            "finished": True,
            "summary": "Correção tentada.",
            "actions": [],
            "writes": 0
        }

    def verificar_simulado(diretorio, maquina):
        maquina.registrar_testes(
            executados=True,
            aprovados=False
        )

        return {
            "executed": True,
            "passed": False,
            "exit_code": 1,
            "output": "1 failed novamente"
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    resultado = agente.executar_reparo(feedback)

    assert resultado["status"] == "REPAIRING"
    assert agente.maquina.estado == Estado.REPAIRING

    assert agente.maquina.testes_aprovados is False
    # Houve uma reparação efetiva, mesmo que
    # a nova verificação tenha reprovado.
    assert agente.maquina.tentativas_reparo == 1


def criar_agente_planejado(tmp_path):
    agente = MiniCodeAgent(tmp_path)

    agente.spec = {
        "objective": "Implementar função resposta",
        "requirements": [
            "A função deve retornar 42"
        ],
        "acceptance_criteria": [
            "Os testes devem passar"
        ]
    }

    agente.plan = {
        "summary": "Implementar codigo.py",
        "steps": [
            {
                "step": 1,
                "description": "Criar função resposta",
                "files": ["codigo.py"]
            }
        ],
        "tests": [
            "Executar testes da função resposta"
        ]
    }

    agente.maquina.registrar_spec(agente.spec)
    agente.maquina.registrar_plan(agente.plan)

    assert agente.maquina.estado == Estado.PLANNED

    return agente


def test_ciclo_sucesso_sem_reparo(
    tmp_path, monkeypatch
):
    agente = criar_agente_planejado(tmp_path)

    chamadas_implementacao = []

    def implementar_simulado(
        executor, spec, plan,
        max_passos=8, feedback_testes=None
    ):
        chamadas_implementacao.append(feedback_testes)

        return {
            "finished": True,
            "summary": "Implementado.",
            "actions": [],
            "writes": 0
        }

    def verificar_simulado(diretorio, maquina):
        maquina.registrar_testes(
            executados=True,
            aprovados=True
        )

        return {
            "executed": True,
            "passed": True,
            "exit_code": 0,
            "output": "1 passed"
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    resultado = agente.executar_ciclo()

    assert resultado["status"] == "DONE"
    assert resultado["repairs"] == 0
    assert agente.maquina.estado == Estado.DONE

    assert len(chamadas_implementacao) == 1
    assert chamadas_implementacao[0] is None


def test_ciclo_reparo_com_sucesso(
    tmp_path, monkeypatch
):
    agente = criar_agente_planejado(tmp_path)

    feedbacks_recebidos = []
    verificacoes = []

    def implementar_simulado(
        executor, spec, plan,
        max_passos=8, feedback_testes=None
    ):
        feedbacks_recebidos.append(feedback_testes)

        return {
            "finished": True,
            "summary": "Implementação concluída.",
            "actions": [],
            "writes": 0
        }

    def verificar_simulado(diretorio, maquina):
        numero = len(verificacoes)
        passou = numero == 1

        resultado = {
            "executed": True,
            "passed": passou,
            "exit_code": 0 if passou else 1,
            "output": (
                "1 passed" if passou else "1 failed"
            )
        }

        verificacoes.append(resultado)

        maquina.registrar_testes(
            executados=True,
            aprovados=passou
        )

        return resultado

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    resultado = agente.executar_ciclo(
        max_reparos=1
    )

    assert resultado["status"] == "DONE"
    assert resultado["repairs"] == 1
    assert agente.maquina.estado == Estado.DONE

    assert len(verificacoes) == 2
    assert len(feedbacks_recebidos) == 2

    assert feedbacks_recebidos[0] is None

    assert feedbacks_recebidos[1]["passed"] is False
    assert "1 failed" in feedbacks_recebidos[1]["output"]


def test_ciclo_atinge_limite_reparos(
    tmp_path, monkeypatch
):
    agente = criar_agente_planejado(tmp_path)

    implementacoes = []
    verificacoes = []

    def implementar_simulado(
        executor, spec, plan,
        max_passos=8, feedback_testes=None
    ):
        implementacoes.append(feedback_testes)

        return {
            "finished": True,
            "summary": "Tentativa concluída.",
            "actions": [],
            "writes": 0
        }

    def verificar_simulado(diretorio, maquina):
        verificacoes.append("falhou")

        maquina.registrar_testes(
            executados=True,
            aprovados=False
        )

        return {
            "executed": True,
            "passed": False,
            "exit_code": 1,
            "output": "1 failed"
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    resultado = agente.executar_ciclo(
        max_reparos=1
    )

    assert resultado["status"] == "FAILED"
    assert resultado["repairs"] == 1
    assert agente.maquina.estado == Estado.FAILED

    # Uma implementação inicial e uma correção.
    assert len(implementacoes) == 2

    # A implementação e a correção foram verificadas.
    assert len(verificacoes) == 2



def test_agente_registra_transicoes(
    tmp_path, monkeypatch
):
    from logger import RegistroEventos
    import json

    agente = criar_agente_planejado(tmp_path)

    def implementar_simulado(
        executor, spec, plan,
        max_passos=8, feedback_testes=None
    ):
        return {
            "finished": True,
            "summary": "Implementado.",
            "actions": [],
            "writes": 0
        }

    def verificar_simulado(diretorio, maquina):
        maquina.registrar_testes(
            executados=True,
            aprovados=True
        )

        return {
            "executed": True,
            "passed": True,
            "exit_code": 0,
            "output": "1 passed"
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    resultado = agente.executar_ciclo()

    assert resultado["status"] == "DONE"

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    assert arquivo.exists()

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    estados = [
        evento["data"]["state"]
        for evento in eventos
        if evento["type"] == "state_transition"
    ]

    assert "IMPLEMENTING" in estados
    assert "VERIFYING" in estados
    assert "DONE" in estados


def test_agente_registra_verificacao(
    tmp_path, monkeypatch
):
    import json

    agente = criar_agente_planejado(tmp_path)

    def implementar_simulado(
        executor, spec, plan,
        max_passos=8, feedback_testes=None
    ):
        return {
            "finished": True,
            "summary": "Implementado.",
            "actions": [],
            "writes": 0
        }

    def verificar_simulado(diretorio, maquina):
        maquina.registrar_testes(
            executados=True,
            aprovados=True
        )

        return {
            "executed": True,
            "passed": True,
            "exit_code": 0,
            "output": "1 passed"
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    agente.executar_ciclo()

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    verificacoes = [
        evento
        for evento in eventos
        if evento["type"] == "verification"
    ]

    assert len(verificacoes) == 1
    assert verificacoes[0]["data"] == {
        "executed": True,
        "passed": True
    }

def test_agentes_tem_run_ids_diferentes(tmp_path):
    from uuid import UUID

    projeto_a = tmp_path / "projeto_a"
    projeto_b = tmp_path / "projeto_b"

    projeto_a.mkdir()
    projeto_b.mkdir()

    agente_a = MiniCodeAgent(projeto_a)
    agente_b = MiniCodeAgent(projeto_b)

    assert agente_a.run_id != agente_b.run_id

    assert str(UUID(agente_a.run_id)) == agente_a.run_id
    assert str(UUID(agente_b.run_id)) == agente_b.run_id

def test_agente_registra_estado_com_run_id(tmp_path):
    import json

    agente = MiniCodeAgent(tmp_path)
    agente.salvar_estado()

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    estados = [
        evento
        for evento in eventos
        if evento["type"] == "state_transition"
    ]

    assert estados
    assert estados[-1]["run_id"] == agente.run_id
    assert estados[-1]["data"]["state"] == "RECEIVED"

def test_metricas_identificam_execucao_do_agente(
    tmp_path
):
    from metricas import calcular_metricas

    agente_a = MiniCodeAgent(tmp_path)
    agente_a.salvar_estado()

    agente_b = MiniCodeAgent(tmp_path)
    agente_b.salvar_estado()

    metricas_a = calcular_metricas(
        tmp_path,
        run_id=agente_a.run_id
    )

    metricas_b = calcular_metricas(
        tmp_path,
        run_id=agente_b.run_id
    )

    assert metricas_a["total_events"] == 1
    assert metricas_b["total_events"] == 1

    assert metricas_a["final_state"] == "RECEIVED"
    assert metricas_b["final_state"] == "RECEIVED"   

    
def test_executor_usa_run_id_do_agente(tmp_path):
    import json

    agente = criar_agente_planejado(tmp_path)

    agente.maquina.transicionar(Estado.IMPLEMENTING)

    executor = Executor(
        tmp_path,
        agente.maquina
    )

    executor.executar_acao({
        "action": "write_file",
        "arguments": {
            "caminho": "codigo.py",
            "conteudo": "x = 42\n"
        }
    })

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    escritas = [
        evento
        for evento in eventos
        if (
            evento["type"] == "tool_execution"
            and evento["data"]["tool"] == "write_file"
        )
    ]

    assert len(escritas) == 1
    assert escritas[0]["run_id"] == agente.run_id
    assert escritas[0]["data"]["success"] is True


def test_verificador_usa_run_id_do_agente(
    tmp_path, monkeypatch
):
    import json

    from verificador import verificar_projeto

    agente = criar_agente_planejado(tmp_path)

    agente.maquina.transicionar(Estado.IMPLEMENTING)
    agente.maquina.transicionar(Estado.VERIFYING)

    def testes_simulados(self):
        return {
            "executed": True,
            "passed": True,
            "exit_code": 0,
            "output": "1 passed"
        }

    monkeypatch.setattr(
        "verificador.FerramentasProjeto.run_tests",
        testes_simulados
    )

    verificar_projeto(
        tmp_path,
        agente.maquina
    )

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    chamadas = [
        evento
        for evento in eventos
        if (
            evento["type"] == "tool_execution"
            and evento["data"]["tool"] == "run_tests"
        )
    ]

    assert len(chamadas) == 1
    assert chamadas[0]["run_id"] == agente.run_id
    assert chamadas[0]["data"]["success"] is True


def test_agente_gera_relatorio_done(
    tmp_path, monkeypatch
):
    import json

    agente = criar_agente_planejado(tmp_path)

    def implementar_simulado(
        executor, spec, plan,
        max_passos=8, feedback_testes=None
    ):
        return {
            "finished": True,
            "summary": "Implementado.",
            "actions": [],
            "writes": 0
        }

    def verificar_simulado(diretorio, maquina):
        maquina.registrar_testes(
            executados=True,
            aprovados=True
        )

        return {
            "executed": True,
            "passed": True,
            "exit_code": 0,
            "output": "1 passed"
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    resultado = agente.executar_ciclo()

    assert resultado["status"] == "DONE"

    arquivo = tmp_path / ".minicode" / "report.json"

    assert arquivo.exists()

    relatorio = json.loads(
        arquivo.read_text(encoding="utf-8")
    )

    assert relatorio["run_id"] == agente.run_id
    assert relatorio["metrics"]["final_state"] == "DONE"
    assert relatorio["metrics"]["task_success"] is True
    assert relatorio["metrics"]["verifications"] == 1


def test_agente_gera_relatorio_failed(
    tmp_path, monkeypatch
):
    import json

    agente = criar_agente_planejado(tmp_path)

    def implementar_simulado(
        executor, spec, plan,
        max_passos=8, feedback_testes=None
    ):
        return {
            "finished": True,
            "summary": "Implementação tentada.",
            "actions": [],
            "writes": 0
        }

    def verificar_simulado(diretorio, maquina):
        maquina.registrar_testes(
            executados=True,
            aprovados=False
        )

        return {
            "executed": True,
            "passed": False,
            "exit_code": 1,
            "output": "1 failed"
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    resultado = agente.executar_ciclo(
        max_reparos=0
    )

    assert resultado["status"] == "FAILED"

    arquivo = tmp_path / ".minicode" / "report.json"

    assert arquivo.exists()

    relatorio = json.loads(
        arquivo.read_text(encoding="utf-8")
    )

    assert relatorio["run_id"] == agente.run_id
    assert relatorio["metrics"]["final_state"] == "FAILED"
    assert relatorio["metrics"]["task_success"] is False
    assert relatorio["metrics"]["verifications"] == 1
    assert relatorio["metrics"]["failed_verifications"] == 1
