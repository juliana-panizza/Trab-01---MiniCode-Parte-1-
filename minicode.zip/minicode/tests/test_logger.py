
import json

import pytest

from logger import RegistroEventos


def ler_eventos(tmp_path):
    arquivo = tmp_path / ".minicode" / "events.jsonl"

    return [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]


def test_criar_registro_de_estado(tmp_path):
    logger = RegistroEventos(tmp_path)

    logger.registrar_estado("PLANNED")

    eventos = ler_eventos(tmp_path)

    assert len(eventos) == 1
    assert eventos[0]["type"] == "state_transition"
    assert eventos[0]["data"]["state"] == "PLANNED"
    assert "timestamp" in eventos[0]


def test_registrar_ferramenta(tmp_path):
    logger = RegistroEventos(tmp_path)

    logger.registrar_ferramenta(
        "write_file",
        True
    )

    eventos = ler_eventos(tmp_path)

    assert eventos[0]["type"] == "tool_execution"
    assert eventos[0]["data"] == {
        "tool": "write_file",
        "success": True
    }


def test_registrar_verificacao(tmp_path):
    logger = RegistroEventos(tmp_path)

    logger.registrar_verificacao(
        executados=True,
        aprovados=False
    )

    eventos = ler_eventos(tmp_path)

    assert eventos[0]["type"] == "verification"
    assert eventos[0]["data"]["executed"] is True
    assert eventos[0]["data"]["passed"] is False


def test_registrar_reparo(tmp_path):
    logger = RegistroEventos(tmp_path)

    logger.registrar_reparo(
        tentativa=1,
        status="started"
    )

    eventos = ler_eventos(tmp_path)

    assert eventos[0]["type"] == "repair_attempt"
    assert eventos[0]["data"]["attempt"] == 1
    assert eventos[0]["data"]["status"] == "started"


def test_eventos_sao_acrescentados(tmp_path):
    logger = RegistroEventos(tmp_path)

    logger.registrar_estado("IMPLEMENTING")
    logger.registrar_ferramenta("read_file", True)
    logger.registrar_estado("VERIFYING")

    eventos = ler_eventos(tmp_path)

    assert len(eventos) == 3

    assert [
        evento["type"] for evento in eventos
    ] == [
        "state_transition",
        "tool_execution",
        "state_transition"
    ]


def test_bloquear_estado_invalido(tmp_path):
    logger = RegistroEventos(tmp_path)

    with pytest.raises(ValueError):
        logger.registrar_estado("ESTADO_INVENTADO")

    assert not logger.arquivo.exists()


def test_bloquear_resultado_incoerente(tmp_path):
    logger = RegistroEventos(tmp_path)

    with pytest.raises(ValueError):
        logger.registrar_verificacao(
            executados=False,
            aprovados=True
        )

    assert not logger.arquivo.exists()


def test_nao_registrar_conteudo_sensivel(tmp_path):
    logger = RegistroEventos(tmp_path)

    logger.registrar_ferramenta(
        "read_file",
        True
    )

    conteudo = logger.arquivo.read_text(
        encoding="utf-8"
    )

    assert "MINICODE_API_KEY" not in conteudo
    assert "conteudo" not in conteudo
    assert "prompt" not in conteudo
