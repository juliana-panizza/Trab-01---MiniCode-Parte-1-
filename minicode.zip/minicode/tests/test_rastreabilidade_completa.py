
import json

from agent import MiniCodeAgent
from states import Estado
from uuid import uuid4

from logger import RegistroEventos
from metricas import calcular_metricas


def test_rastreabilidade_ciclo_com_reparo(
    tmp_path, monkeypatch
):
    projeto = tmp_path / "projeto"
    projeto.mkdir()

    spec = {
        "objective": "Criar função resposta",
        "requirements": [
            "A função resposta deve retornar 42"
        ],
        "acceptance_criteria": [
            "resposta() retorna 42"
        ]
    }

    plan = {
        "summary": "Implementar resposta",
        "steps": [{
            "step": 1,
            "description": "Criar codigo.py",
            "files": ["codigo.py"]
        }],
        "tests": [
            "Verificar resposta()"
        ]
    }

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan
    )

    chamadas_implementacao = []

    def implementar_simulado(
        executor,
        spec,
        plan,
        max_passos=8,
        feedback_testes=None
    ):
        chamadas_implementacao.append(feedback_testes)

        if feedback_testes is None:
            conteudo = (
                "def resposta():\n"
                "    return 0\n"
            )
        else:
            conteudo = (
                "def resposta():\n"
                "    return 42\n"
            )

        # A escrita utiliza o executor real.
        executor.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": "codigo.py",
                "conteudo": conteudo
            }
        })

        return {
            "finished": True,
            "summary": "Implementação simulada.",
            "actions": [],
            "writes": 1
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    verificacoes = []

    def verificar_simulado(diretorio, maquina):
        passou = len(verificacoes) == 1
        verificacoes.append(passou)

        maquina.registrar_testes(
            executados=True,
            aprovados=passou
        )

        return {
            "executed": True,
            "passed": passou,
            "exit_code": 0 if passou else 1,
            "output": (
                "1 passed (simulado)"
                if passou
                else "AssertionError (simulado)"
            )
        }

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    agente = MiniCodeAgent(projeto)
    agente.preparar("Criar resposta que retorne 42")

    resultado = agente.executar_ciclo(
        max_reparos=1
    )

    assert resultado["status"] == "DONE"
    assert resultado["repairs"] == 1
    assert agente.maquina.estado == Estado.DONE

    # 1. Confere os arquivos de rastreabilidade.
    pasta_minicode = projeto / ".minicode"

    arquivos_esperados = [
        "specification.md",
        "plan.md",
        "state.json",
        "report.json",
        "events.jsonl"
    ]

    for nome in arquivos_esperados:
        assert (pasta_minicode / nome).is_file()

    # 2. Confere a persistência da SPEC e do PLAN.
    assert (
        pasta_minicode / "specification.md"
    ).stat().st_size > 0

    assert (
        pasta_minicode / "plan.md"
    ).stat().st_size > 0

    # 3. Confere o estado final.
    estado_salvo = json.loads(
        (pasta_minicode / "state.json").read_text(
            encoding="utf-8"
        )
    )

    assert estado_salvo["state"] == "DONE"

    # 4. Confere os eventos da execução.
    eventos = [
        json.loads(linha)
        for linha in (
            pasta_minicode / "events.jsonl"
        ).read_text(encoding="utf-8").splitlines()
    ]

    eventos_execucao = [
        evento
        for evento in eventos
        if evento.get("run_id") == agente.run_id
    ]

    assert eventos_execucao

    tipos = [
        evento["type"]
        for evento in eventos_execucao
    ]

    assert "state_transition" in tipos
    assert "tool_execution" in tipos
    assert "verification" in tipos
    assert "repair_attempt" in tipos

    # 5. Confere os arquivos modificados.
    escritas = [
        evento["data"]
        for evento in eventos_execucao
        if (
            evento["type"] == "tool_execution"
            and evento["data"]["tool"] == "write_file"
        )
    ]

    assert len(escritas) == 2
    assert all(
        escrita["path"] == "codigo.py"
        and escrita["success"] is True
        for escrita in escritas
    )

    # 6. Confere as verificações.
    testes = [
        evento["data"]
        for evento in eventos_execucao
        if evento["type"] == "verification"
    ]

    assert testes == [
        {"executed": True, "passed": False},
        {"executed": True, "passed": True}
    ]

    # 7. Confere os eventos de reparação.
    reparos = [
        evento["data"]
        for evento in eventos_execucao
        if evento["type"] == "repair_attempt"
    ]

    assert reparos == [
        {"attempt": 1, "status": "started"},
        {"attempt": 1, "status": "passed"}
    ]

    # 8. Confere o relatório.
    relatorio = json.loads(
        (pasta_minicode / "report.json").read_text(
            encoding="utf-8"
        )
    )

    metricas = relatorio["metrics"]

    assert relatorio["run_id"] == agente.run_id
    assert metricas["final_state"] == "DONE"
    assert metricas["task_success"] is True
    assert metricas["verifications"] == 2
    assert metricas["repairs_started"] == 1
    assert metricas["tool_usage"]["write_file"] == 2

    # 9. Confere o código final criado.
    assert (
        projeto / "codigo.py"
    ).read_text(encoding="utf-8") == (
        "def resposta():\n"
        "    return 42\n"
    )

    # 10. Confere que o conteúdo do código
    # não foi armazenado no log de eventos.
    texto_eventos = (
        pasta_minicode / "events.jsonl"
    ).read_text(encoding="utf-8")

    assert "def resposta():" not in texto_eventos
    assert "return 42" not in texto_eventos

    assert len(chamadas_implementacao) == 2
    assert len(verificacoes) == 2


def test_rastreabilidade_separada_por_run_id(tmp_path):
    run_id_a = str(uuid4())
    run_id_b = str(uuid4())

    logger_a = RegistroEventos(
        tmp_path,
        run_id=run_id_a
    )

    logger_b = RegistroEventos(
        tmp_path,
        run_id=run_id_b
    )

    logger_a.registrar_ferramenta(
        "write_file",
        True,
        caminho="codigo_a.py"
    )

    logger_a.registrar_chamada_llm(
        "implementation",
        True
    )

    logger_b.registrar_ferramenta(
        "write_file",
        True,
        caminho="codigo_b.py"
    )

    logger_b.registrar_chamada_llm(
        "repair",
        False
    )

    logger_b.registrar_chamada_llm(
        "repair",
        True
    )

    metricas_a = calcular_metricas(
        tmp_path,
        run_id=run_id_a
    )

    metricas_b = calcular_metricas(
        tmp_path,
        run_id=run_id_b
    )

    assert metricas_a["tool_calls"] == 1
    assert metricas_a["llm_calls"] == 1
    assert metricas_a["failed_llm_calls"] == 0

    assert metricas_b["tool_calls"] == 1
    assert metricas_b["llm_calls"] == 2
    assert metricas_b["failed_llm_calls"] == 1

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    eventos_a = [
        evento for evento in eventos
        if evento.get("run_id") == run_id_a
    ]

    eventos_b = [
        evento for evento in eventos
        if evento.get("run_id") == run_id_b
    ]

    assert len(eventos_a) == 2
    assert len(eventos_b) == 3

    caminhos_a = [
        evento["data"]["path"]
        for evento in eventos_a
        if evento["type"] == "tool_execution"
    ]

    caminhos_b = [
        evento["data"]["path"]
        for evento in eventos_b
        if evento["type"] == "tool_execution"
    ]

    assert caminhos_a == ["codigo_a.py"]
    assert caminhos_b == ["codigo_b.py"]


def test_rastreabilidade_execucao_com_falha(
    tmp_path, monkeypatch
):
    import pytest

    spec = {
        "objective": "Criar uma função",
        "requirements": [
            "Implementar a função exemplo"
        ],
        "acceptance_criteria": [
            "A função deve existir"
        ]
    }

    plan = {
        "summary": "Criar exemplo.py",
        "steps": [{
            "step": 1,
            "description": "Implementar função",
            "files": ["exemplo.py"]
        }],
        "tests": ["Verificar a função"]
    }

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan
    )

    def implementar_com_falha(
        executor,
        spec,
        plan,
        max_passos=8,
        feedback_testes=None
    ):
        # Simula uma tentativa proibida de escrita.
        executor.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": ".env",
                "conteudo": "CREDENCIAL_TESTE=segredo"
            }
        })

    monkeypatch.setattr(
        "agent.implementar",
        implementar_com_falha
    )

    agente = MiniCodeAgent(tmp_path)

    agente.preparar(
        "Criar uma função de exemplo"
    )

    with pytest.raises(PermissionError):
        agente.executar_implementacao()

    assert agente.maquina.estado == Estado.FAILED

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    eventos_execucao = [
        evento
        for evento in eventos
        if evento.get("run_id") == agente.run_id
    ]

    falhas_ferramenta = [
        evento["data"]
        for evento in eventos_execucao
        if (
            evento["type"] == "tool_execution"
            and evento["data"]["success"] is False
        )
    ]

    assert falhas_ferramenta == [{
        "tool": "write_file",
        "success": False
    }]

    erros = [
        evento["data"]
        for evento in eventos_execucao
        if evento["type"] == "execution_error"
    ]

    # O executor e o agente registram a exceção
    # nas respectivas camadas.
    assert {
        "stage": "implementation",
        "error_type": "PermissionError"
    } in erros

    relatorio = json.loads(
        (
            tmp_path / ".minicode" / "report.json"
        ).read_text(encoding="utf-8")
    )

    assert relatorio["run_id"] == agente.run_id
    assert relatorio["metrics"]["final_state"] == "FAILED"
    assert relatorio["metrics"]["task_success"] is False

    # Não deve haver arquivo criado fora do escopo.
    assert not (tmp_path / ".env").exists()

    # Não armazenar conteúdo ou credenciais nos eventos.
    texto_log = arquivo.read_text(encoding="utf-8")

    assert "CREDENCIAL_TESTE=segredo" not in texto_log
    assert ".env" not in texto_log
