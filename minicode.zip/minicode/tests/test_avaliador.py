
from uuid import uuid4

import pytest

from avaliador import avaliar_execucoes


def criar_relatorio(sucesso, ferramentas=2, reparos=0):
    return {
        "run_id": str(uuid4()),
        "metrics": {
            "final_state": "DONE" if sucesso else "FAILED",
            "task_success": sucesso,
            "tool_calls": ferramentas,
            "verifications": 1,
            "repairs_started": reparos
        }
    }


def test_avaliacao_todas_aprovadas():
    relatorios = [
        criar_relatorio(True),
        criar_relatorio(True)
    ]

    resultado = avaliar_execucoes(relatorios)

    assert resultado["total_runs"] == 2
    assert resultado["successful_runs"] == 2
    assert resultado["failed_runs"] == 0
    assert resultado["success_rate"] == 1.0


def test_avaliacao_com_falhas():
    relatorios = [
        criar_relatorio(True, ferramentas=3),
        criar_relatorio(False, ferramentas=5, reparos=1),
        criar_relatorio(True, ferramentas=4)
    ]

    resultado = avaliar_execucoes(relatorios)

    assert resultado["total_runs"] == 3
    assert resultado["successful_runs"] == 2
    assert resultado["failed_runs"] == 1
    assert resultado["success_rate"] == 0.6667

    assert resultado["total_tool_calls"] == 12
    assert resultado["average_tool_calls"] == 4.0
    assert resultado["total_repairs"] == 1


def test_rejeitar_execucao_duplicada():
    relatorio = criar_relatorio(True)

    with pytest.raises(
        ValueError,
        match="contabilizada duas vezes"
    ):
        avaliar_execucoes([
            relatorio,
            relatorio
        ])


def test_rejeitar_relatorio_incoerente():
    relatorio = criar_relatorio(True)
    relatorio["metrics"]["final_state"] = "FAILED"

    with pytest.raises(
        ValueError,
        match="incoerentes"
    ):
        avaliar_execucoes([relatorio])


def test_rejeitar_lista_vazia():
    with pytest.raises(ValueError):
        avaliar_execucoes([])


def test_primeira_tentativa_todas_aprovadas():
    relatorios = [
        criar_relatorio(True, reparos=0),
        criar_relatorio(True, reparos=0)
    ]

    resultado = avaliar_execucoes(relatorios)

    assert resultado["first_attempt_successes"] == 2
    assert resultado["first_attempt_success_rate"] == 1.0


def test_primeira_tentativa_com_reparos():
    relatorios = [
        criar_relatorio(True, reparos=0),
        criar_relatorio(True, reparos=1),
        criar_relatorio(False, reparos=1)
    ]

    resultado = avaliar_execucoes(relatorios)

    assert resultado["successful_runs"] == 2
    assert resultado["first_attempt_successes"] == 1

    assert resultado["first_attempt_success_rate"] == 0.3333

    assert resultado["runs"][0]["first_attempt_success"] is True
    assert resultado["runs"][1]["first_attempt_success"] is False
    assert resultado["runs"][2]["first_attempt_success"] is False


def test_medias_llm_e_iteracoes():
    from uuid import uuid4

    relatorios = []

    dados = [
        (True, 4, 1),
        (True, 7, 2),
        (False, 5, 1)
    ]

    for sucesso, chamadas, iteracoes in dados:
        relatorios.append({
            "run_id": str(uuid4()),
            "metrics": {
                "final_state": (
                    "DONE" if sucesso else "FAILED"
                ),
                "task_success": sucesso,
                "tool_calls": 2,
                "verifications": iteracoes,
                "repairs_started": 0 if iteracoes == 1 else 1,
                "llm_calls": chamadas,
                "iterations": iteracoes
            }
        })

    resultado = avaliar_execucoes(relatorios)

    assert resultado["total_runs"] == 3
    assert resultado["total_llm_calls"] == 16
    assert resultado["total_iterations"] == 4

    assert resultado["average_llm_calls"] == 5.33
    assert resultado["average_iterations"] == 1.33

    assert resultado["runs"][0]["llm_calls"] == 4
    assert resultado["runs"][1]["iterations"] == 2


def test_medias_compativeis_com_relatorios_antigos():
    from uuid import uuid4

    relatorios = [
        {
            "run_id": str(uuid4()),
            "metrics": {
                "final_state": "DONE",
                "task_success": True,
                "tool_calls": 3,
                "verifications": 1,
                "repairs_started": 0
            }
        }
    ]

    resultado = avaliar_execucoes(relatorios)

    assert resultado["total_llm_calls"] == 0
    assert resultado["total_iterations"] == 1
    assert resultado["average_llm_calls"] == 0.0
    assert resultado["average_iterations"] == 1.0


def test_rejeitar_metricas_llm_invalidas():
    from uuid import uuid4
    import pytest

    relatorio = {
        "run_id": str(uuid4()),
        "metrics": {
            "final_state": "DONE",
            "task_success": True,
            "tool_calls": 1,
            "verifications": 1,
            "repairs_started": 0,
            "llm_calls": -1,
            "iterations": 1
        }
    }

    with pytest.raises(
        ValueError,
        match="llm_calls"
    ):
        avaliar_execucoes([relatorio])

    relatorio["metrics"]["llm_calls"] = 3
    relatorio["metrics"]["iterations"] = True

    with pytest.raises(
        ValueError,
        match="iterations"
    ):
        avaliar_execucoes([relatorio])
