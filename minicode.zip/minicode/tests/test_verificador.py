
import pytest
import json

from states import Estado, MaquinaEstados
from verificador import verificar_projeto


@pytest.fixture
def maquina_em_verificacao():
    maquina = MaquinaEstados()

    spec = {
        "objective": "Criar função",
        "requirements": ["Implementar função"],
        "acceptance_criteria": [
            "A função deve passar nos testes"
        ]
    }

    plan = {
        "summary": "Implementar função",
        "steps": [
            {
                "step": 1,
                "description": "Criar a função",
                "files": ["codigo.py"]
            }
        ],
        "tests": ["Executar pytest"]
    }

    maquina.registrar_spec(spec)
    maquina.registrar_plan(plan)
    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    return maquina


def test_verificacao_aprovada(
    tmp_path, monkeypatch, maquina_em_verificacao
):
    resultado_simulado = {
        "executed": True,
        "passed": True,
        "exit_code": 0,
        "output": "3 passed"
    }

    monkeypatch.setattr(
        "verificador.FerramentasProjeto.run_tests",
        lambda self: resultado_simulado
    )

    resultado = verificar_projeto(
        tmp_path,
        maquina_em_verificacao
    )

    assert resultado["passed"] is True
    assert maquina_em_verificacao.testes_executados is True
    assert maquina_em_verificacao.testes_aprovados is True
    assert maquina_em_verificacao.estado == Estado.VERIFYING


def test_verificacao_reprovada(
    tmp_path, monkeypatch, maquina_em_verificacao
):
    resultado_simulado = {
        "executed": True,
        "passed": False,
        "exit_code": 1,
        "output": "1 failed"
    }

    monkeypatch.setattr(
        "verificador.FerramentasProjeto.run_tests",
        lambda self: resultado_simulado
    )

    resultado = verificar_projeto(
        tmp_path,
        maquina_em_verificacao
    )

    assert resultado["passed"] is False
    assert maquina_em_verificacao.testes_executados is True
    assert maquina_em_verificacao.testes_aprovados is False
    assert maquina_em_verificacao.estado == Estado.VERIFYING


def test_verificacao_sem_estado_autorizado(tmp_path):
    maquina = MaquinaEstados()

    with pytest.raises(RuntimeError):
        verificar_projeto(tmp_path, maquina)

    assert maquina.estado == Estado.RECEIVED

def ler_eventos_verificador(tmp_path):
    arquivo = tmp_path / ".minicode" / "events.jsonl"

    return [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]


def test_log_run_tests_aprovado(
    tmp_path, monkeypatch, maquina_em_verificacao
):
    def executar_simulado(self):
        return {
            "executed": True,
            "passed": True,
            "exit_code": 0,
            "output": "3 passed"
        }

    monkeypatch.setattr(
        "verificador.FerramentasProjeto.run_tests",
        executar_simulado
    )

    verificar_projeto(
        tmp_path,
        maquina_em_verificacao
    )

    eventos = ler_eventos_verificador(tmp_path)

    assert eventos[-1]["type"] == "tool_execution"
    assert eventos[-1]["data"] == {
        "tool": "run_tests",
        "success": True
    }


def test_log_run_tests_reprovado(
    tmp_path, monkeypatch, maquina_em_verificacao
):
    def executar_simulado(self):
        return {
            "executed": True,
            "passed": False,
            "exit_code": 1,
            "output": "1 failed"
        }

    monkeypatch.setattr(
        "verificador.FerramentasProjeto.run_tests",
        executar_simulado
    )

    verificar_projeto(
        tmp_path,
        maquina_em_verificacao
    )

    eventos = ler_eventos_verificador(tmp_path)

    assert eventos[-1]["data"] == {
        "tool": "run_tests",
        "success": False
    }

    assert maquina_em_verificacao.testes_aprovados is False


def test_log_run_tests_com_excecao(
    tmp_path, monkeypatch, maquina_em_verificacao
):
    def executar_simulado(self):
        raise RuntimeError("Erro simulado")

    monkeypatch.setattr(
        "verificador.FerramentasProjeto.run_tests",
        executar_simulado
    )

    with pytest.raises(
        RuntimeError,
        match="Erro simulado"
    ):
        verificar_projeto(
            tmp_path,
            maquina_em_verificacao
        )

    eventos = ler_eventos_verificador(tmp_path)

    assert eventos[-1]["data"] == {
        "tool": "run_tests",
        "success": False
    }


def test_verificacao_bloqueada_sem_isolamento(
    tmp_path, monkeypatch
):
    from states import Estado, MaquinaEstados
    from tools import FerramentasProjeto
    from verificador import verificar_projeto

    maquina = MaquinaEstados()

    maquina.registrar_spec({
        "objective": "Criar função",
        "requirements": ["Implementar função"],
        "acceptance_criteria": ["Passar nos testes"]
    })

    maquina.registrar_plan({
        "summary": "Implementar função",
        "steps": [{
            "step": 1,
            "description": "Criar codigo.py",
            "files": ["codigo.py"]
        }],
        "tests": ["Executar pytest"]
    })

    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    def testes_bloqueados(self):
        return {
            "executed": False,
            "passed": False,
            "exit_code": None,
            "output": (
                "Execução bloqueada: "
                "ambiente isolado indisponível."
            )
        }

    monkeypatch.setattr(
        FerramentasProjeto,
        "run_tests",
        testes_bloqueados
    )

    resultado = verificar_projeto(tmp_path, maquina)

    assert resultado["executed"] is False
    assert resultado["passed"] is False
    assert resultado["exit_code"] is None

    assert maquina.testes_executados is False
    assert maquina.testes_aprovados is False
    assert maquina.estado == Estado.VERIFYING
