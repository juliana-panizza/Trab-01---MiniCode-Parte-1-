
import pytest

from cenarios import CENARIOS, validar_cenario


def test_todos_cenarios_sao_validos():
    for cenario in CENARIOS:
        assert validar_cenario(cenario) is True


def test_ids_dos_cenarios_sao_unicos():
    identificadores = [
        cenario["id"]
        for cenario in CENARIOS
    ]

    assert len(identificadores) == len(
        set(identificadores)
    )


def test_todos_possuem_criterios():
    for cenario in CENARIOS:
        assert len(
            cenario["acceptance_criteria"]
        ) >= 3


def test_rejeitar_cenario_sem_criterios():
    cenario = CENARIOS[0].copy()
    cenario["acceptance_criteria"] = []

    with pytest.raises(ValueError):
        validar_cenario(cenario)


def test_rejeitar_dificuldade_invalida():
    cenario = CENARIOS[0].copy()
    cenario["difficulty"] = "impossible"

    with pytest.raises(ValueError):
        validar_cenario(cenario)
