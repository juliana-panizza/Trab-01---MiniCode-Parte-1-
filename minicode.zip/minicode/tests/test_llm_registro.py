
import json
from types import SimpleNamespace
from uuid import uuid4

import pytest

import llm
from llm import chat, contexto_llm


def ler_eventos(projeto):
    arquivo = projeto / ".minicode" / "events.jsonl"

    if not arquivo.exists():
        return []

    return [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]


def criar_cliente_falso(resultado=None, erro=None):
    def create(**kwargs):
        if erro is not None:
            raise erro

        return SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(
                        content=resultado
                    )
                )
            ]
        )

    return SimpleNamespace(
        chat=SimpleNamespace(
            completions=SimpleNamespace(
                create=create
            )
        )
    )


def test_chamada_llm_com_sucesso(tmp_path, monkeypatch):
    monkeypatch.setattr(
        llm,
        "criar_cliente",
        lambda: criar_cliente_falso(
            resultado='{"action": "finish"}'
        )
    )

    run_id = str(uuid4())

    with contexto_llm(tmp_path, run_id, "implementation"):
        resposta = chat(
            [{"role": "user", "content": "Teste"}]
        )

    assert resposta == '{"action": "finish"}'

    eventos = ler_eventos(tmp_path)

    assert len(eventos) == 1
    assert eventos[0]["type"] == "llm_call"
    assert eventos[0]["run_id"] == run_id
    assert eventos[0]["data"] == {
        "stage": "implementation",
        "success": True
    }


def test_chamada_llm_com_erro(tmp_path, monkeypatch):
    monkeypatch.setattr(
        llm,
        "criar_cliente",
        lambda: criar_cliente_falso(
            erro=RuntimeError("API indisponível")
        )
    )

    with contexto_llm(
        tmp_path,
        str(uuid4()),
        "repair"
    ):
        with pytest.raises(
            RuntimeError,
            match="API indisponível"
        ):
            chat([{"role": "user", "content": "Teste"}])

    eventos = ler_eventos(tmp_path)

    assert len(eventos) == 1
    assert eventos[0]["data"] == {
        "stage": "repair",
        "success": False
    }


@pytest.mark.parametrize(
    "conteudo",
    ["", None]
)
def test_resposta_vazia_conta_falha(
    tmp_path, monkeypatch, conteudo
):
    monkeypatch.setattr(
        llm,
        "criar_cliente",
        lambda: criar_cliente_falso(
            resultado=conteudo
        )
    )

    with contexto_llm(
        tmp_path,
        str(uuid4()),
        "spec"
    ):
        with pytest.raises(RuntimeError):
            chat([{"role": "user", "content": "Teste"}])

    eventos = ler_eventos(tmp_path)

    assert len(eventos) == 1
    assert eventos[0]["data"]["success"] is False


def test_multiplas_chamadas_sao_contadas(
    tmp_path, monkeypatch
):
    chamadas_api = []

    def create(**kwargs):
        chamadas_api.append(kwargs)

        return SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(
                        content="Resposta válida"
                    )
                )
            ]
        )

    cliente = SimpleNamespace(
        chat=SimpleNamespace(
            completions=SimpleNamespace(
                create=create
            )
        )
    )

    monkeypatch.setattr(
        llm,
        "criar_cliente",
        lambda: cliente
    )

    run_id = str(uuid4())

    with contexto_llm(tmp_path, run_id, "plan"):
        chat([{"role": "user", "content": "Primeira"}])
        chat([{"role": "user", "content": "Segunda"}])
        chat([{"role": "user", "content": "Terceira"}])

    eventos = ler_eventos(tmp_path)

    assert len(chamadas_api) == 3
    assert len(eventos) == 3

    assert all(
        evento["type"] == "llm_call"
        and evento["run_id"] == run_id
        and evento["data"]["stage"] == "plan"
        for evento in eventos
    )
