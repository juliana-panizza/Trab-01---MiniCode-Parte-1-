
import pytest

from states import Estado, MaquinaEstados


@pytest.fixture
def maquina_preparada():
    maquina = MaquinaEstados(max_tentativas=3)

    spec = {
        "objective": "Criar uma função de fatorial",
        "requirements": [
            "Receber um inteiro não negativo"
        ],
        "acceptance_criteria": [
            "fatorial(0) deve retornar 1"
        ]
    }

    plan = {
        "summary": "Implementar a função de fatorial",
        "steps": [
            {
                "step": 1,
                "description": "Criar a função",
                "files": ["calculadora.py"]
            }
        ],
        "tests": [
            "Testar fatorial(0)"
        ]
    }

    maquina.registrar_spec(spec)
    maquina.registrar_plan(plan)

    return maquina


def test_estado_inicial():
    maquina = MaquinaEstados()

    assert maquina.estado == Estado.RECEIVED


def test_nao_implementar_sem_spec():
    maquina = MaquinaEstados()

    with pytest.raises(RuntimeError):
        maquina.transicionar(Estado.IMPLEMENTING)


def test_fluxo_spec_plan(maquina_preparada):
    assert maquina_preparada.estado == Estado.PLANNED
    assert maquina_preparada.spec_valida
    assert maquina_preparada.plan_valido


def test_nao_finalizar_sem_testes(maquina_preparada):
    maquina = maquina_preparada

    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    with pytest.raises(RuntimeError):
        maquina.finalizar()


def test_nao_finalizar_com_testes_falhando(maquina_preparada):
    maquina = maquina_preparada

    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    maquina.registrar_testes(
        executados=True,
        aprovados=False
    )

    with pytest.raises(RuntimeError):
        maquina.finalizar()


def test_finalizar_com_testes_aprovados(maquina_preparada):
    maquina = maquina_preparada

    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    maquina.registrar_testes(
        executados=True,
        aprovados=True
    )

    maquina.finalizar()

    assert maquina.estado == Estado.DONE


def test_reparo_apos_falha(maquina_preparada):
    maquina = maquina_preparada

    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    maquina.registrar_testes(
        executados=True,
        aprovados=False
    )

    maquina.transicionar(Estado.REPAIRING)

    assert maquina.estado == Estado.REPAIRING

    # Entrar em REPAIRING ainda não é iniciar um reparo.
    assert maquina.tentativas_reparo == 0

    tentativa = maquina.iniciar_reparo()

    assert tentativa == 1
    assert maquina.tentativas_reparo == 1



def test_limite_de_reparos(maquina_preparada):
    maquina = maquina_preparada

    # O limite padrão da máquina é 3.
    assert maquina.max_tentativas == 3

    for tentativa_esperada in range(1, 4):
        maquina.transicionar(Estado.IMPLEMENTING)
        maquina.transicionar(Estado.VERIFYING)

        maquina.registrar_testes(
            executados=True,
            aprovados=False
        )

        maquina.transicionar(Estado.REPAIRING)

        # A entrada no estado não conta como tentativa.
        assert maquina.tentativas_reparo == (
            tentativa_esperada - 1
        )

        tentativa = maquina.iniciar_reparo()

        assert tentativa == tentativa_esperada
        assert maquina.tentativas_reparo == tentativa_esperada

    # Depois de três reparos, outra verificação
    # reprovada ainda pode levar a REPAIRING.
    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    maquina.registrar_testes(
        executados=True,
        aprovados=False
    )

    maquina.transicionar(Estado.REPAIRING)

    assert maquina.estado == Estado.REPAIRING
    assert maquina.tentativas_reparo == 3

    # Mas não é permitido iniciar um quarto reparo.
    with pytest.raises(
        RuntimeError,
        match="Limite de reparos atingido"
    ):
        maquina.iniciar_reparo()

    assert maquina.tentativas_reparo == 3



def test_resultados_antigos_sao_invalidados(maquina_preparada):
    maquina = maquina_preparada

    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    maquina.registrar_testes(
        executados=True,
        aprovados=False
    )

    maquina.transicionar(Estado.REPAIRING)
    maquina.transicionar(Estado.IMPLEMENTING)

    assert maquina.testes_executados is False
    assert maquina.testes_aprovados is False


def test_nao_reparar_testes_aprovados(maquina_preparada):
    maquina = maquina_preparada

    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    maquina.registrar_testes(
        executados=True,
        aprovados=True
    )

    with pytest.raises(RuntimeError):
        maquina.transicionar(Estado.REPAIRING)


def test_nao_iniciar_reparo_duas_vezes(
    maquina_preparada
):
    maquina = maquina_preparada

    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    maquina.registrar_testes(
        executados=True,
        aprovados=False
    )

    maquina.transicionar(Estado.REPAIRING)

    assert maquina.tentativas_reparo == 0

    primeira = maquina.iniciar_reparo()

    assert primeira == 1
    assert maquina.reparo_iniciado is True

    with pytest.raises(
        RuntimeError,
        match="já foi iniciado"
    ):
        maquina.iniciar_reparo()

    # A tentativa duplicada não altera o contador.
    assert maquina.tentativas_reparo == 1


def test_nova_passagem_permite_outro_reparo(
    maquina_preparada
):
    maquina = maquina_preparada

    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    maquina.registrar_testes(
        executados=True,
        aprovados=False
    )

    maquina.transicionar(Estado.REPAIRING)

    assert maquina.iniciar_reparo() == 1

    # Simula uma implementação corrigida
    # cujos testes continuam reprovados.
    maquina.transicionar(Estado.IMPLEMENTING)
    maquina.transicionar(Estado.VERIFYING)

    maquina.registrar_testes(
        executados=True,
        aprovados=False
    )

    maquina.transicionar(Estado.REPAIRING)

    # A nova passagem libera uma nova tentativa.
    assert maquina.reparo_iniciado is False

    assert maquina.iniciar_reparo() == 2
    assert maquina.tentativas_reparo == 2
