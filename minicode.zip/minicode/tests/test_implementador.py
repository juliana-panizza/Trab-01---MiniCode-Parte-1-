
import json

from executor import Executor
from implementador import implementar
from states import Estado, MaquinaEstados


def test_implementacao_simulada(tmp_path, monkeypatch):
    maquina = MaquinaEstados()

    spec = {
        "objective": "Criar função resposta",
        "requirements": [
            "A função deve retornar 42"
        ],
        "acceptance_criteria": [
            "resposta() deve retornar 42"
        ]
    }

    plan = {
        "summary": "Criar codigo.py",
        "steps": [
            {
                "step": 1,
                "description": "Implementar a função",
                "files": ["codigo.py"]
            }
        ],
        "tests": [
            "Verificar resposta()"
        ]
    }

    maquina.registrar_spec(spec)
    maquina.registrar_plan(plan)
    maquina.transicionar(Estado.IMPLEMENTING)

    respostas = [
        {
            "action": "write_file",
            "arguments": {
                "caminho": "codigo.py",
                "conteudo": "def resposta():\n    return 42\n"
            }
        },
        {
            "action": "finish",
            "arguments": {
                "resposta": "Função criada."
            }
        }
    ]

    def chat_simulado(mensagens, **kwargs):
        return json.dumps(respostas.pop(0))

    monkeypatch.setattr(
        "implementador.chat",
        chat_simulado
    )

    executor = Executor(tmp_path, maquina)

    resultado = implementar(
        executor,
        spec,
        plan
    )

    assert resultado["finished"] is True
    assert resultado["writes"] == 1

    assert (
        tmp_path / "codigo.py"
    ).read_text(encoding="utf-8") == (
        "def resposta():\n    return 42\n"
    )

    assert maquina.estado == Estado.IMPLEMENTING


import pytest


def test_implementar_sem_estado_autorizado(tmp_path):
    maquina = MaquinaEstados()

    executor = Executor(tmp_path, maquina)

    with pytest.raises(RuntimeError):
        implementar(
            executor,
            spec={},
            plan={}
        )


def test_limite_de_escritas(tmp_path, monkeypatch):
    maquina = MaquinaEstados()

    spec = {
        "objective": "Criar arquivos",
        "requirements": ["Criar arquivos Python"],
        "acceptance_criteria": [
            "Os arquivos devem ser criados"
        ]
    }

    plan = {
        "summary": "Criar arquivos de teste",
        "steps": [
            {
                "step": 1,
                "description": "Criar arquivos",
                "files": ["arquivo.py"]
            }
        ],
        "tests": ["Verificar os arquivos"]
    }

    maquina.registrar_spec(spec)
    maquina.registrar_plan(plan)
    maquina.transicionar(Estado.IMPLEMENTING)

    def chat_simulado(mensagens, **kwargs):
        return json.dumps({
            "action": "write_file",
            "arguments": {
                "caminho": "arquivo.py",
                "conteudo": "x = 1"
            }
        })

    monkeypatch.setattr(
        "implementador.chat",
        chat_simulado
    )

    executor = Executor(tmp_path, maquina)

    with pytest.raises(
        RuntimeError,
        match="Limite de quatro escritas"
    ):
        implementar(
            executor,
            spec,
            plan,
            max_passos=8
        )
