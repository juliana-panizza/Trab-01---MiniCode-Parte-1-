
import pytest

from preparador_avaliacao import preparar_cenarios
from validador_ambiente import validar_ambiente_avaliacao


@pytest.fixture
def ambiente_preparado(tmp_path):
    base = tmp_path / "avaliacao"
    preparar_cenarios(base)
    return base


def test_validar_ambiente_completo(ambiente_preparado):
    resultado = validar_ambiente_avaliacao(
        ambiente_preparado
    )

    assert len(resultado) == 5
    assert {item["id"] for item in resultado} == {
        "C01", "C02", "C03", "C04", "C05"
    }

    assert all(item["ready"] for item in resultado)


def test_rejeitar_diretorio_inexistente(tmp_path):
    with pytest.raises(FileNotFoundError):
        validar_ambiente_avaliacao(
            tmp_path / "nao_existe"
        )


def test_rejeitar_arquivo_alvo_ausente(
    ambiente_preparado
):
    arquivo = (
        ambiente_preparado
        / "C01"
        / "projeto"
        / "calculadora.py"
    )

    arquivo.unlink()

    with pytest.raises(FileNotFoundError):
        validar_ambiente_avaliacao(
            ambiente_preparado
        )


def test_rejeitar_testes_alterados(
    ambiente_preparado
):
    arquivo = (
        ambiente_preparado
        / "C02"
        / "avaliacao"
        / "test_aceitacao.py"
    )

    arquivo.write_text(
        "def test_falso(): assert True\n",
        encoding="utf-8"
    )

    with pytest.raises(
        ValueError,
        match="Testes de aceitação alterados"
    ):
        validar_ambiente_avaliacao(
            ambiente_preparado
        )


def test_rejeitar_pasta_de_avaliacao_ausente(
    ambiente_preparado
):
    import shutil

    pasta = (
        ambiente_preparado
        / "C03"
        / "avaliacao"
    )

    shutil.rmtree(pasta)

    with pytest.raises(FileNotFoundError):
        validar_ambiente_avaliacao(
            ambiente_preparado
        )
