
import json
from uuid import uuid4

import pytest

from logger import RegistroEventos


def test_registrar_chamada_llm(tmp_path):
    run_id = str(uuid4())

    logger = RegistroEventos(
        tmp_path,
        run_id=run_id
    )

    logger.registrar_chamada_llm(
        etapa="implementation",
        sucesso=True
    )

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    assert len(eventos) == 1

    evento = eventos[0]

    assert evento["type"] == "llm_call"
    assert evento["run_id"] == run_id

    assert evento["data"] == {
        "stage": "implementation",
        "success": True
    }

    assert "timestamp" in evento


def test_registrar_chamada_llm_com_falha(tmp_path):
    logger = RegistroEventos(
        tmp_path,
        run_id=str(uuid4())
    )

    logger.registrar_chamada_llm(
        etapa="repair",
        sucesso=False
    )

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    evento = json.loads(
        arquivo.read_text(
            encoding="utf-8"
        ).splitlines()[0]
    )

    assert evento["data"]["stage"] == "repair"
    assert evento["data"]["success"] is False


@pytest.mark.parametrize(
    "etapa",
    ["", "   ", None, 123]
)
def test_rejeitar_etapa_invalida(tmp_path, etapa):
    logger = RegistroEventos(tmp_path)

    with pytest.raises(ValueError):
        logger.registrar_chamada_llm(etapa)

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    assert not arquivo.exists() or (
        arquivo.read_text(encoding="utf-8") == ""
    )


def test_rejeitar_sucesso_invalido(tmp_path):
    logger = RegistroEventos(tmp_path)

    with pytest.raises(TypeError):
        logger.registrar_chamada_llm(
            etapa="spec",
            sucesso="sim"
        )

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    assert not arquivo.exists() or (
        arquivo.read_text(encoding="utf-8") == ""
    )
