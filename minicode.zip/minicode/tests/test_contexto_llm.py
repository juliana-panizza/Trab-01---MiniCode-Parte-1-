
import json
from uuid import uuid4

import pytest

from llm import contexto_llm, registrar_resultado_llm


def ler_eventos(projeto):
    arquivo = projeto / ".minicode" / "events.jsonl"

    if not arquivo.exists():
        return []

    return [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]


def test_contexto_registra_chamada(tmp_path):
    run_id = str(uuid4())

    with contexto_llm(tmp_path, run_id, "spec"):
        registrar_resultado_llm(True)

    eventos = ler_eventos(tmp_path)

    assert len(eventos) == 1
    assert eventos[0]["type"] == "llm_call"
    assert eventos[0]["run_id"] == run_id
    assert eventos[0]["data"]["stage"] == "spec"
    assert eventos[0]["data"]["success"] is True


def test_contexto_registra_falha(tmp_path):
    run_id = str(uuid4())

    with contexto_llm(tmp_path, run_id, "repair"):
        registrar_resultado_llm(False)

    eventos = ler_eventos(tmp_path)

    assert eventos[0]["data"]["stage"] == "repair"
    assert eventos[0]["data"]["success"] is False


def test_fora_do_contexto_nao_registra(tmp_path):
    registrar_resultado_llm(True)

    assert ler_eventos(tmp_path) == []


def test_contexto_restaura_estado(tmp_path):
    run_id = str(uuid4())

    with contexto_llm(tmp_path, run_id, "plan"):
        registrar_resultado_llm(True)

    # Fora do contexto, o registro não é feito.
    registrar_resultado_llm(True)

    assert len(ler_eventos(tmp_path)) == 1


def test_contexto_rejeita_etapa_invalida(tmp_path):
    with pytest.raises(ValueError):
        with contexto_llm(
            tmp_path,
            str(uuid4()),
            "etapa_invalida"
        ):
            pass


def test_contextos_aninhados(tmp_path):
    run_id = str(uuid4())

    with contexto_llm(tmp_path, run_id, "spec"):
        registrar_resultado_llm(True)

        with contexto_llm(tmp_path, run_id, "plan"):
            registrar_resultado_llm(True)

        registrar_resultado_llm(True)

    eventos = ler_eventos(tmp_path)

    etapas = [
        evento["data"]["stage"]
        for evento in eventos
    ]

    assert etapas == ["spec", "plan", "spec"]
