
import pytest

from aceitacao import obter_testes_aceitacao
from preparador_avaliacao import preparar_cenarios
from pathlib import Path

@pytest.fixture
def avaliacao_preparada(tmp_path):
    base = tmp_path / "avaliacao"

    projetos = preparar_cenarios(base)

    return base, projetos


def test_prepara_cinco_cenarios(avaliacao_preparada):
    base, projetos = avaliacao_preparada

    assert len(projetos) == 5
    assert {item["id"] for item in projetos} == {
        "C01", "C02", "C03", "C04", "C05"
    }

    assert (base / "C01").is_dir()
    assert (base / "C02").is_dir()
    assert (base / "C03").is_dir()


def test_cria_arquivos_iniciais(avaliacao_preparada):
    base, _ = avaliacao_preparada

    assert (
        base / "C01" / "projeto" / "calculadora.py"
    ).exists()

    assert (
        base / "C02" / "projeto" / "texto.py"
    ).exists()

    assert (
        base / "C03" / "projeto" / "notas.py"
    ).exists()


def test_testes_ficam_fora_do_projeto(
    avaliacao_preparada
):
    base, _ = avaliacao_preparada

    for identificador in ("C01", "C02", "C03"):
        projeto = base / identificador / "projeto"
        avaliacao = base / identificador / "avaliacao"

        assert (
            avaliacao / "test_aceitacao.py"
        ).exists()

        assert not (
            projeto / "test_aceitacao.py"
        ).exists()

        conteudo = (
            avaliacao / "test_aceitacao.py"
        ).read_text(encoding="utf-8")

        assert conteudo == obter_testes_aceitacao(
            identificador
        )


def test_nao_sobrescreve_avaliacao_anterior(
    avaliacao_preparada
):
    base, _ = avaliacao_preparada

    arquivo = (
        base / "C01" / "projeto" / "calculadora.py"
    )

    arquivo.write_text(
        "resultado_anterior = 42\n",
        encoding="utf-8"
    )

    with pytest.raises(FileExistsError):
        preparar_cenarios(base)

    assert arquivo.read_text(
        encoding="utf-8"
    ) == "resultado_anterior = 42\n"


def test_retorna_diretorios_corretos(
    avaliacao_preparada
):
    base, projetos = avaliacao_preparada

    for item in projetos:
        identificador = item["id"]

        assert item["project_dir"] == str(
            base / identificador / "projeto"
        )

        assert item["acceptance_tests"] == str(
            base / identificador / "avaliacao"
            / "test_aceitacao.py"
        )

        assert item["task"]


def test_c04_comeca_com_bug(avaliacao_preparada):
    base, projetos = avaliacao_preparada

    c04 = next(
        projeto
        for projeto in projetos
        if projeto["id"] == "C04"
    )

    arquivo = (
        Path(c04["project_dir"]) / "desconto.py"
    )

    assert arquivo.read_text(
        encoding="utf-8"
    ) == (
        "def aplicar_desconto(preco, percentual):\n"
        "    return preco - percentual\n"
    )

    testes = Path(
        c04["acceptance_tests"]
    ).read_text(encoding="utf-8")

    assert "test_desconto_dez_por_cento" in testes
    assert "test_desconto_total" in testes


def test_c05_preserva_api_inicial(avaliacao_preparada):
    base, projetos = avaliacao_preparada

    c05 = next(
        projeto
        for projeto in projetos
        if projeto["id"] == "C05"
    )

    arquivo = Path(c05["project_dir"]) / "saudacao.py"

    assert arquivo.read_text(encoding="utf-8") == (
        "def saudar(nome):\n"
        '    return f"Olá, {nome}!"\n'
    )

    testes = Path(
        c05["acceptance_tests"]
    ).read_text(encoding="utf-8")

    assert "test_compatibilidade_antiga" in testes
    assert "test_parametro_nomeado" in testes

