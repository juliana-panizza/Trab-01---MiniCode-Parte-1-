
import json

import pytest

from agent import MiniCodeAgent
from states import Estado


def test_preparar_registra_erro_sem_expor_mensagem(
    tmp_path, monkeypatch
):
    def gerar_spec_com_erro(tarefa):
        raise RuntimeError(
            "Falha com informação sensível"
        )

    monkeypatch.setattr(
        "agent.gerar_spec",
        gerar_spec_com_erro
    )

    agente = MiniCodeAgent(tmp_path)

    with pytest.raises(RuntimeError):
        agente.preparar("Criar função de exemplo")

    assert agente.maquina.estado == Estado.FAILED

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    erros = [
        evento
        for evento in eventos
        if evento["type"] == "execution_error"
    ]

    assert len(erros) == 1
    assert erros[0]["run_id"] == agente.run_id

    assert erros[0]["data"] == {
        "stage": "spec",
        "error_type": "RuntimeError"
    }

    texto_log = arquivo.read_text(
        encoding="utf-8"
    )

    assert "informação sensível" not in texto_log


def test_preparar_registra_erro_no_plan(
    tmp_path, monkeypatch
):
    spec = {
        "objective": "Criar função de exemplo",
        "requirements": ["Criar função exemplo"],
        "acceptance_criteria": ["Função implementada"]
    }

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )

    def gerar_plan_com_erro(spec, arquivos):
        raise RuntimeError(
            "Falha no planejamento com dado sensível"
        )

    monkeypatch.setattr(
        "agent.gerar_plan",
        gerar_plan_com_erro
    )

    agente = MiniCodeAgent(tmp_path)

    with pytest.raises(RuntimeError):
        agente.preparar("Criar função de exemplo")

    assert agente.maquina.estado == Estado.FAILED

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    erros = [
        evento
        for evento in eventos
        if evento["type"] == "execution_error"
    ]

    assert len(erros) == 1
    assert erros[0]["run_id"] == agente.run_id
    assert erros[0]["data"] == {
        "stage": "plan",
        "error_type": "RuntimeError"
    }

    assert "dado sensível" not in arquivo.read_text(
        encoding="utf-8"
    )


def test_implementacao_registra_erro(
    tmp_path, monkeypatch
):
    spec = {
        "objective": "Criar função de exemplo",
        "requirements": [
            "Criar uma função exemplo"
        ],
        "acceptance_criteria": [
            "Função implementada"
        ]
    }

    plan = {
        "summary": "Implementar função exemplo",
        "steps": [{
            "step": 1,
            "description": "Criar exemplo.py",
            "files": ["exemplo.py"]
        }],
        "tests": [
            "Verificar função exemplo"
        ]
    }

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan
    )

    def implementar_com_erro(*args, **kwargs):
        raise RuntimeError(
            "Falha com informação sensível"
        )

    monkeypatch.setattr(
        "agent.implementar",
        implementar_com_erro
    )

    agente = MiniCodeAgent(tmp_path)

    agente.preparar(
        "Criar uma função de exemplo"
    )

    with pytest.raises(RuntimeError):
        agente.executar_implementacao()

    assert agente.maquina.estado == Estado.FAILED

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    erros = [
        evento
        for evento in eventos
        if evento["type"] == "execution_error"
    ]

    assert len(erros) == 1
    assert erros[0]["run_id"] == agente.run_id

    assert erros[0]["data"] == {
        "stage": "implementation",
        "error_type": "RuntimeError"
    }

    texto_log = arquivo.read_text(
        encoding="utf-8"
    )

    assert "informação sensível" not in texto_log

    # Confere que o relatório final foi gerado.
    relatorio = json.loads(
        (
            tmp_path / ".minicode" / "report.json"
        ).read_text(encoding="utf-8")
    )

    assert relatorio["run_id"] == agente.run_id
    assert relatorio["metrics"]["final_state"] == "FAILED"
    assert relatorio["metrics"]["task_success"] is False


def test_reparo_registra_erro(
    tmp_path, monkeypatch
):
    spec = {
        "objective": "Criar função resposta",
        "requirements": [
            "A função resposta deve retornar 42"
        ],
        "acceptance_criteria": [
            "resposta() retorna 42"
        ]
    }

    plan = {
        "summary": "Implementar função resposta",
        "steps": [{
            "step": 1,
            "description": "Criar codigo.py",
            "files": ["codigo.py"]
        }],
        "tests": [
            "Verificar resposta()"
        ]
    }

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan
    )

    def implementar_com_erro(*args, **kwargs):
        raise RuntimeError(
            "Erro de reparo com informação sensível"
        )

    monkeypatch.setattr(
        "agent.implementar",
        implementar_com_erro
    )

    agente = MiniCodeAgent(tmp_path)
    agente.preparar(
        "Criar função resposta que retorne 42"
    )

    # Simula um ciclo que chegou à reparação.
    agente.maquina.transicionar(Estado.IMPLEMENTING)
    agente.maquina.transicionar(Estado.VERIFYING)

    agente.maquina.registrar_testes(
        executados=True,
        aprovados=False
    )

    agente.maquina.transicionar(Estado.REPAIRING)

    resultado_verificacao = {
        "executed": True,
        "passed": False,
        "exit_code": 1,
        "output": "AssertionError: esperado 42"
    }

    with pytest.raises(
        RuntimeError,
        match="Erro de reparo"
    ):
        agente.executar_reparo(
            resultado_verificacao
        )

    assert agente.maquina.estado == Estado.FAILED

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    erros = [
        evento
        for evento in eventos
        if evento["type"] == "execution_error"
    ]

    assert len(erros) == 1
    assert erros[0]["run_id"] == agente.run_id

    assert erros[0]["data"] == {
        "stage": "repair",
        "error_type": "RuntimeError"
    }

    texto_log = arquivo.read_text(
        encoding="utf-8"
    )

    assert "informação sensível" not in texto_log

    relatorio = json.loads(
        (
            tmp_path / ".minicode" / "report.json"
        ).read_text(encoding="utf-8")
    )

    assert relatorio["run_id"] == agente.run_id
    assert relatorio["metrics"]["final_state"] == "FAILED"
    assert relatorio["metrics"]["task_success"] is False

    
    # Confere que a tentativa foi encerrada.
    reparos = [
        evento["data"]
        for evento in eventos
        if (
            evento["type"] == "repair_attempt"
            and evento.get("run_id") == agente.run_id
        )
    ]

    assert reparos == [
        {"attempt": 1, "status": "started"},
        {"attempt": 1, "status": "failed"}
    ]



def test_verificacao_registra_excecao(
    tmp_path, monkeypatch
):
    spec = {
        "objective": "Criar função resposta",
        "requirements": [
            "A função resposta deve retornar 42"
        ],
        "acceptance_criteria": [
            "resposta() retorna 42"
        ]
    }

    plan = {
        "summary": "Implementar função resposta",
        "steps": [{
            "step": 1,
            "description": "Criar codigo.py",
            "files": ["codigo.py"]
        }],
        "tests": [
            "Verificar resposta()"
        ]
    }

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan
    )

    def verificar_com_erro(*args, **kwargs):
        raise RuntimeError(
            "Erro na verificação com informação sensível"
        )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_com_erro
    )

    agente = MiniCodeAgent(tmp_path)

    agente.preparar(
        "Criar função resposta que retorne 42"
    )

    # Prepara o estado necessário à verificação,
    # sem executar implementação real.
    agente.maquina.transicionar(
        Estado.IMPLEMENTING
    )

    with pytest.raises(
        RuntimeError,
        match="Erro na verificação"
    ):
        agente.executar_verificacao()

    assert agente.maquina.estado == Estado.FAILED

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    erros = [
        evento
        for evento in eventos
        if evento["type"] == "execution_error"
    ]

    assert len(erros) == 1
    assert erros[0]["run_id"] == agente.run_id

    assert erros[0]["data"] == {
        "stage": "verification",
        "error_type": "RuntimeError"
    }

    texto_log = arquivo.read_text(
        encoding="utf-8"
    )

    assert "informação sensível" not in texto_log

    relatorio = json.loads(
        (
            tmp_path / ".minicode" / "report.json"
        ).read_text(encoding="utf-8")
    )

    assert relatorio["run_id"] == agente.run_id
    assert relatorio["metrics"]["final_state"] == "FAILED"
    assert relatorio["metrics"]["task_success"] is False
