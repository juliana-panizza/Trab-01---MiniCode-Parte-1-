
import json

import pytest

from logger import RegistroEventos
from metricas import calcular_metricas
from uuid import uuid4

def test_metricas_sem_eventos(tmp_path):
    resultado = calcular_metricas(tmp_path)

    assert resultado["total_events"] == 0
    assert resultado["tool_calls"] == 0
    assert resultado["final_state"] is None
    assert resultado["task_success"] is False


def test_metricas_execucao_aprovada(tmp_path):
    logger = RegistroEventos(tmp_path)

    logger.registrar_estado("IMPLEMENTING")
    logger.registrar_ferramenta("list_files", True)
    logger.registrar_ferramenta("read_file", True)
    logger.registrar_ferramenta("write_file", True)

    logger.registrar_estado("VERIFYING")
    logger.registrar_ferramenta("run_tests", True)
    logger.registrar_verificacao(True, True)
    logger.registrar_estado("DONE")

    resultado = calcular_metricas(tmp_path)

    assert resultado["total_events"] == 8

    assert resultado["tool_calls"] == 4
    assert resultado["tool_successes"] == 4
    assert resultado["tool_failures"] == 0

    assert resultado["tool_usage"] == {
        "list_files": 1,
        "read_file": 1,
        "write_file": 1,
        "run_tests": 1
    }

    assert resultado["verifications"] == 1
    assert resultado["passed_verifications"] == 1

    assert resultado["repairs_started"] == 0
    assert resultado["final_state"] == "DONE"
    assert resultado["task_success"] is True


def test_metricas_com_reparo_e_falha(tmp_path):
    logger = RegistroEventos(tmp_path)

    logger.registrar_estado("IMPLEMENTING")
    logger.registrar_ferramenta("write_file", True)

    logger.registrar_estado("VERIFYING")
    logger.registrar_ferramenta("run_tests", False)
    logger.registrar_verificacao(True, False)

    logger.registrar_estado("REPAIRING")
    logger.registrar_reparo(1, "started")

    logger.registrar_estado("IMPLEMENTING")
    logger.registrar_ferramenta("write_file", False)

    logger.registrar_estado("VERIFYING")
    logger.registrar_ferramenta("run_tests", False)
    logger.registrar_verificacao(True, False)

    logger.registrar_estado("FAILED")

    resultado = calcular_metricas(tmp_path)

    assert resultado["tool_calls"] == 4
    assert resultado["tool_successes"] == 1
    assert resultado["tool_failures"] == 3

    assert resultado["verifications"] == 2
    assert resultado["passed_verifications"] == 0
    assert resultado["failed_verifications"] == 2

    assert resultado["repairs_started"] == 1
    assert resultado["final_state"] == "FAILED"
    assert resultado["task_success"] is False


def test_metricas_json_invalido(tmp_path):
    pasta = tmp_path / ".minicode"
    pasta.mkdir()

    arquivo = pasta / "events.jsonl"
    arquivo.write_text(
        "isto não é um JSON\n",
        encoding="utf-8"
    )

    with pytest.raises(
        ValueError,
        match="JSON inválido"
    ):
        calcular_metricas(tmp_path)


def test_metricas_rejeita_link_simbolico(
    tmp_path
):
    pasta = tmp_path / ".minicode"
    pasta.mkdir()

    original = tmp_path / "eventos_reais.jsonl"
    original.write_text(
        '{"type":"state_transition",'
        '"data":{"state":"DONE"}}\n',
        encoding="utf-8"
    )

    link = pasta / "events.jsonl"

    try:
        link.symlink_to(original)
    except (OSError, NotImplementedError):
        pytest.skip(
            "Links simbólicos indisponíveis neste ambiente."
        )

    with pytest.raises(
        ValueError,
        match="link simbólico"
    ):
        calcular_metricas(tmp_path)

def test_logger_registra_run_id(tmp_path):
    identificador = str(uuid4())

    logger = RegistroEventos(
        tmp_path,
        run_id=identificador
    )

    logger.registrar_estado("IMPLEMENTING")

    arquivo = tmp_path / ".minicode" / "events.jsonl"
    evento = json.loads(
        arquivo.read_text(encoding="utf-8").splitlines()[0]
    )

    assert evento["run_id"] == identificador


def test_metricas_filtram_execucoes(tmp_path):
    primeira = str(uuid4())
    segunda = str(uuid4())

    logger_primeiro = RegistroEventos(
        tmp_path,
        run_id=primeira
    )

    logger_segundo = RegistroEventos(
        tmp_path,
        run_id=segunda
    )

    logger_primeiro.registrar_estado("IMPLEMENTING")
    logger_primeiro.registrar_ferramenta(
        "write_file", True
    )
    logger_primeiro.registrar_estado("DONE")

    logger_segundo.registrar_estado("IMPLEMENTING")
    logger_segundo.registrar_ferramenta(
        "write_file", False
    )
    logger_segundo.registrar_estado("FAILED")

    metricas_primeiro = calcular_metricas(
        tmp_path,
        run_id=primeira
    )

    metricas_segundo = calcular_metricas(
        tmp_path,
        run_id=segunda
    )

    assert metricas_primeiro["total_events"] == 3
    assert metricas_primeiro["task_success"] is True
    assert metricas_primeiro["tool_successes"] == 1

    assert metricas_segundo["total_events"] == 3
    assert metricas_segundo["task_success"] is False
    assert metricas_segundo["tool_failures"] == 1


def test_logger_rejeita_run_id_invalido(tmp_path):
    with pytest.raises(ValueError):
        RegistroEventos(
            tmp_path,
            run_id="execucao-invalida"
        )
