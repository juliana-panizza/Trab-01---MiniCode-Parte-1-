
import json
from uuid import uuid4

import pytest

from logger import RegistroEventos


def ler_eventos(projeto):
    arquivo = projeto / ".minicode" / "events.jsonl"

    if not arquivo.exists():
        return []

    return [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]


def test_registrar_arquivo_modificado(tmp_path):
    run_id = str(uuid4())

    logger = RegistroEventos(
        tmp_path,
        run_id=run_id
    )

    logger.registrar_ferramenta(
        "write_file",
        True,
        caminho="src/calculadora.py"
    )

    eventos = ler_eventos(tmp_path)

    assert len(eventos) == 1

    assert eventos[0]["run_id"] == run_id
    assert eventos[0]["data"] == {
        "tool": "write_file",
        "success": True,
        "path": "src/calculadora.py"
    }


def test_normalizar_barras_windows(tmp_path):
    logger = RegistroEventos(tmp_path)

    logger.registrar_ferramenta(
        "write_file",
        True,
        caminho=r"src\calculadora.py"
    )

    evento = ler_eventos(tmp_path)[0]

    assert evento["data"]["path"] == "src/calculadora.py"


def test_ferramenta_sem_caminho_continua_funcionando(
    tmp_path
):
    logger = RegistroEventos(tmp_path)

    logger.registrar_ferramenta(
        "list_files",
        True
    )

    evento = ler_eventos(tmp_path)[0]

    assert evento["data"] == {
        "tool": "list_files",
        "success": True
    }


@pytest.mark.parametrize(
    "caminho",
    [
        "../segredo.py",
        "/fora.py",
        "C:/fora.py",
        "",
        "src//arquivo.py",
        "./arquivo.py"
    ]
)
def test_rejeitar_caminhos_invalidos(
    tmp_path, caminho
):
    logger = RegistroEventos(tmp_path)

    with pytest.raises(ValueError):
        logger.registrar_ferramenta(
            "write_file",
            True,
            caminho=caminho
        )

    assert ler_eventos(tmp_path) == []


def test_rejeitar_caminho_em_run_tests(tmp_path):
    logger = RegistroEventos(tmp_path)

    with pytest.raises(ValueError):
        logger.registrar_ferramenta(
            "run_tests",
            True,
            caminho="teste.py"
        )

    assert ler_eventos(tmp_path) == []

