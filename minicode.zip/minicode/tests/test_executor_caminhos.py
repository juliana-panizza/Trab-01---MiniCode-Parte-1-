
import json
from uuid import uuid4

from executor import Executor
from states import Estado, MaquinaEstados


def preparar_executor(tmp_path):
    maquina = MaquinaEstados()

    # Prepara o estado permitido para execução.
    maquina.estado = Estado.IMPLEMENTING
    maquina.run_id = str(uuid4())

    executor = Executor(tmp_path, maquina)

    return executor, maquina


def ler_eventos(projeto):
    arquivo = projeto / ".minicode" / "events.jsonl"

    return [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]


def test_escrita_registra_caminho(tmp_path):
    executor, maquina = preparar_executor(tmp_path)

    executor.executar_acao({
        "action": "write_file",
        "arguments": {
            "caminho": "calculadora.py",
            "conteudo": "def soma(a, b):\n    return a + b\n"
        }
    })

    assert (tmp_path / "calculadora.py").exists()

    eventos = ler_eventos(tmp_path)

    assert len(eventos) == 1

    evento = eventos[0]

    assert evento["type"] == "tool_execution"
    assert evento["run_id"] == maquina.run_id

    assert evento["data"] == {
        "tool": "write_file",
        "success": True,
        "path": "calculadora.py"
    }

    # O conteúdo do código não deve estar no log.
    texto_log = (
        tmp_path / ".minicode" / "events.jsonl"
    ).read_text(encoding="utf-8")

    assert "def soma" not in texto_log


def test_leitura_registra_caminho(tmp_path):
    executor, maquina = preparar_executor(tmp_path)

    (tmp_path / "arquivo.py").write_text(
        "valor = 42\n",
        encoding="utf-8"
    )

    executor.executar_acao({
        "action": "read_file",
        "arguments": {
            "caminho": "arquivo.py"
        }
    })

    eventos = ler_eventos(tmp_path)

    assert len(eventos) == 1
    assert eventos[0]["run_id"] == maquina.run_id

    assert eventos[0]["data"] == {
        "tool": "read_file",
        "success": True,
        "path": "arquivo.py"
    }

