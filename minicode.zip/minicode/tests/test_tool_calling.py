
import json

import pytest

from tool_calling import executar_acao, consultar_projeto
from tools import FerramentasProjeto


def test_executar_list_files(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    (tmp_path / "exemplo.py").write_text(
        "print('teste')",
        encoding="utf-8"
    )

    resultado = executar_acao(
        ferramentas,
        {
            "action": "list_files",
            "arguments": {}
        }
    )

    assert "exemplo.py" in resultado


def test_executar_read_file(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    (tmp_path / "codigo.py").write_text(
        "x = 10",
        encoding="utf-8"
    )

    resultado = executar_acao(
        ferramentas,
        {
            "action": "read_file",
            "arguments": {
                "caminho": "codigo.py"
            }
        }
    )

    assert resultado == "x = 10"


def test_rejeitar_acao_desconhecida(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    with pytest.raises(ValueError):
        executar_acao(
            ferramentas,
            {
                "action": "delete_file",
                "arguments": {
                    "caminho": "codigo.py"
                }
            }
        )


def test_bloquear_leitura_env(tmp_path):
    ferramentas = FerramentasProjeto(tmp_path)

    (tmp_path / ".env").write_text(
        "TOKEN=exemplo",
        encoding="utf-8"
    )

    with pytest.raises(PermissionError):
        executar_acao(
            ferramentas,
            {
                "action": "read_file",
                "arguments": {
                    "caminho": ".env"
                }
            }
        )


def test_consulta_finaliza_corretamente(
    tmp_path, monkeypatch
):
    respostas = [
        {
            "action": "list_files",
            "arguments": {}
        },
        {
            "action": "finish",
            "arguments": {
                "resposta": "Projeto consultado."
            }
        }
    ]

    chamadas = []

    def chat_simulado(mensagens, **kwargs):
        chamadas.append(mensagens)
        return json.dumps(respostas.pop(0))

    monkeypatch.setattr(
        "tool_calling.chat",
        chat_simulado
    )

    resultado = consultar_projeto(
        tmp_path,
        "Liste os arquivos",
        max_passos=3
    )

    assert resultado == "Projeto consultado."
    assert len(chamadas) == 2


def test_limite_de_passos(
    tmp_path, monkeypatch
):
    def chat_simulado(mensagens, **kwargs):
        return json.dumps({
            "action": "list_files",
            "arguments": {}
        })

    monkeypatch.setattr(
        "tool_calling.chat",
        chat_simulado
    )

    with pytest.raises(
        RuntimeError,
        match="Limite de passos"
    ):
        consultar_projeto(
            tmp_path,
            "Liste os arquivos",
            max_passos=2
        )


def test_nao_permitir_escrita(
    tmp_path, monkeypatch
):
    respostas = [
        {
            "action": "write_file",
            "arguments": {
                "caminho": "perigoso.py",
                "conteudo": "print('teste')"
            }
        },
        {
            "action": "finish",
            "arguments": {
                "resposta": "Operação encerrada."
            }
        }
    ]

    def chat_simulado(mensagens, **kwargs):
        return json.dumps(respostas.pop(0))

    monkeypatch.setattr(
        "tool_calling.chat",
        chat_simulado
    )

    consultar_projeto(
        tmp_path,
        "Escreva um arquivo",
        max_passos=3
    )

    assert not (tmp_path / "perigoso.py").exists()
