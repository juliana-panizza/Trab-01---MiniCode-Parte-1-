
import json
from uuid import uuid4

import pytest

from executor import Executor
from states import Estado, MaquinaEstados


def test_executor_registra_erro_sem_expor_mensagem(
    tmp_path
):
    maquina = MaquinaEstados()
    maquina.estado = Estado.IMPLEMENTING
    maquina.run_id = str(uuid4())

    executor = Executor(tmp_path, maquina)

    with pytest.raises(Exception):
        executor.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": "../segredo.py",
                "conteudo": "informacao_sensivel = 123"
            }
        })

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    falhas_ferramenta = [
        evento for evento in eventos
        if evento["type"] == "tool_execution"
    ]

    erros = [
        evento for evento in eventos
        if evento["type"] == "execution_error"
    ]

    assert len(falhas_ferramenta) == 1
    assert len(erros) == 1

    assert falhas_ferramenta[0]["data"] == {
        "tool": "write_file",
        "success": False
    }

    assert erros[0]["run_id"] == maquina.run_id
    assert erros[0]["data"]["stage"] == "implementation"

    texto = arquivo.read_text(encoding="utf-8")

    assert "../segredo.py" not in texto
    assert "informacao_sensivel" not in texto
