
import json

import pytest

from spec import (
    validar_spec,
    gerar_spec,
    salvar_spec
)

from plan import (
    validar_plan,
    gerar_plan,
    salvar_plan
)


@pytest.fixture
def spec_valida():
    return {
        "objective": "Criar uma função de fatorial",
        "requirements": [
            "Receber um inteiro não negativo",
            "Retornar seu fatorial"
        ],
        "acceptance_criteria": [
            "fatorial(0) deve retornar 1",
            "fatorial(5) deve retornar 120"
        ]
    }


@pytest.fixture
def plan_valido():
    return {
        "summary": "Implementar a função de fatorial",
        "steps": [
            {
                "step": 1,
                "description": "Criar a função",
                "files": ["calculadora.py"]
            },
            {
                "step": 2,
                "description": "Criar testes",
                "files": ["test_calculadora.py"]
            }
        ],
        "tests": [
            "Testar fatorial(0)",
            "Testar fatorial(5)"
        ]
    }


# TESTES DA SPEC

def test_spec_valida(spec_valida):
    assert validar_spec(spec_valida) is True


def test_spec_sem_objetivo(spec_valida):
    spec_valida.pop("objective")

    with pytest.raises(ValueError):
        validar_spec(spec_valida)


def test_spec_sem_requisitos(spec_valida):
    spec_valida["requirements"] = []

    with pytest.raises(ValueError):
        validar_spec(spec_valida)


def test_spec_sem_criterios(spec_valida):
    spec_valida["acceptance_criteria"] = []

    with pytest.raises(ValueError):
        validar_spec(spec_valida)


def test_gerar_spec_com_resposta_valida(
    monkeypatch, spec_valida
):
    resposta = json.dumps(spec_valida)

    monkeypatch.setattr(
        "spec.chat",
        lambda mensagens, **kwargs: resposta
    )

    resultado = gerar_spec(
        "Crie uma função de fatorial"
    )

    assert resultado == spec_valida


def test_gerar_spec_com_json_invalido(monkeypatch):
    monkeypatch.setattr(
        "spec.chat",
        lambda mensagens, **kwargs: "Isto não é JSON"
    )

    with pytest.raises(ValueError):
        gerar_spec("Crie uma função")


def test_salvar_spec(tmp_path, spec_valida):
    caminho = salvar_spec(spec_valida, tmp_path)

    assert caminho.exists()

    conteudo = caminho.read_text(encoding="utf-8")

    assert "# Specification" in conteudo
    assert "fatorial(0)" in conteudo


# TESTES DO PLAN

def test_plan_valido(plan_valido):
    assert validar_plan(plan_valido) is True


def test_plan_sem_resumo(plan_valido):
    plan_valido["summary"] = ""

    with pytest.raises(ValueError):
        validar_plan(plan_valido)


def test_plan_sem_passos(plan_valido):
    plan_valido["steps"] = []

    with pytest.raises(ValueError):
        validar_plan(plan_valido)


def test_plan_com_numeracao_incorreta(plan_valido):
    plan_valido["steps"][0]["step"] = 3

    with pytest.raises(ValueError):
        validar_plan(plan_valido)


def test_plan_sem_testes(plan_valido):
    plan_valido["tests"] = []

    with pytest.raises(ValueError):
        validar_plan(plan_valido)


def test_gerar_plan_com_resposta_valida(
    monkeypatch, spec_valida, plan_valido
):
    resposta = json.dumps(plan_valido)

    monkeypatch.setattr(
        "plan.chat",
        lambda mensagens, **kwargs: resposta
    )

    resultado = gerar_plan(
        spec_valida,
        ["calculadora.py", "test_calculadora.py"]
    )

    assert resultado == plan_valido


def test_gerar_plan_com_json_invalido(
    monkeypatch, spec_valida
):
    monkeypatch.setattr(
        "plan.chat",
        lambda mensagens, **kwargs: "Resposta inválida"
    )

    with pytest.raises(ValueError):
        gerar_plan(spec_valida, [])


def test_salvar_plan(tmp_path, plan_valido):
    caminho = salvar_plan(plan_valido, tmp_path)

    assert caminho.exists()

    conteudo = caminho.read_text(encoding="utf-8")

    assert "# Implementation Plan" in conteudo
    assert "calculadora.py" in conteudo
