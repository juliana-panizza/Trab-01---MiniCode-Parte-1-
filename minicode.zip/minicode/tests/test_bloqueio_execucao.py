
from tools import FerramentasProjeto


def test_run_tests_bloqueia_sem_isolamento(
    tmp_path, monkeypatch
):
    pasta_testes = tmp_path / "tests"
    pasta_testes.mkdir()

    # Este arquivo não deve ser executado.
    (pasta_testes / "test_perigoso.py").write_text(
        "from pathlib import Path\n"
        "Path('executado.txt').write_text('executado')\n"
        "def test_exemplo():\n"
        "    assert True\n",
        encoding="utf-8"
    )

    def subprocess_proibido(*args, **kwargs):
        raise AssertionError(
            "subprocess.run não deveria ser chamado."
        )

    # Garante que a implementação não recorra
    # ao subprocess.run do computador.
    monkeypatch.setattr(
        "subprocess.run",
        subprocess_proibido
    )

    ferramentas = FerramentasProjeto(tmp_path)

    resultado = ferramentas.run_tests()

    assert resultado == {
        "executed": False,
        "passed": False,
        "exit_code": None,
        "output": (
            "Execução bloqueada: ambiente "
            "isolado indisponível."
        )
    }

    assert not (tmp_path / "executado.txt").exists()
