
import json
from uuid import uuid4

import pytest

from logger import RegistroEventos
from relatorio import gerar_relatorio


def test_gerar_relatorio_aprovado(tmp_path):
    run_id = str(uuid4())

    logger = RegistroEventos(
        tmp_path,
        run_id=run_id
    )

    logger.registrar_estado("IMPLEMENTING")
    logger.registrar_ferramenta(
        "write_file", True
    )
    logger.registrar_estado("VERIFYING")
    logger.registrar_ferramenta(
        "run_tests", True
    )
    logger.registrar_verificacao(True, True)
    logger.registrar_estado("DONE")

    relatorio = gerar_relatorio(
        tmp_path,
        run_id
    )

    arquivo = (
        tmp_path / ".minicode" / "report.json"
    )

    assert arquivo.exists()

    salvo = json.loads(
        arquivo.read_text(encoding="utf-8")
    )

    assert salvo == relatorio
    assert salvo["run_id"] == run_id
    assert "generated_at" in salvo

    assert salvo["metrics"]["final_state"] == "DONE"
    assert salvo["metrics"]["task_success"] is True
    assert salvo["metrics"]["tool_calls"] == 2


def test_relatorio_filtra_run_id(tmp_path):
    primeiro = str(uuid4())
    segundo = str(uuid4())

    logger_a = RegistroEventos(
        tmp_path, run_id=primeiro
    )
    logger_b = RegistroEventos(
        tmp_path, run_id=segundo
    )

    logger_a.registrar_estado("IMPLEMENTING")
    logger_a.registrar_ferramenta("write_file", True)
    logger_a.registrar_estado("DONE")

    logger_b.registrar_estado("IMPLEMENTING")
    logger_b.registrar_ferramenta("write_file", False)
    logger_b.registrar_estado("FAILED")

    relatorio = gerar_relatorio(
        tmp_path,
        primeiro
    )

    metricas = relatorio["metrics"]

    assert relatorio["run_id"] == primeiro
    assert metricas["total_events"] == 3
    assert metricas["tool_successes"] == 1
    assert metricas["tool_failures"] == 0
    assert metricas["final_state"] == "DONE"


def test_relatorio_rejeita_run_id_invalido(tmp_path):
    with pytest.raises(
        ValueError,
        match="run_id inválido"
    ):
        gerar_relatorio(
            tmp_path,
            "identificador-invalido"
        )

    assert not (
        tmp_path / ".minicode" / "report.json"
    ).exists()


def test_relatorio_sem_eventos_da_execucao(tmp_path):
    run_id = str(uuid4())

    with pytest.raises(
        ValueError,
        match="Não existem eventos"
    ):
        gerar_relatorio(
            tmp_path,
            run_id
        )

    assert not (
        tmp_path / ".minicode" / "report.json"
    ).exists()
