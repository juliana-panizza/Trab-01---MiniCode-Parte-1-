
import pytest

from executor import Executor
from states import Estado, MaquinaEstados


@pytest.fixture
def executor_preparado(tmp_path):
    maquina = MaquinaEstados()

    spec = {
        "objective": "Criar uma função",
        "requirements": [
            "Implementar uma função Python"
        ],
        "acceptance_criteria": [
            "A função deve retornar o valor esperado"
        ]
    }

    plan = {
        "summary": "Implementar e testar a função",
        "steps": [
            {
                "step": 1,
                "description": "Criar codigo.py",
                "files": ["codigo.py"]
            }
        ],
        "tests": [
            "Verificar o retorno da função"
        ]
    }

    maquina.registrar_spec(spec)
    maquina.registrar_plan(plan)
    maquina.transicionar(Estado.IMPLEMENTING)

    return Executor(tmp_path, maquina)


def test_escrever_arquivo(executor_preparado, tmp_path):
    resultado = executor_preparado.executar_acao({
        "action": "write_file",
        "arguments": {
            "caminho": "codigo.py",
            "conteudo": "def resposta(): return 42"
        }
    })

    assert resultado["success"] is True

    assert (
        tmp_path / "codigo.py"
    ).read_text(encoding="utf-8") == (
        "def resposta(): return 42"
    )


def test_ler_arquivo(executor_preparado, tmp_path):
    (tmp_path / "codigo.py").write_text(
        "x = 10",
        encoding="utf-8"
    )

    resultado = executor_preparado.executar_acao({
        "action": "read_file",
        "arguments": {
            "caminho": "codigo.py"
        }
    })

    assert resultado == "x = 10"


def test_listar_arquivos(executor_preparado, tmp_path):
    (tmp_path / "codigo.py").write_text(
        "x = 1",
        encoding="utf-8"
    )

    resultado = executor_preparado.executar_acao({
        "action": "list_files",
        "arguments": {}
    })

    assert "codigo.py" in resultado


def test_bloquear_escrita_sem_implementing(tmp_path):
    maquina = MaquinaEstados()
    executor = Executor(tmp_path, maquina)

    with pytest.raises(RuntimeError):
        executor.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": "codigo.py",
                "conteudo": "print('teste')"
            }
        })

    assert not (tmp_path / "codigo.py").exists()


def test_bloquear_arquivo_protegido(
    executor_preparado, tmp_path
):
    with pytest.raises(PermissionError):
        executor_preparado.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": ".env",
                "conteudo": "TOKEN=segredo"
            }
        })

    assert not (tmp_path / ".env").exists()


def test_bloquear_arquivo_fora_do_projeto(
    executor_preparado, tmp_path
):
    with pytest.raises(PermissionError):
        executor_preparado.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": "../fora.py",
                "conteudo": "print('teste')"
            }
        })


def test_bloquear_acao_desconhecida(
    executor_preparado
):
    with pytest.raises(ValueError):
        executor_preparado.executar_acao({
            "action": "delete_file",
            "arguments": {
                "caminho": "codigo.py"
            }
        })


def test_bloquear_extensao_nao_permitida(
    executor_preparado, tmp_path
):
    with pytest.raises(PermissionError):
        executor_preparado.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": "script.bat",
                "conteudo": "echo teste"
            }
        })

    assert not (tmp_path / "script.bat").exists()


def test_bloquear_conteudo_muito_grande(
    executor_preparado, tmp_path
):
    conteudo = "a" * 50_001

    with pytest.raises(ValueError):
        executor_preparado.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": "grande.py",
                "conteudo": conteudo
            }
        })

    assert not (tmp_path / "grande.py").exists()


def test_registrar_escrita_bem_sucedida(
    executor_preparado, tmp_path
):
    import json

    executor_preparado.executar_acao({
        "action": "write_file",
        "arguments": {
            "caminho": "codigo.py",
            "conteudo": "x = 42"
        }
    })

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    assert eventos[-1]["type"] == "tool_execution"
    
    assert eventos[-1]["data"] == {
        "tool": "write_file",
        "success": True,
        "path": "codigo.py"
    }



def test_registrar_leitura_bem_sucedida(
    executor_preparado, tmp_path
):
    import json

    (tmp_path / "codigo.py").write_text(
        "x = 10",
        encoding="utf-8"
    )

    executor_preparado.executar_acao({
        "action": "read_file",
        "arguments": {
            "caminho": "codigo.py"
        }
    })

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    
    assert eventos[-1]["data"] == {
        "tool": "read_file",
        "success": True,
        "path": "codigo.py"
    }


def test_registrar_escrita_bloqueada(
    executor_preparado, tmp_path
):
    import json

    with pytest.raises(PermissionError):
        executor_preparado.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": ".env",
                "conteudo": "TOKEN=exemplo"
            }
        })

    arquivo = tmp_path / ".minicode" / "events.jsonl"

    eventos = [
        json.loads(linha)
        for linha in arquivo.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    
    assert len(eventos) == 2

    # Primeiro evento: tentativa de escrita bloqueada.
    assert eventos[-2]["type"] == "tool_execution"

    assert eventos[-2]["data"] == {
        "tool": "write_file",
        "success": False
    }

    # Segundo evento: categoria do erro ocorrido.
    assert eventos[-1]["type"] == "execution_error"

    assert eventos[-1]["data"] == {
        "stage": "implementation",
        "error_type": "PermissionError"
    }

    # Nenhuma informação sensível deve aparecer no log.
    texto_log = arquivo.read_text(encoding="utf-8")

    assert "TOKEN=exemplo" not in texto_log
    assert ".env" not in texto_log


    assert not (tmp_path / ".env").exists()
