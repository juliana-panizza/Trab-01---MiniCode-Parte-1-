
import json
import pytest

from agent import MiniCodeAgent
from states import Estado


def test_fluxo_completo_simulado(tmp_path, monkeypatch):
    """
    Testa TASK -> SPEC -> PLAN -> IMPLEMENTING
    -> VERIFYING -> DONE.

    Simula a LLM e os resultados do pytest.
    Usa o executor real para gravar um arquivo
    apenas dentro do diretório temporário.
    """

    projeto = tmp_path / "projeto"
    projeto.mkdir()

    tarefa = (
        "Implementar uma função fatorial(n) "
        "em calculadora.py."
    )

    spec = {
        "objective": "Implementar fatorial",
        "requirements": [
            "Criar função fatorial(n)",
            "Aceitar inteiros não negativos"
        ],
        "acceptance_criteria": [
            "fatorial(0) == 1",
            "fatorial(5) == 120"
        ]
    }

    plan = {
        "summary": "Implementar função fatorial",
        "steps": [
            {
                "step": 1,
                "description": "Criar função fatorial",
                "files": ["calculadora.py"]
            }
        ],
        "tests": [
            "Verificar fatorial(0) e fatorial(5)"
        ]
    }

    # Simula a geração da SPEC e do PLAN.
    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan
    )

    chamadas_implementador = []

    # A LLM é simulada, mas a escrita usa
    # o Executor real.
    def implementar_simulado(
        executor,
        spec,
        plan,
        max_passos=8,
        feedback_testes=None
    ):
        chamadas_implementador.append(feedback_testes)

        executor.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": "calculadora.py",
                "conteudo": (
                    "def fatorial(n):\n"
                    "    if n < 0:\n"
                    "        raise ValueError('n negativo')\n"
                    "    resultado = 1\n"
                    "    for i in range(2, n + 1):\n"
                    "        resultado *= i\n"
                    "    return resultado\n"
                )
            }
        })

        return {
            "finished": True,
            "summary": "Fatorial implementado.",
            "actions": [],
            "writes": 1
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    # Não executa o código gerado.
    def verificar_simulado(diretorio, maquina):
        maquina.registrar_testes(
            executados=True,
            aprovados=True
        )

        return {
            "executed": True,
            "passed": True,
            "exit_code": 0,
            "output": "2 passed (simulado)"
        }

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    # 1. Recebe a tarefa, gera SPEC e PLAN.
    agente = MiniCodeAgent(projeto)

    preparacao = agente.preparar(tarefa)

    assert preparacao["status"] == "prepared"
    assert agente.maquina.estado == Estado.PLANNED

    # 2. Executa o ciclo até o estado final.
    resultado = agente.executar_ciclo(
        max_reparos=1
    )

    assert resultado["status"] == "DONE"
    assert resultado["repairs"] == 0
    assert agente.maquina.estado == Estado.DONE

    # 3. Confere que o executor escreveu o código.
    arquivo_codigo = projeto / "calculadora.py"

    assert arquivo_codigo.exists()
    assert "def fatorial(n)" in arquivo_codigo.read_text(
        encoding="utf-8"
    )

    # 4. Confere o estado persistido.
    estado_salvo = json.loads(
        (projeto / ".minicode" / "state.json").read_text(
            encoding="utf-8"
        )
    )

    assert estado_salvo["state"] == "DONE"

    # 5. Confere os eventos registrados.
    arquivo_eventos = (
        projeto / ".minicode" / "events.jsonl"
    )

    eventos = [
        json.loads(linha)
        for linha in arquivo_eventos.read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    estados = [
        evento["data"]["state"]
        for evento in eventos
        if evento["type"] == "state_transition"
    ]

    assert "PLANNED" in estados
    assert "IMPLEMENTING" in estados
    assert "VERIFYING" in estados
    assert "DONE" in estados

    # 6. Confere o relatório final.
    relatorio = json.loads(
        (projeto / ".minicode" / "report.json").read_text(
            encoding="utf-8"
        )
    )

    assert relatorio["run_id"] == agente.run_id
    assert relatorio["metrics"]["task_success"] is True
    assert relatorio["metrics"]["final_state"] == "DONE"

    assert relatorio["metrics"]["tool_usage"][
        "write_file"
    ] == 1

    assert relatorio["metrics"]["verifications"] == 1

    # Não houve tentativa de reparação.
    assert len(chamadas_implementador) == 1
    assert chamadas_implementador[0] is None


def test_fluxo_completo_com_reparo(
    tmp_path, monkeypatch
):
    """
    Simula uma falha inicial, uma correção
    e uma nova verificação aprovada.

    Não consulta a API nem executa o código criado.
    """

    projeto = tmp_path / "projeto"
    projeto.mkdir()

    spec = {
        "objective": "Criar função resposta",
        "requirements": [
            "A função resposta deve retornar 42"
        ],
        "acceptance_criteria": [
            "resposta() retorna 42"
        ]
    }

    plan = {
        "summary": "Implementar e verificar resposta",
        "steps": [{
            "step": 1,
            "description": "Criar codigo.py",
            "files": ["codigo.py"]
        }],
        "tests": [
            "Verificar o retorno da função"
        ]
    }

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan
    )

    feedbacks = []
    numero_verificacoes = [0]

    def implementar_simulado(
        executor,
        spec,
        plan,
        max_passos=8,
        feedback_testes=None
    ):
        feedbacks.append(feedback_testes)

        if feedback_testes is None:
            # Primeira implementação: incorreta.
            conteudo = (
                "def resposta():\n"
                "    return 0\n"
            )
        else:
            # Reparo: recebe o erro da verificação.
            assert feedback_testes["executed"] is True
            assert feedback_testes["passed"] is False
            assert "esperado 42" in feedback_testes["output"]

            conteudo = (
                "def resposta():\n"
                "    return 42\n"
            )

        executor.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": "codigo.py",
                "conteudo": conteudo
            }
        })

        return {
            "finished": True,
            "summary": "Implementação concluída.",
            "actions": [],
            "writes": 1
        }

    def verificar_simulado(diretorio, maquina):
        numero_verificacoes[0] += 1

        # Primeira verificação reprova;
        # segunda verificação aprova.
        passou = numero_verificacoes[0] == 2

        resultado = {
            "executed": True,
            "passed": passou,
            "exit_code": 0 if passou else 1,
            "output": (
                "1 passed (simulado)"
                if passou
                else "AssertionError: esperado 42"
            )
        }

        maquina.registrar_testes(
            executados=True,
            aprovados=passou
        )

        return resultado

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    # Inicia a tarefa desde RECEIVED.
    agente = MiniCodeAgent(projeto)

    preparacao = agente.preparar(
        "Criar função resposta que retorne 42"
    )

    assert preparacao["status"] == "prepared"

    # Executa implementação, verificação,
    # reparação e segunda verificação.
    resultado = agente.executar_ciclo(
        max_reparos=1
    )

    assert resultado["status"] == "DONE"
    assert resultado["repairs"] == 1
    assert agente.maquina.estado == Estado.DONE

    # Duas implementações e duas verificações.
    assert len(feedbacks) == 2
    assert feedbacks[0] is None
    assert feedbacks[1]["passed"] is False
    assert numero_verificacoes[0] == 2

    # O arquivo foi corrigido pelo executor real.
    arquivo = projeto / "codigo.py"

    assert arquivo.read_text(
        encoding="utf-8"
    ) == (
        "def resposta():\n"
        "    return 42\n"
    )

    # Confere a sequência de estados registrada.
    eventos = [
        json.loads(linha)
        for linha in (
            projeto / ".minicode" / "events.jsonl"
        ).read_text(
            encoding="utf-8"
        ).splitlines()
    ]

    estados = [
        evento["data"]["state"]
        for evento in eventos
        if evento["type"] == "state_transition"
        and evento.get("run_id") == agente.run_id
    ]

    assert estados[-5:] == [
        "VERIFYING",
        "REPAIRING",
        "IMPLEMENTING",
        "VERIFYING",
        "DONE"
    ]

    # Confere o relatório final.
    relatorio = json.loads(
        (
            projeto / ".minicode" / "report.json"
        ).read_text(encoding="utf-8")
    )

    metricas = relatorio["metrics"]

    assert relatorio["run_id"] == agente.run_id
    assert metricas["final_state"] == "DONE"
    assert metricas["task_success"] is True

    assert metricas["verifications"] == 2
    assert metricas["passed_verifications"] == 1
    assert metricas["failed_verifications"] == 1
    assert metricas["repairs_started"] == 1
    assert metricas["tool_usage"]["write_file"] == 2


def test_fluxo_completo_falha_definitiva(
    tmp_path, monkeypatch
):
    """
    Simula implementação e reparo que falham.

    Verifica o limite de reparos, os estados,
    os eventos e o relatório final.

    Não chama a API nem executa código gerado.
    """

    projeto = tmp_path / "projeto"
    projeto.mkdir()

    spec = {
        "objective": "Criar função resposta",
        "requirements": [
            "A função resposta deve retornar 42"
        ],
        "acceptance_criteria": [
            "resposta() retorna 42"
        ]
    }

    plan = {
        "summary": "Implementar e testar resposta",
        "steps": [{
            "step": 1,
            "description": "Criar codigo.py",
            "files": ["codigo.py"]
        }],
        "tests": [
            "Verificar resposta()"
        ]
    }

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan
    )

    implementacoes = []
    verificacoes = []

    def implementar_simulado(
        executor,
        spec,
        plan,
        max_passos=8,
        feedback_testes=None
    ):
        implementacoes.append(feedback_testes)

        # As duas tentativas produzem código incorreto.
        executor.executar_acao({
            "action": "write_file",
            "arguments": {
                "caminho": "codigo.py",
                "conteudo": (
                    "def resposta():\n"
                    "    return 0\n"
                )
            }
        })

        return {
            "finished": True,
            "summary": "Tentativa concluída.",
            "actions": [],
            "writes": 1
        }

    def verificar_simulado(diretorio, maquina):
        verificacoes.append("falhou")

        maquina.registrar_testes(
            executados=True,
            aprovados=False
        )

        return {
            "executed": True,
            "passed": False,
            "exit_code": 1,
            "output": "AssertionError: esperado 42"
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    agente = MiniCodeAgent(projeto)

    preparacao = agente.preparar(
        "Criar função resposta que retorne 42"
    )

    assert preparacao["status"] == "prepared"

    resultado = agente.executar_ciclo(
        max_reparos=1
    )

    # O ciclo termina sem sucesso.
    assert resultado["status"] == "FAILED"
    assert resultado["repairs"] == 1
    assert agente.maquina.estado == Estado.FAILED

    # Houve uma implementação inicial e um reparo.
    assert len(implementacoes) == 2
    assert implementacoes[0] is None

    # O reparo recebeu o resultado da falha.
    assert implementacoes[1]["executed"] is True
    assert implementacoes[1]["passed"] is False
    assert "esperado 42" in implementacoes[1]["output"]

    # Houve exatamente duas verificações.
    assert len(verificacoes) == 2

    # O código continua incorreto.
    arquivo = projeto / "codigo.py"

    assert arquivo.read_text(
        encoding="utf-8"
    ) == (
        "def resposta():\n"
        "    return 0\n"
    )

    # Confere o estado persistido.
    estado_salvo = json.loads(
        (
            projeto / ".minicode" / "state.json"
        ).read_text(encoding="utf-8")
    )

    assert estado_salvo["state"] == "FAILED"

    # Confere o histórico de estados registrado.
    eventos = [
        json.loads(linha)
        for linha in (
            projeto / ".minicode" / "events.jsonl"
        ).read_text(encoding="utf-8").splitlines()
    ]

    estados = [
        evento["data"]["state"]
        for evento in eventos
        if (
            evento["type"] == "state_transition"
            and evento.get("run_id") == agente.run_id
        )
    ]

    
    assert estados[-6:] == [
        "VERIFYING",
        "REPAIRING",
        "IMPLEMENTING",
        "VERIFYING",
        "REPAIRING",
        "FAILED"
    ]


    # Confere o relatório final.
    relatorio = json.loads(
        (
            projeto / ".minicode" / "report.json"
        ).read_text(encoding="utf-8")
    )

    metricas = relatorio["metrics"]

    assert relatorio["run_id"] == agente.run_id
    assert metricas["final_state"] == "FAILED"
    assert metricas["task_success"] is False

    assert metricas["verifications"] == 2
    assert metricas["passed_verifications"] == 0
    assert metricas["failed_verifications"] == 2
    assert metricas["repairs_started"] == 1
    assert metricas["tool_usage"]["write_file"] == 2

    
    # Confere o histórico da tentativa de reparação.
    reparos = [
        evento["data"]
        for evento in eventos
        if (
            evento["type"] == "repair_attempt"
            and evento.get("run_id") == agente.run_id
        )
    ]

    assert reparos == [
        {"attempt": 1, "status": "started"},
        {"attempt": 1, "status": "failed"}
    ]



def test_reparo_registra_inicio_e_resultado(
    tmp_path, monkeypatch
):
    spec = {
        "objective": "Criar função resposta",
        "requirements": ["Retornar 42"],
        "acceptance_criteria": ["resposta() == 42"]
    }

    plan = {
        "summary": "Implementar resposta",
        "steps": [{
            "step": 1,
            "description": "Criar codigo.py",
            "files": ["codigo.py"]
        }],
        "tests": ["Verificar resposta()"]
    }

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan
    )

    def implementar_simulado(
        executor,
        spec,
        plan,
        max_passos=8,
        feedback_testes=None
    ):
        return {
            "finished": True,
            "summary": "Implementação simulada.",
            "actions": [],
            "writes": 0
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    verificacoes = [0]

    def verificar_simulado(diretorio, maquina):
        verificacoes[0] += 1

        passou = verificacoes[0] == 2

        maquina.registrar_testes(
            executados=True,
            aprovados=passou
        )

        return {
            "executed": True,
            "passed": passou,
            "exit_code": 0 if passou else 1,
            "output": "Resultado simulado"
        }

    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    agente = MiniCodeAgent(tmp_path)
    agente.preparar("Criar função resposta")

    resultado = agente.executar_ciclo(max_reparos=1)

    assert resultado["status"] == "DONE"
    assert resultado["repairs"] == 1

    eventos = [
        json.loads(linha)
        for linha in (
            tmp_path / ".minicode" / "events.jsonl"
        ).read_text(encoding="utf-8").splitlines()
    ]

    reparos = [
        evento["data"]
        for evento in eventos
        if (
            evento["type"] == "repair_attempt"
            and evento.get("run_id") == agente.run_id
        )
    ]

    assert reparos == [
        {"attempt": 1, "status": "started"},
        {"attempt": 1, "status": "passed"}
    ]


@pytest.mark.parametrize(
    "limite",
    [0, 1, 2]
)
def test_ciclo_respeita_limite_de_reparos(
    tmp_path, monkeypatch, limite
):
    spec = {
        "objective": "Criar função resposta",
        "requirements": ["Retornar 42"],
        "acceptance_criteria": ["resposta() == 42"]
    }

    plan = {
        "summary": "Implementar função resposta",
        "steps": [{
            "step": 1,
            "description": "Criar codigo.py",
            "files": ["codigo.py"]
        }],
        "tests": ["Verificar resposta()"]
    }

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )
    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan
    )

    implementacoes = []
    verificacoes = []

    def implementar_simulado(
        executor, spec, plan,
        max_passos=8, feedback_testes=None
    ):
        implementacoes.append(feedback_testes)

        return {
            "finished": True,
            "summary": "Tentativa simulada.",
            "actions": [],
            "writes": 0
        }

    def verificar_simulado(diretorio, maquina):
        verificacoes.append(True)

        maquina.registrar_testes(
            executados=True,
            aprovados=False
        )

        return {
            "executed": True,
            "passed": False,
            "exit_code": 1,
            "output": "Falha simulada"
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )
    monkeypatch.setattr(
        "agent.verificar_projeto",
        verificar_simulado
    )

    agente = MiniCodeAgent(tmp_path)
    agente.preparar("Criar função resposta")

    resultado = agente.executar_ciclo(
        max_reparos=limite
    )

    assert resultado["status"] == "FAILED"
    assert resultado["repairs"] == limite
    assert agente.maquina.estado == Estado.FAILED

    # Uma implementação inicial + reparos permitidos.
    assert len(implementacoes) == 1 + limite
    assert len(verificacoes) == 1 + limite

    # O contador interno deve acompanhar
    # somente as reparações realmente iniciadas.
    assert agente.maquina.tentativas_reparo == limite

    eventos = [
        json.loads(linha)
        for linha in (
            tmp_path / ".minicode" / "events.jsonl"
        ).read_text(encoding="utf-8").splitlines()
    ]

    reparos_iniciados = [
        evento["data"]["attempt"]
        for evento in eventos
        if (
            evento["type"] == "repair_attempt"
            and evento.get("run_id") == agente.run_id
            and evento["data"]["status"] == "started"
        )
    ]

    assert reparos_iniciados == list(
        range(1, limite + 1)
    )

    relatorio = json.loads(
        (
            tmp_path / ".minicode" / "report.json"
        ).read_text(encoding="utf-8")
    )

    assert relatorio["metrics"]["repairs_started"] == limite
    assert relatorio["metrics"]["verifications"] == (
        1 + limite
    )

    
def test_ciclo_bloqueado_sem_isolamento(
    tmp_path, monkeypatch
):
    from pathlib import Path

    spec = {
        "objective": "Criar função exemplo",
        "requirements": ["Implementar exemplo"],
        "acceptance_criteria": ["Passar nos testes"]
    }

    plan = {
        "summary": "Criar exemplo.py",
        "steps": [{
            "step": 1,
            "description": "Implementar exemplo",
            "files": ["exemplo.py"]
        }],
        "tests": ["Executar pytest"]
    }

    monkeypatch.setattr(
        "agent.gerar_spec",
        lambda tarefa: spec
    )

    monkeypatch.setattr(
        "agent.gerar_plan",
        lambda spec, arquivos: plan
    )

    def implementar_simulado(
        executor, spec, plan,
        max_passos=8, feedback_testes=None
    ):
        return {
            "finished": True,
            "summary": "Implementação simulada.",
            "actions": [],
            "writes": 0
        }

    monkeypatch.setattr(
        "agent.implementar",
        implementar_simulado
    )

    # A pasta tests existe, mas a execução real
    # deve ser bloqueada pela ferramenta.
    pasta_testes = tmp_path / "tests"
    pasta_testes.mkdir()

    (pasta_testes / "test_exemplo.py").write_text(
        "def test_exemplo():\n"
        "    assert True\n",
        encoding="utf-8"
    )

    agente = MiniCodeAgent(tmp_path)
    agente.preparar("Criar função exemplo")

    resultado = agente.executar_ciclo(
        max_reparos=2
    )

    assert resultado["status"] == "FAILED"
    assert resultado["repairs"] == 0

    assert agente.maquina.estado == Estado.FAILED
    assert agente.maquina.testes_executados is False
    assert agente.maquina.tentativas_reparo == 0

    eventos = [
        json.loads(linha)
        for linha in (
            tmp_path / ".minicode" / "events.jsonl"
        ).read_text(encoding="utf-8").splitlines()
    ]

    reparos_iniciados = [
        evento
        for evento in eventos
        if (
            evento.get("run_id") == agente.run_id
            and evento["type"] == "repair_attempt"
            and evento["data"]["status"] == "started"
        )
    ]

    assert reparos_iniciados == []

    relatorio = json.loads(
        (
            tmp_path / ".minicode" / "report.json"
        ).read_text(encoding="utf-8")
    )

    assert relatorio["metrics"]["final_state"] == "FAILED"
    assert relatorio["metrics"]["repairs_started"] == 0

