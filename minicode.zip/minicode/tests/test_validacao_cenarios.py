
from pathlib import Path

import pytest

from preparador_avaliacao import preparar_cenarios


@pytest.fixture
def projetos_avaliacao(tmp_path):
    base = tmp_path / "avaliacao"
    projetos = preparar_cenarios(base)

    return {
        projeto["id"]: projeto
        for projeto in projetos
    }


def test_c04_contem_bug_intencional(projetos_avaliacao):
    c04 = projetos_avaliacao["C04"]

    codigo = Path(
        c04["project_dir"], "desconto.py"
    ).read_text(encoding="utf-8")

    assert "def aplicar_desconto(preco, percentual):" in codigo
    assert "return preco - percentual" in codigo

    # Não pode começar com a solução correta.
    assert "percentual / 100" not in codigo


def test_c05_contem_api_original(projetos_avaliacao):
    c05 = projetos_avaliacao["C05"]

    codigo = Path(
        c05["project_dir"], "saudacao.py"
    ).read_text(encoding="utf-8")

    assert "def saudar(nome):" in codigo
    assert 'return f"Olá, {nome}!"' in codigo

    # O parâmetro novo ainda não foi implementado.
    assert "formal" not in codigo


def test_aceitacao_c04_cobre_casos_essenciais(
    projetos_avaliacao
):
    c04 = projetos_avaliacao["C04"]

    testes = Path(
        c04["acceptance_tests"]
    ).read_text(encoding="utf-8")

    assert "aplicar_desconto(100, 10)" in testes
    assert "aplicar_desconto(80, 0)" in testes
    assert "aplicar_desconto(200, 50)" in testes
    assert "aplicar_desconto(75, 100)" in testes


def test_aceitacao_c05_exige_compatibilidade(
    projetos_avaliacao
):
    c05 = projetos_avaliacao["C05"]

    testes = Path(
        c05["acceptance_tests"]
    ).read_text(encoding="utf-8")

    assert 'saudar("Ana")' in testes
    assert 'saudar("Ana", False)' in testes
    assert 'saudar("Ana", True)' in testes
    assert "formal=True" in testes
