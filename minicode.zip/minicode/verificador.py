
from states import Estado
from tools import FerramentasProjeto
from logger import RegistroEventos


def verificar_projeto(diretorio_projeto, maquina):
    """
    Executa os testes durante VERIFYING.

    Registra a chamada de run_tests e seu resultado,
    sem armazenar a saída completa do pytest.
    """

    if maquina.estado != Estado.VERIFYING:
        raise RuntimeError(
            "A verificação exige o estado VERIFYING."
        )

    ferramentas = FerramentasProjeto(diretorio_projeto)
    logger = RegistroEventos(
        diretorio_projeto,
        run_id=getattr(maquina, "run_id", None)
    )

    try:
        resultado = ferramentas.run_tests()
    except Exception:
        logger.registrar_ferramenta(
            "run_tests",
            False
        )
        raise

    logger.registrar_ferramenta(
        "run_tests",
        resultado["executed"] and resultado["passed"]
    )

    maquina.registrar_testes(
        executados=resultado["executed"],
        aprovados=resultado["passed"]
    )

    return resultado
