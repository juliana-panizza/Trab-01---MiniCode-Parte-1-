
from pathlib import Path

from aceitacao import obter_testes_aceitacao
from cenarios import CENARIOS, validar_cenario


def preparar_cenarios(diretorio_base):
    """
    Prepara projetos e testes independentes
    para a avaliação do MiniCode.

    Não executa código nem consulta a LLM.
    Não sobrescreve cenários existentes.
    """

    base = Path(diretorio_base).resolve()

    # Evita modificar uma avaliação anterior.
    if base.exists():
        raise FileExistsError(
            "O diretório de avaliação já existe."
        )

    # Valida tudo antes de criar os diretórios.
    ids = set()

    for cenario in CENARIOS:
        validar_cenario(cenario)

        identificador = cenario["id"]

        if identificador in ids:
            raise ValueError(
                "Identificador de cenário duplicado."
            )

        if not (
            identificador.startswith("C")
            and identificador[1:].isdigit()
        ):
            raise ValueError(
                "Identificador de cenário inválido."
            )

        ids.add(identificador)

        if (
            Path(cenario["target_file"]).name
            != cenario["target_file"]
        ):
            raise ValueError(
                "Arquivo-alvo deve estar na raiz "
                "do projeto."
            )

        obter_testes_aceitacao(identificador)

    base.mkdir(parents=True)

    projetos = []

    for cenario in CENARIOS:
        identificador = cenario["id"]

        pasta_cenario = base / identificador
        projeto = pasta_cenario / "projeto"
        avaliacao = pasta_cenario / "avaliacao"

        projeto.mkdir(parents=True)
        avaliacao.mkdir(parents=True)

        
        arquivo_alvo = (
            projeto / cenario["target_file"]
        )

        
        if identificador == "C04":
            conteudo_inicial = (
                "def aplicar_desconto(preco, percentual):\n"
                "    return preco - percentual\n"
            )
        elif identificador == "C05":
            conteudo_inicial = (
                "def saudar(nome):\n"
                '    return f"Olá, {nome}!"\n'
            )
        else:
            conteudo_inicial = (
                "# Arquivo inicial para implementação.\n"
            )


        arquivo_alvo.write_text(
            conteudo_inicial,
            encoding="utf-8"
        )


        arquivo_testes = (
            avaliacao / "test_aceitacao.py"
        )

        arquivo_testes.write_text(
            obter_testes_aceitacao(identificador),
            encoding="utf-8"
        )

        projetos.append({
            "id": identificador,
            "task": cenario["task"],
            "project_dir": str(projeto),
            "acceptance_tests": str(arquivo_testes)
        })

    return projetos

