
import json
import os
import tempfile

from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

from metricas import calcular_metricas


def gerar_relatorio(diretorio_projeto, run_id):
    """
    Gera .minicode/report.json com as métricas
    de uma única execução.

    Não consulta a LLM nem executa código.
    """

    try:
        identificador = str(UUID(run_id))
    except (ValueError, TypeError, AttributeError):
        raise ValueError("run_id inválido.")

    raiz = Path(diretorio_projeto).resolve()

    if not raiz.is_dir():
        raise ValueError(
            "O diretório do projeto não existe."
        )

    pasta = raiz / ".minicode"

    if pasta.is_symlink():
        raise PermissionError(
            "A pasta .minicode não pode ser um link simbólico."
        )

    pasta.mkdir(exist_ok=True)

    destino = pasta / "report.json"

    if destino.is_symlink():
        raise PermissionError(
            "O relatório não pode ser um link simbólico."
        )

    metricas = calcular_metricas(
        raiz,
        run_id=identificador
    )

    if metricas["total_events"] == 0:
        raise ValueError(
            "Não existem eventos para esse run_id."
        )

    relatorio = {
        "run_id": identificador,
        "generated_at": datetime.now(
            timezone.utc
        ).isoformat(),
        "metrics": metricas
    }

    # Grava primeiro em um arquivo temporário.
    # Depois substitui report.json.
    temporario = None

    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=pasta,
            prefix=".report_",
            suffix=".tmp",
            delete=False
        ) as arquivo:
            temporario = Path(arquivo.name)

            json.dump(
                relatorio,
                arquivo,
                ensure_ascii=False,
                indent=2
            )

        os.replace(temporario, destino)

    finally:
        if temporario is not None:
            temporario.unlink(missing_ok=True)

    return relatorio
