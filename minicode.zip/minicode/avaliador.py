
from uuid import UUID



def avaliar_execucoes(relatorios):
    """
    Consolida relatórios de diferentes execuções.

    Não executa testes e não consulta a LLM.
    """

    if not isinstance(relatorios, list) or not relatorios:
        raise ValueError(
            "Informe uma lista não vazia de relatórios."
        )

    identificadores = set()
    detalhes = []

    total_sucessos = 0
    total_ferramentas = 0
    total_verificacoes = 0
    total_reparos = 0
    total_primeira_tentativa = 0

    # Novos contadores
    total_chamadas_llm = 0
    total_iteracoes = 0

    for relatorio in relatorios:
        if not isinstance(relatorio, dict):
            raise ValueError("Relatório inválido.")

        run_id = relatorio.get("run_id")
        metricas = relatorio.get("metrics")

        try:
            identificador = str(UUID(run_id))
        except (ValueError, TypeError, AttributeError):
            raise ValueError("run_id inválido.")

        if identificador in identificadores:
            raise ValueError(
                "Uma execução não pode ser contabilizada duas vezes."
            )

        identificadores.add(identificador)

        if not isinstance(metricas, dict):
            raise ValueError("Métricas inválidas.")

        estado = metricas.get("final_state")
        sucesso = metricas.get("task_success")

        if estado not in {"DONE", "FAILED"}:
            raise ValueError(
                "A avaliação exige execuções finalizadas."
            )

        if type(sucesso) is not bool:
            raise ValueError("Resultado de sucesso inválido.")

        if sucesso != (estado == "DONE"):
            raise ValueError(
                "Estado final e sucesso são incoerentes."
            )

        campos_numericos = (
            "tool_calls",
            "verifications",
            "repairs_started"
        )

        for campo in campos_numericos:
            valor = metricas.get(campo)

            if type(valor) is not int or valor < 0:
                raise ValueError(
                    f"Métrica inválida: {campo}"
                )

        # Os novos campos podem estar ausentes em
        # relatórios antigos, gerados antes desta etapa.
        chamadas_llm = metricas.get("llm_calls", 0)
        iteracoes = metricas.get(
            "iterations",
            metricas["verifications"]
        )

        if type(chamadas_llm) is not int or chamadas_llm < 0:
            raise ValueError(
                "Métrica inválida: llm_calls"
            )

        if type(iteracoes) is not int or iteracoes < 0:
            raise ValueError(
                "Métrica inválida: iterations"
            )

        total_sucessos += int(sucesso)

        primeira_tentativa = (
            sucesso and metricas["repairs_started"] == 0
        )

        total_primeira_tentativa += int(
            primeira_tentativa
        )

        total_ferramentas += metricas["tool_calls"]
        total_verificacoes += metricas["verifications"]
        total_reparos += metricas["repairs_started"]

        total_chamadas_llm += chamadas_llm
        total_iteracoes += iteracoes

        detalhes.append({
            "run_id": identificador,
            "status": estado,
            "success": sucesso,
            "tool_calls": metricas["tool_calls"],
            "verifications": metricas["verifications"],
            "repairs": metricas["repairs_started"],
            "first_attempt_success": primeira_tentativa,
            "llm_calls": chamadas_llm,
            "iterations": iteracoes
        })

    total = len(relatorios)

    return {
        "total_runs": total,
        "successful_runs": total_sucessos,
        "failed_runs": total - total_sucessos,
        "success_rate": round(
            total_sucessos / total, 4
        ),
        "total_tool_calls": total_ferramentas,
        "total_verifications": total_verificacoes,
        "total_repairs": total_reparos,
        "average_tool_calls": round(
            total_ferramentas / total, 2
        ),
        "first_attempt_successes": total_primeira_tentativa,
        "first_attempt_success_rate": round(
            total_primeira_tentativa / total, 4
        ),
        "total_llm_calls": total_chamadas_llm,
        "total_iterations": total_iteracoes,
        "average_llm_calls": round(
            total_chamadas_llm / total, 2
        ),
        "average_iterations": round(
            total_iteracoes / total, 2
        ),
        "runs": detalhes
    }

