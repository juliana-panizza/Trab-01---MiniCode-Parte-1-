
from pathlib import Path

from aceitacao import obter_testes_aceitacao
from cenarios import CENARIOS, validar_cenario


def validar_ambiente_avaliacao(diretorio_base):
    """
    Verifica a estrutura dos cenários de avaliação.

    Não importa nem executa os arquivos dos projetos.
    Não executa pytest nem consulta a LLM.
    """

    base = Path(diretorio_base).resolve()

    if not base.is_dir():
        raise FileNotFoundError(
            "Diretório de avaliação não encontrado."
        )

    resultados = []

    for cenario in CENARIOS:
        validar_cenario(cenario)

        identificador = cenario["id"]

        # Evita identificadores usados como caminhos.
        if (
            not identificador.startswith("C")
            or not identificador[1:].isdigit()
        ):
            raise ValueError(
                "Identificador de cenário inválido."
            )

        nome_arquivo = cenario["target_file"]

        if (
            Path(nome_arquivo).name != nome_arquivo
            or nome_arquivo in {".", ".."}
        ):
            raise ValueError(
                "Nome de arquivo-alvo inválido."
            )

        pasta_cenario = base / identificador
        projeto = pasta_cenario / "projeto"
        avaliacao = pasta_cenario / "avaliacao"

        arquivo_alvo = projeto / nome_arquivo
        arquivo_testes = avaliacao / "test_aceitacao.py"

        # Rejeita links simbólicos nos caminhos esperados.
        caminhos = (
            pasta_cenario,
            projeto,
            avaliacao,
            arquivo_alvo,
            arquivo_testes
        )

        if any(caminho.is_symlink() for caminho in caminhos):
            raise PermissionError(
                f"Link simbólico detectado em {identificador}."
            )

        if not projeto.is_dir():
            raise FileNotFoundError(
                f"Projeto ausente: {identificador}."
            )

        if not avaliacao.is_dir():
            raise FileNotFoundError(
                f"Avaliação ausente: {identificador}."
            )

        if not arquivo_alvo.is_file():
            raise FileNotFoundError(
                f"Arquivo-alvo ausente: {identificador}."
            )

        if not arquivo_testes.is_file():
            raise FileNotFoundError(
                f"Testes ausentes: {identificador}."
            )

        # Os testes devem permanecer fora da pasta
        # disponibilizada às ferramentas do agente.
        if arquivo_testes.resolve().is_relative_to(
            projeto.resolve()
        ):
            raise PermissionError(
                "Testes de aceitação dentro do projeto."
            )

        testes_esperados = obter_testes_aceitacao(
            identificador
        )

        testes_encontrados = arquivo_testes.read_text(
            encoding="utf-8"
        )

        if testes_encontrados != testes_esperados:
            raise ValueError(
                f"Testes de aceitação alterados: {identificador}."
            )

        resultados.append({
            "id": identificador,
            "ready": True,
            "project_dir": str(projeto),
            "acceptance_tests": str(arquivo_testes)
        })

    return resultados
