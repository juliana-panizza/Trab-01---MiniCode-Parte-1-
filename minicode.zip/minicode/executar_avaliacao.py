"""Avalia o MiniCode com testes de desenvolvimento publicos e aceitacao externa.

O Qwen pode ler os testes de desenvolvimento em projeto/tests. Antes de
cada verificacao, o avaliador restaura a versao de referencia para impedir
que mudancas feitas pelo agente validem uma solucao incorreta.
Os testes externos de aceitacao permanecem fora do projeto.
"""

import argparse
import json
from pathlib import Path
from uuid import uuid4

from agent import MiniCodeAgent
from avaliacao_independente import avaliar_aceitacao
from cenarios import CENARIOS
from executor_isolado import verificar_docker
from metricas import calcular_metricas
from preparador_avaliacao import preparar_cenarios
from states import Estado


# Testes publicos pequenos derivados dos requisitos publicados em cada tarefa.
# NAO copiar TESTES_ACEITACAO para a pasta do agente.
TESTES_DESENVOLVIMENTO = {
    "C01": '''import pytest
from calculadora import fatorial

def test_fatorial_basico():
    assert fatorial(5) == 120

def test_fatorial_zero():
    assert fatorial(0) == 1

def test_fatorial_negativo():
    with pytest.raises(ValueError):
        fatorial(-1)
''',
    "C02": '''from texto import eh_palindromo

def test_palindromo():
    assert eh_palindromo("Osso") is True

def test_nao_palindromo():
    assert eh_palindromo("casa") is False
''',
    "C03": '''import pytest
from notas import calcular_media

def test_media_basica():
    assert calcular_media([8, 7, 9]) == 8.0

def test_lista_vazia():
    with pytest.raises(ValueError):
        calcular_media([])
''',
    "C04": '''from desconto import aplicar_desconto

def test_percentual():
    assert aplicar_desconto(80, 25) == 60
''',
    "C05": '''from saudacao import saudar

def test_compativel():
    assert saudar("Bia") == "Olá, Bia!"

def test_formal():
    assert saudar("Bia", formal=True) == "Saudações, Bia."
''',
}


def _proteger_verificacao(agente, projeto, identificador):
    """Forca testes de referencia antes de cada verificacao, inclusive reparos.

    A fonte confiavel e TESTES_DESENVOLVIMENTO, nao o arquivo editavel do
    projeto. O Qwen pode modifica-lo durante a implementacao, mas essa versao
    nunca determina o resultado da verificacao.
    """
    arquivo = projeto / "tests" / "test_desenvolvimento.py"
    conteudo_confiavel = TESTES_DESENVOLVIMENTO[identificador]
    verificar_original = agente.executar_verificacao

    def verificar_com_testes_confiaveis(*args, **kwargs):
        arquivo.parent.mkdir(parents=True, exist_ok=True)
        arquivo.write_text(conteudo_confiavel, encoding="utf-8")
        return verificar_original(*args, **kwargs)

    agente.executar_verificacao = verificar_com_testes_confiaveis


def _resultado_aceitacao(item):
    r = avaliar_aceitacao(item["project_dir"], item["acceptance_tests"])
    return {
        "executed": bool(r["executed"]),
        "passed": bool(r["passed"]),
        "exit_code": r["exit_code"],
    }


def _sucesso(aceitacao):
    return aceitacao["executed"] and aceitacao["passed"]


def executar_rodada(diretorio_saida, selecionados=None, max_passos=8,
                    max_reparos=2):
    if type(max_passos) is not int or not 1 <= max_passos <= 30:
        raise ValueError("max_passos deve ser inteiro entre 1 e 30.")
    if type(max_reparos) is not int or not 0 <= max_reparos <= 2:
        raise ValueError("max_reparos deve ser 0, 1 ou 2.")
    if not verificar_docker()["available"]:
        raise RuntimeError("Docker indisponivel; avaliacao nao iniciada.")

    saida = Path(diretorio_saida).resolve()
    if saida.exists():
        raise FileExistsError("O diretorio da rodada ja existe.")
    ids_validos = {c["id"] for c in CENARIOS}
    if selecionados is not None and (
        not selecionados or set(selecionados) - ids_validos
    ):
        raise ValueError("Cenarios invalidos.")

    projetos = preparar_cenarios(saida)
    if selecionados is not None:
        projetos = [p for p in projetos if p["id"] in selecionados]

    registros = []
    for item in projetos:
        identificador = item["id"]
        print(f"[{identificador}] Qwen: especificacao e implementacao...", flush=True)

        projeto = Path(item["project_dir"])
        testes = projeto / "tests"
        testes.mkdir()
        (testes / "test_desenvolvimento.py").write_text(
            TESTES_DESENVOLVIMENTO[identificador], encoding="utf-8"
        )

        agente = MiniCodeAgent(projeto)
        _proteger_verificacao(agente, projeto, identificador)
        implementacao_concluida = False
        erro_tipo = None
        inicial = {"executed": False, "passed": False, "exit_code": None}
        final = dict(inicial)
        reparos = 0
        verificacoes = 0
        try:
            agente.preparar(item["task"])
            agente.executar_implementacao(max_passos=max_passos)
            implementacao_concluida = True

            # Primeira tentativa: aceitacao externa, sem expor feedback ao Qwen.
            inicial = _resultado_aceitacao(item)
            final = dict(inicial)
            print(f"[{identificador}] Aceitacao inicial: {'PASSOU' if _sucesso(inicial) else 'FALHOU'}", flush=True)

            verificacao = agente.executar_verificacao()
            verificacoes += 1
            while verificacao["status"] == "REPAIRING" and reparos < max_reparos:
                feedback = verificacao["verification"]
                print(f"[{identificador}] Reparo {reparos + 1}/{max_reparos}...", flush=True)
                reparos += 1
                verificacao = agente.executar_reparo(
                    feedback, max_passos=max_passos
                )
                verificacoes += 1

            # Se o limite acabou e os testes de desenvolvimento ainda falham,
            # encerra o estado da maquina, sem iniciar outro reparo.
            if agente.maquina.estado == Estado.REPAIRING:
                agente.maquina.falhar()
                agente.salvar_estado()

            if reparos:
                final = _resultado_aceitacao(item)

        except Exception as erro:
            # Nunca imprimir excecoes que possam conter detalhes do provedor.
            erro_tipo = type(erro).__name__
            # Mesmo em erro de implementacao, registrar resultado externo final.
            try:
                final = _resultado_aceitacao(item)
            except Exception:
                pass

        try:
            m = calcular_metricas(projeto, run_id=agente.run_id)
        except (OSError, ValueError, KeyError, TypeError):
            m = {}

        sucesso_inicial = implementacao_concluida and _sucesso(inicial)
        sucesso_final = implementacao_concluida and _sucesso(final)
        registro = {
            "scenario_id": identificador,
            "run_id": agente.run_id,
            "project_dir": str(projeto),
            "implementation_completed": implementacao_concluida,
            "initial_acceptance": inicial,
            "acceptance": final,
            "first_attempt_success": bool(sucesso_inicial),
            "success": bool(sucesso_final),
            "repairs": reparos,
            "development_verifications": verificacoes,
            "agent_state": agente.maquina.estado.value,
            "llm_calls": m.get("llm_calls"),
            "tool_calls": m.get("tool_calls"),
            "error_type": erro_tipo,
        }
        registros.append(registro)
        print(f"[{identificador}] Final: {'APROVADO' if sucesso_final else 'NAO APROVADO'}; reparos: {reparos}", flush=True)

        # Salvar progresso apos cada cenario, inclusive se houver falha.
        (saida / "resultados.json").write_text(
            json.dumps({"method": "development_repair_external_acceptance",
                        "runs": registros}, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    total = len(registros)
    resumo = {
        "method": "development_repair_external_acceptance",
        "total": total,
        "successful": sum(r["success"] for r in registros),
        "success_rate": round(sum(r["success"] for r in registros) / total, 4),
        "first_attempt_success_rate": round(
            sum(r["first_attempt_success"] for r in registros) / total, 4
        ),
        "average_iterations": round(
            sum(r["development_verifications"] for r in registros) / total, 2
        ),
        "average_llm_calls": (
            round(sum(r["llm_calls"] for r in registros) / total, 2)
            if all(type(r["llm_calls"]) is int for r in registros) else None
        ),
        "note": "Sucesso medido exclusivamente pelos testes externos; reparos recebem feedback apenas dos testes publicos de desenvolvimento.",
        "runs": registros,
    }
    (saida / "resultados.json").write_text(
        json.dumps(resumo, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"\nRodada: {saida}\nSucesso final: {resumo['successful']}/{total}")
    return resumo


def main():
    parser = argparse.ArgumentParser(description="MiniCode: avaliacao com reparos")
    parser.add_argument("--cenario", choices=[c["id"] for c in CENARIOS])
    parser.add_argument("--max-passos", type=int, default=8)
    parser.add_argument("--max-reparos", type=int, default=2, choices=[0, 1, 2])
    parser.add_argument("--saida", default=None)
    args = parser.parse_args()
    destino = args.saida or ("avaliacoes/rodada_" + uuid4().hex[:10])
    executar_rodada(destino, [args.cenario] if args.cenario else None,
                    args.max_passos, args.max_reparos)


if __name__ == "__main__":
    main()
