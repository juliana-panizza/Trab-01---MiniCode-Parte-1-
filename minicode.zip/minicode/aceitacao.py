
import ast
from textwrap import dedent


TESTES_ACEITACAO = {
    "C01": dedent("""
        import pytest
        from calculadora import fatorial

        def test_fatorial_zero():
            assert fatorial(0) == 1

        def test_fatorial_um():
            assert fatorial(1) == 1

        def test_fatorial_cinco():
            assert fatorial(5) == 120

        def test_fatorial_negativo():
            with pytest.raises(ValueError):
                fatorial(-1)
    """).strip() + "\n",

    "C02": dedent("""
        from texto import eh_palindromo

        def test_palindromo_simples():
            assert eh_palindromo("arara") is True

        def test_nao_palindromo():
            assert eh_palindromo("python") is False

        def test_palindromo_com_espacos():
            assert eh_palindromo(
                "A base do teto desaba"
            ) is True
    """).strip() + "\n",

    "C03": dedent("""
        import pytest
        from notas import calcular_media

        def test_media_tres_notas():
            assert calcular_media([8, 7, 9]) == 8.0

        def test_media_uma_nota():
            assert calcular_media([10]) == 10.0

        def test_media_lista_vazia():
            with pytest.raises(ValueError):
                calcular_media([])
    """).strip() + "\n",

    "C04": dedent("""
        from desconto import aplicar_desconto


        def test_desconto_dez_por_cento():
            assert aplicar_desconto(100, 10) == 90


        def test_desconto_zero():
            assert aplicar_desconto(80, 0) == 80


        def test_desconto_cinquenta_por_cento():
            assert aplicar_desconto(200, 50) == 100


        def test_desconto_total():
            assert aplicar_desconto(75, 100) == 0
    """).strip() + "\n",

    
    "C05": dedent("""
        from saudacao import saudar

        def test_compatibilidade_antiga():
            assert saudar("Ana") == "Olá, Ana!"

        def test_parametro_falso():
            assert saudar("Ana", False) == "Olá, Ana!"

        def test_parametro_verdadeiro():
            assert saudar("Ana", True) == "Saudações, Ana."

        def test_parametro_nomeado():
            assert saudar(
                "João", formal=True
            ) == "Saudações, João."
    """).strip() + "\n"

}


def obter_testes_aceitacao(cenario_id):
    """
    Retorna os testes independentes de um cenário.

    Não executa o código testado.
    """

    if not isinstance(cenario_id, str):
        raise ValueError("Identificador inválido.")

    if cenario_id not in TESTES_ACEITACAO:
        raise ValueError(
            f"Cenário desconhecido: {cenario_id}"
        )

    return TESTES_ACEITACAO[cenario_id]


def validar_testes_aceitacao():
    """
    Verifica se os arquivos de testes definidos
    possuem sintaxe Python válida.
    """

    for identificador, codigo in TESTES_ACEITACAO.items():
        try:
            arvore = ast.parse(codigo)
        except SyntaxError as erro:
            raise ValueError(
                f"Testes inválidos para {identificador}"
            ) from erro

        funcoes = [
            no
            for no in arvore.body
            if isinstance(no, ast.FunctionDef)
            and no.name.startswith("test_")
        ]

        if len(funcoes) < 3:
            raise ValueError(
                f"O cenário {identificador} "
                "precisa de pelo menos três testes."
            )

    return True
