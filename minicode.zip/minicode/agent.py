# Arquivo Orquestrador (responsabilidades estão na anotação)

from pathlib import Path
import json

from spec import gerar_spec, salvar_spec
from plan import gerar_plan, salvar_plan
from states import Estado, MaquinaEstados

from executor import Executor
from implementador import implementar
from verificador import verificar_projeto
from logger import RegistroEventos
from uuid import uuid4
from relatorio import gerar_relatorio
from llm import contexto_llm

class MiniCodeAgent:

    '''
        Construtor
        Ao criarmos um objeto, informamos qual projeto queremos modificar.
        ex: agente = MiniCodeAgent("examples/projeto_teste")
    '''
    def __init__(self, diretorio_projeto):
        self.diretorio = Path(diretorio_projeto).resolve()

        self.run_id = str(uuid4())
        if not self.diretorio.is_dir():
            raise ValueError(
                f"Diretório do projeto não encontrado: {self.diretorio}"
            )

        self.maquina = MaquinaEstados(max_tentativas=3)
        self.maquina.run_id = self.run_id

        self.tarefa = None
        self.spec = None
        self.plan = None

    ''' 
        Função que percorre o diretório do projeto e identifica os arquivos existentes.
        O método rglob() procura arquivos e diretórios recursivamentte e depois
        filtramos os casos com .git, .venv e .minicode que serão desconsiderados
        por não serem de implementação.
    '''
    def listar_arquivos(self):
        """
        Listagem inicial para fornecer contexto ao PLAN.
        Posteriormente será integrada à ferramenta list_files.
        """

        arquivos = []
        ignorados = {
            ".minicode", ".git", ".venv",
            "__pycache__", ".pytest_cache"
        }

        for caminho in self.diretorio.rglob("*"):

            if qualquer_ignorado(caminho, self.diretorio, ignorados):
                continue

            if caminho.is_symlink():
                continue

            if caminho.is_file():
                relativo = caminho.relative_to(self.diretorio)
                arquivos.append(relativo.as_posix())

        return sorted(arquivos)

    '''
        Como o professor pediu rastreabilidade, vamos gerar um arquivo json chamado state 
        que é um registro da execução. Vai servir como um histórico (eu acho)
    '''
    def salvar_estado(self):
        """
        Registra a situação atual do agente em state.json.
        """

        pasta = self.diretorio / ".minicode"
        pasta.mkdir(parents=True, exist_ok=True)

        dados = {
            "task": self.tarefa,
            "state": self.maquina.estado.value,
            "history": self.maquina.historico,
            "spec_valid": self.maquina.spec_valida,
            "plan_valid": self.maquina.plan_valido,
            "repair_attempts": self.maquina.tentativas_reparo,
            "tests_executed": self.maquina.testes_executados,
            "tests_passed": self.maquina.testes_aprovados
        }

        caminho = pasta / "state.json"

        caminho.write_text(
            json.dumps(dados, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )

        
        # Registrar apenas mudanças de estado.
        estado_atual = self.maquina.estado.value

        if getattr(self, "_ultimo_estado_logado", None) != estado_atual:
            logger = RegistroEventos(
                self.diretorio,
                run_id=self.run_id
            )
            logger.registrar_estado(estado_atual)

            self._ultimo_estado_logado = estado_atual

        
        # Gerar relatório ao concluir a execução.
        if estado_atual in {"DONE", "FAILED"}:
            if getattr(
                self,
                "_ultimo_relatorio_estado",
                None
            ) != estado_atual:

                gerar_relatorio(
                    self.diretorio,
                    self.run_id
                )

                self._ultimo_relatorio_estado = estado_atual



    '''
        (Ver melhor depois)
    '''
    def preparar(self, tarefa):
        """
        Executa TASK -> SPEC -> PLAN.
        Não realiza modificações no código do projeto.
        """

        if self.maquina.estado != Estado.RECEIVED:
            raise RuntimeError(
                "Esta instância já iniciou uma tarefa."
            )

        if not isinstance(tarefa, str) or not tarefa.strip():
            raise ValueError("A tarefa não pode estar vazia.")

        self.tarefa = tarefa

        etapa_atual = "spec"
        try:
            print("\n[RECEIVED] Tarefa recebida.")
            self.salvar_estado()

            # Etapa 1: SPEC
            print("\nGerando especificação...")

            with contexto_llm(
                self.diretorio,
                self.run_id,
                "spec"
            ):
                self.spec = gerar_spec(tarefa)

            salvar_spec(self.spec, self.diretorio)

            self.maquina.registrar_spec(self.spec)
            self.salvar_estado()

            print("[SPECIFIED] Especificação validada.")

            # Etapa 2: PLAN
            etapa_atual = "plan"

            arquivos = self.listar_arquivos()

            print("\nArquivos encontrados:")
            for arquivo in arquivos:
                print(f"- {arquivo}")

            print("\nGerando planejamento...")

            with contexto_llm(
                self.diretorio,
                self.run_id,
                "plan"
            ):
                self.plan = gerar_plan(self.spec, arquivos)

            salvar_plan(self.plan, self.diretorio)

            self.maquina.registrar_plan(self.plan)
            self.salvar_estado()

            print("[PLANNED] Planejamento validado.")

            return {
                "status": "prepared",
                "state": self.maquina.estado.value,
                "specification": self.spec,
                "plan": self.plan
            }


        
        
        except Exception as erro:
            logger = RegistroEventos(
                self.diretorio,
                run_id=self.run_id
            )

            logger.registrar_erro(
                etapa_atual,
                erro
            )

            if self.maquina.estado not in (
                Estado.FAILED,
                Estado.DONE
            ):
                self.maquina.falhar()

            self.salvar_estado()
            raise


    
    def executar_implementacao(self, max_passos=8):
        """
        Continua uma tarefa já preparada.

        Executa PLANNED -> IMPLEMENTING.
        Não declara sucesso nem executa testes.
        """

        if self.maquina.estado != Estado.PLANNED:
            raise RuntimeError(
                "A implementação exige o estado PLANNED."
            )

        if self.spec is None or self.plan is None:
            raise RuntimeError(
                "SPEC e PLAN precisam existir."
            )

        if not self.maquina.spec_valida:
            raise RuntimeError("SPEC inválida.")

        if not self.maquina.plan_valido:
            raise RuntimeError("PLAN inválido.")

        try:
            self.maquina.transicionar(Estado.IMPLEMENTING)
            self.salvar_estado()

            print("[IMPLEMENTING] Iniciando implementação...")

            executor = Executor(
                self.diretorio,
                self.maquina
            )
            with contexto_llm(
                self.diretorio,
                self.run_id,
                "implementation"
            ):
                resultado = implementar(
                    executor,
                    self.spec,
                    self.plan,
                    max_passos=max_passos
                )

            if not resultado.get("finished"):
                raise RuntimeError(
                    "A implementação não foi concluída."
                )

            self.salvar_estado()

            return resultado

        
        except Exception as erro:
            logger = RegistroEventos(
                self.diretorio,
                run_id=self.run_id
            )

            logger.registrar_erro(
                "implementation",
                erro
            )

            if self.maquina.estado not in (
                Estado.FAILED,
                Estado.DONE
            ):
                self.maquina.falhar()

            self.salvar_estado()
            raise

        
    
    def executar_verificacao(self):
        """
        Verifica a implementação e decide o próximo estado.

        DONE: testes executados e aprovados.
        REPAIRING: testes executados e reprovados.
        FAILED: testes não executados ou erro.
        """

        if self.maquina.estado != Estado.IMPLEMENTING:
            raise RuntimeError(
                "A verificação exige o estado IMPLEMENTING."
            )

        try:
            self.maquina.transicionar(Estado.VERIFYING)
            self.salvar_estado()

            print("[VERIFYING] Executando testes...")

            resultado = verificar_projeto(
                self.diretorio,
                self.maquina
            )

            
            
            logger = RegistroEventos(
                self.diretorio,
                run_id=self.run_id
            )

            logger.registrar_verificacao(
                executados=resultado["executed"],
                aprovados=resultado["passed"]
            )



            if not resultado["executed"]:
                self.maquina.falhar()
                self.salvar_estado()

                return {
                    "status": "FAILED",
                    "verification": resultado
                }

            if resultado["passed"]:
                self.maquina.finalizar()
                status = "DONE"
            else:
                self.maquina.transicionar(Estado.REPAIRING)
                status = "REPAIRING"

            self.salvar_estado()

            return {
                "status": status,
                "verification": resultado
            }

        
        except Exception as erro:
            logger = RegistroEventos(
                self.diretorio,
                run_id=self.run_id
            )

            logger.registrar_erro(
                "verification",
                erro
            )

            if self.maquina.estado not in (
                Estado.FAILED,
                Estado.DONE
            ):
                self.maquina.falhar()

            self.salvar_estado()
            raise


    
    def executar_reparo(
        self,
        resultado_verificacao,
        max_passos=8
    ):
        """
        Executa uma tentativa de reparação.

        Exige REPAIRING e um resultado anterior
        de testes executados e reprovados.

        Após implementar, verifica novamente.
        """

        if self.maquina.estado != Estado.REPAIRING:
            raise RuntimeError(
                "O reparo exige o estado REPAIRING."
            )

        if not isinstance(resultado_verificacao, dict):
            raise ValueError(
                "Resultado de verificação inválido."
            )

        if (
            resultado_verificacao.get("executed") is not True
            or resultado_verificacao.get("passed") is not False
        ):
            raise ValueError(
                "O reparo exige testes executados "
                "e reprovados."
            )

        if self.spec is None or self.plan is None:
            raise RuntimeError(
                "SPEC e PLAN são obrigatórios."
            )

        try:
            
            
            logger = RegistroEventos(
                self.diretorio,
                run_id=self.run_id
            )

            tentativa_atual = self.maquina.iniciar_reparo()

            logger.registrar_reparo(
                tentativa=tentativa_atual,
                status="started"
            )



            self.maquina.transicionar(Estado.IMPLEMENTING)
            self.salvar_estado()

            print("[REPAIR] Solicitando correção ao Qwen...")

            executor = Executor(
                self.diretorio,
                self.maquina
            )


            with contexto_llm(
                self.diretorio,
                self.run_id,
                "repair"
            ):
                implementacao = implementar(
                    executor,
                    self.spec,
                    self.plan,
                    max_passos=max_passos,
                    feedback_testes=resultado_verificacao
                )


            if not implementacao.get("finished"):
                raise RuntimeError(
                    "A reparação não foi concluída."
                )

            
            verificacao = self.executar_verificacao()

            # Registra o resultado da tentativa de reparo.
            status_reparo = (
                "passed"
                if verificacao["status"] == "DONE"
                else "failed"
            )

            logger.registrar_reparo(
                tentativa=tentativa_atual,
                status=status_reparo
            )

            return {
                "repair": implementacao,
                "verification": verificacao,
                "status": verificacao["status"]
            }


        
        
        except Exception as erro:
            logger = RegistroEventos(
                self.diretorio,
                run_id=self.run_id
            )

            # Encerra a tentativa iniciada, caso exista.
            if "tentativa_atual" in locals():
                logger.registrar_reparo(
                    tentativa=tentativa_atual,
                    status="failed"
                )

            logger.registrar_erro(
                "repair",
                erro
            )

            if self.maquina.estado not in (
                Estado.FAILED,
                Estado.DONE
            ):
                self.maquina.falhar()

            self.salvar_estado()
            raise



    
    def executar_ciclo(
        self,
        max_passos=8,
        max_reparos=1
    ):
        """
        Executa implementação, verificação e
        reparações até DONE ou FAILED.

        O limite max_reparos conta as correções
        adicionais após a primeira implementação.
        """

        if self.maquina.estado != Estado.PLANNED:
            raise RuntimeError(
                "O ciclo exige o estado PLANNED."
            )

        if (
            type(max_reparos) is not int
            or not 0 <= max_reparos <= 2
        ):
            raise ValueError(
                "max_reparos deve estar entre 0 e 2."
            )

        historico = []
        reparos_realizados = 0

        try:
            implementacao = self.executar_implementacao(
                max_passos=max_passos
            )

            historico.append({
                "stage": "implementation",
                "result": implementacao
            })

            verificacao = self.executar_verificacao()

            historico.append({
                "stage": "verification",
                "result": verificacao
            })

            while self.maquina.estado == Estado.REPAIRING:

                if reparos_realizados >= max_reparos:
                    self.maquina.falhar()
                    self.salvar_estado()
                    break

                feedback = verificacao["verification"]

                reparos_realizados += 1

                resultado_reparo = self.executar_reparo(
                    feedback,
                    max_passos=max_passos
                )

                historico.append({
                    "stage": "repair",
                    "attempt": reparos_realizados,
                    "result": resultado_reparo
                })

                verificacao = resultado_reparo["verification"]

            self.salvar_estado()

            return {
                "status": self.maquina.estado.value,
                "repairs": reparos_realizados,
                "history": historico
            }

        except Exception:
            if self.maquina.estado not in (
                Estado.DONE,
                Estado.FAILED
            ):
                self.maquina.falhar()

            self.salvar_estado()
            raise


def qualquer_ignorado(caminho, raiz, ignorados):
    relativo = caminho.relative_to(raiz)
    return any(parte in ignorados for parte in relativo.parts)
