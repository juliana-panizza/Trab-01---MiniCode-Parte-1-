# Responsável por gerar, validar e salvar o planejamento

import json
from pathlib import Path

from llm import chat
from spec import validar_spec


PLAN_PROMPT = """
Você é responsável pelo planejamento de tarefas de
programação do agente MiniCode.

Receberá uma especificação e uma lista de arquivos
existentes em um projeto.

Sua responsabilidade é produzir um plano de
implementação baseado nessas informações.

Retorne exclusivamente um objeto JSON com:

{
    "summary": "Resumo da implementação",
    "steps": [
        {
            "step": 1,
            "description": "Ação a realizar",
            "files": ["arquivo.py"]
        }
    ],
    "tests": [
        "Descrição de um teste"
    ]
}

Regras:
- Não implemente código.
- Não modifique arquivos.
- Utilize a especificação como referência.
- Considere os arquivos existentes no projeto.
- Não afirme que arquivos inexistentes já existem.
- Se for necessário criar um arquivo, indique isso no passo.
- Organize os passos em ordem de execução.
- Inclua testes relacionados aos critérios de aceitação.
- Responda em português.
- Inclua explicitamente a execução dos testes como
  uma das etapas finais do planejamento.
"""


def validar_plan(plan):
    if not isinstance(plan, dict):
        raise ValueError("O plano deve ser um objeto JSON.")

    if not isinstance(plan.get("summary"), str):
        raise ValueError("O resumo do plano deve ser um texto.")

    if not plan["summary"].strip():
        raise ValueError("O resumo do plano não pode estar vazio.")

    passos = plan.get("steps")

    if not isinstance(passos, list) or not passos:
        raise ValueError("O plano deve conter passos.")

    for indice, passo in enumerate(passos, start=1):
        if not isinstance(passo, dict):
            raise ValueError("Cada passo deve ser um objeto.")

        if passo.get("step") != indice:
            raise ValueError(
                "Os passos devem ser numerados sequencialmente."
            )

        descricao = passo.get("description")

        if not isinstance(descricao, str) or not descricao.strip():
            raise ValueError(
                f"O passo {indice} deve possuir uma descrição."
            )

        arquivos = passo.get("files")

        if not isinstance(arquivos, list):
            raise ValueError(
                f"O passo {indice} deve possuir uma lista de arquivos."
            )

        if not all(
            isinstance(arquivo, str) and arquivo.strip()
            for arquivo in arquivos
        ):
            raise ValueError(
                f"O passo {indice} contém um arquivo inválido."
            )

    testes = plan.get("tests")

    if not isinstance(testes, list) or not testes:
        raise ValueError("O plano deve conter testes.")

    if not all(
        isinstance(teste, str) and teste.strip()
        for teste in testes
    ):
        raise ValueError("O plano contém testes inválidos.")

    return True


def gerar_plan(spec, arquivos_projeto):
    validar_spec(spec)

    if not isinstance(arquivos_projeto, list):
        raise ValueError(
            "Os arquivos do projeto devem estar em uma lista."
        )

    contexto = {
        "specification": spec,
        "project_files": arquivos_projeto
    }

    mensagens = [
        {"role": "system", "content": PLAN_PROMPT},
        {
            "role": "user",
            "content": json.dumps(
                contexto,
                ensure_ascii=False,
                indent=2
            )
        }
    ]

    resposta = chat(
        mensagens,
        response_format={"type": "json_object"}
    )

    try:
        plan = json.loads(resposta)
    except json.JSONDecodeError as erro:
        raise ValueError(
            "A LLM não retornou um plano em JSON válido."
        ) from erro

    validar_plan(plan)

    return plan


def salvar_plan(plan, diretorio_projeto):
    validar_plan(plan)

    pasta = Path(diretorio_projeto) / ".minicode"
    pasta.mkdir(parents=True, exist_ok=True)

    caminho = pasta / "plan.md"

    linhas = [
        "# Implementation Plan",
        "",
        "## Summary",
        "",
        plan["summary"],
        "",
        "## Steps",
        ""
    ]

    for passo in plan["steps"]:
        linhas.append(
            f"{passo['step']}. {passo['description']}"
        )

        if passo["files"]:
            linhas.append(
                f"   - Arquivos: {', '.join(passo['files'])}"
            )

    linhas.extend([
        "",
        "## Tests",
        ""
    ])

    for teste in plan["tests"]:
        linhas.append(f"- {teste}")

    caminho.write_text(
        "\n".join(linhas) + "\n",
        encoding="utf-8"
    )

    return caminho
