
import json

from llm import chat
from tools import FerramentasProjeto


PROMPT_FERRAMENTAS = """
Você é um agente de análise de projetos Python.

Escolha uma ação por resposta.

Ações permitidas:
- list_files: lista os arquivos do projeto.
- read_file: lê um arquivo específico.
- finish: apresenta a resposta final.

Retorne SOMENTE um JSON neste formato:

{
    "action": "nome_da_acao",
    "arguments": {}
}

Para read_file:
{
    "action": "read_file",
    "arguments": {
        "caminho": "arquivo.py"
    }
}

Para finalizar:
{
    "action": "finish",
    "arguments": {
        "resposta": "Sua resposta ao usuário"
    }
}

Regras:
- Utilize as ferramentas para investigar o projeto.
- Não invente conteúdo de arquivos.
- Não solicite alterações.
- Não utilize ações fora da lista permitida.
- Responda em português.
"""


def executar_acao(ferramentas, acao):
    if not isinstance(acao, dict):
        raise ValueError("A ação deve ser um objeto.")

    if set(acao) != {"action", "arguments"}:
        raise ValueError("Estrutura de ação inválida.")

    nome = acao["action"]
    argumentos = acao["arguments"]

    if not isinstance(argumentos, dict):
        raise ValueError("Argumentos inválidos.")

    if nome == "list_files":
        if argumentos:
            raise ValueError(
                "list_files não recebe argumentos."
            )

        return ferramentas.list_files()

    if nome == "read_file":
        if set(argumentos) != {"caminho"}:
            raise ValueError(
                "Argumentos inválidos para read_file."
            )

        caminho = argumentos["caminho"]

        if not isinstance(caminho, str):
            raise ValueError("Caminho inválido.")

        conteudo = ferramentas.read_file(caminho)

        # Limita o texto enviado de volta à LLM.
        return conteudo[:12000]

    raise ValueError("Ação não autorizada.")


def consultar_projeto(diretorio, pergunta, max_passos=5):
    if (
        not isinstance(max_passos, int)
        or isinstance(max_passos, bool)
        or not 1 <= max_passos <= 10
    ):
        raise ValueError("max_passos deve estar entre 1 e 10.")

    if not isinstance(pergunta, str) or not pergunta.strip():
        raise ValueError("A pergunta não pode estar vazia.")

    ferramentas = FerramentasProjeto(diretorio)

    mensagens = [
        {
            "role": "system",
            "content": PROMPT_FERRAMENTAS
        },
        {
            "role": "user",
            "content": pergunta
        }
    ]

    for passo in range(max_passos):
        resposta = chat(
            mensagens,
            response_format={"type": "json_object"}
        )

        try:
            acao = json.loads(resposta)

            if not isinstance(acao, dict):
                raise ValueError("Resposta JSON inválida.")

            nome = acao.get("action")
            argumentos = acao.get("arguments")

            if nome == "finish":
                if (
                    set(acao) != {"action", "arguments"}
                    or not isinstance(argumentos, dict)
                    or set(argumentos) != {"resposta"}
                    or not isinstance(argumentos["resposta"], str)
                ):
                    raise ValueError(
                        "Resposta final inválida."
                    )

                return argumentos["resposta"]

            resultado = executar_acao(
                ferramentas,
                acao
            )

            print(f"[TOOL] {nome}")

        except (ValueError, PermissionError,
                FileNotFoundError, UnicodeError) as erro:
            resultado = {"error": str(erro)}
            print(f"[TOOL ERROR] {erro}")

        mensagens.append({
            "role": "assistant",
            "content": resposta
        })

        mensagens.append({
            "role": "user",
            "content": (
                "Resultado da ação anterior:\n"
                + json.dumps(
                    resultado,
                    ensure_ascii=False
                )
                + "\nEscolha a próxima ação ou finalize."
            )
        })

    raise RuntimeError(
        "Limite de passos de consulta atingido."
    )
