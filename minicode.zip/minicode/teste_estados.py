# Arquivo de testes iniciais 
'''
    Como algumas ferramentas ainda não foram implementadas, os testes aqui são bem limitados
    e simulados propositalmente para verificar se tudo está funcionando.
'''
from states import Estado, MaquinaEstados


def executar_teste():
    maquina = MaquinaEstados(max_tentativas=3)

    print("Estado inicial:", maquina.estado.value)

    print("\nTentando implementar sem SPEC e PLAN...")

    try:
        maquina.transicionar(Estado.IMPLEMENTING)
    except RuntimeError as erro:
        print("Bloqueado corretamente:", erro)

    spec = {
        "objective": "Criar uma função de fatorial",
        "requirements": [
            "Receber um inteiro não negativo",
            "Retornar o fatorial"
        ],
        "acceptance_criteria": [
            "fatorial(0) deve retornar 1",
            "fatorial(5) deve retornar 120"
        ]
    }

    maquina.registrar_spec(spec)
    print("\nEstado:", maquina.estado.value)

    plan = {
        "summary": "Implementar e testar o fatorial",
        "steps": [
            {
                "step": 1,
                "description": "Criar a função",
                "files": ["calculadora.py"]
            },
            {
                "step": 2,
                "description": "Criar os testes",
                "files": ["test_calculadora.py"]
            }
        ],
        "tests": [
            "Testar fatorial(0)",
            "Testar fatorial(5)"
        ]
    }

    maquina.registrar_plan(plan)
    print("Estado:", maquina.estado.value)

    maquina.transicionar(Estado.IMPLEMENTING)
    print("Estado:", maquina.estado.value)

    maquina.transicionar(Estado.VERIFYING)
    print("Estado:", maquina.estado.value)

    print("\nTentando finalizar sem testes...")

    try:
        maquina.finalizar()
    except RuntimeError as erro:
        print("Bloqueado corretamente:", erro)

    print("\nSimulando testes reprovados...")
    maquina.registrar_testes(
        executados=True,
        aprovados=False
    )

    maquina.transicionar(Estado.REPAIRING)
    print("Estado:", maquina.estado.value)

    maquina.transicionar(Estado.IMPLEMENTING)
    print("Estado:", maquina.estado.value)

    maquina.transicionar(Estado.VERIFYING)
    print("Estado:", maquina.estado.value)

    print("\nSimulando testes aprovados...")
    maquina.registrar_testes(
        executados=True,
        aprovados=True
    )

    maquina.finalizar()
    print("Estado final:", maquina.estado.value)

    print("\nHistórico:")
    print(" -> ".join(maquina.historico))


if __name__ == "__main__":
    executar_teste()
