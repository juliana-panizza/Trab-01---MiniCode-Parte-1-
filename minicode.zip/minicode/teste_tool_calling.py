
from tool_calling import consultar_projeto


def main():
    resposta = consultar_projeto(
        diretorio="examples/projeto_teste",
        pergunta=(
            "Liste os arquivos Python deste projeto "
            "e informe quais estão vazios."
        )
    )

    print("\nResposta do agente:")
    print(resposta)


if __name__ == "__main__":
    main()
