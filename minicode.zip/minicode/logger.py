
import json
from datetime import datetime, timezone
from pathlib import Path

from uuid import UUID

class RegistroEventos:
    """
    Registra eventos estruturados do MiniCode.

    Não armazena prompts, código-fonte,
    tokens ou saídas completas dos testes.
    """

    def __init__(self, diretorio_projeto, run_id=None):
        self.raiz = Path(diretorio_projeto).resolve()

        self.pasta = self.raiz / ".minicode"
        self.pasta.mkdir(parents=True, exist_ok=True)

        self.arquivo = self.pasta / "events.jsonl"

        if run_id is not None:
            try:
                run_id = str(UUID(run_id))
            except (ValueError, TypeError, AttributeError):
                raise ValueError("run_id inválido.")

        self.run_id = run_id           

    def _registrar(self, tipo, dados):
        evento = {
            "timestamp": datetime.now(
                timezone.utc
            ).isoformat(),
            "type": tipo,
            "data": dados
        }

        if self.run_id is not None:
            evento["run_id"] = self.run_id

        with self.arquivo.open(
            "a",
            encoding="utf-8"
        ) as arquivo:
            arquivo.write(
                json.dumps(
                    evento,
                    ensure_ascii=False
                ) + "\n"
            )

        return evento

    def registrar_estado(self, estado):
        if not isinstance(estado, str):
            raise ValueError("Estado inválido.")

        estados_permitidos = {
            "RECEIVED",
            "SPECIFIED",
            "PLANNED",
            "IMPLEMENTING",
            "VERIFYING",
            "REPAIRING",
            "DONE",
            "FAILED"
        }

        if estado not in estados_permitidos:
            raise ValueError("Estado desconhecido.")

        return self._registrar(
            "state_transition",
            {"state": estado}
        )

    
    def registrar_ferramenta(
        self,
        nome,
        sucesso,
        caminho=None
    ):
        ferramentas_permitidas = {
            "list_files",
            "read_file",
            "write_file",
            "run_tests"
        }

        if nome not in ferramentas_permitidas:
            raise ValueError("Ferramenta desconhecida.")

        if type(sucesso) is not bool:
            raise ValueError("Sucesso deve ser booleano.")

        dados = {
            "tool": nome,
            "success": sucesso
        }

        if caminho is not None:
            if nome not in {"read_file", "write_file"}:
                raise ValueError(
                    "Caminho permitido apenas para "
                    "read_file e write_file."
                )

            if not isinstance(caminho, str):
                raise ValueError(
                    "O caminho deve ser uma string."
                )

            from pathlib import PurePath

            caminho_normalizado = caminho.replace("\\", "/")

            if (
                not caminho_normalizado
                or caminho_normalizado.startswith("/")
                or ":" in caminho_normalizado
                or any(
                    parte in {"", ".", ".."}
                    for parte in caminho_normalizado.split("/")
                )
            ):
                raise ValueError(
                    "O caminho deve ser relativo ao projeto."
                )

            dados["path"] = caminho_normalizado

        return self._registrar(
            "tool_execution",
            dados
        )

    
    def registrar_erro(self, etapa, erro):
        """
        Registra a categoria de uma falha.

        Não salva mensagens de exceção, traceback,
        caminhos de arquivos ou credenciais.
        """

        etapas_permitidas = {
            "spec",
            "plan",
            "implementation",
            "verification",
            "repair"
        }

        if (
            not isinstance(etapa, str)
            or etapa not in etapas_permitidas
        ):
            raise ValueError(
                "Etapa de erro inválida."
            )

        if not isinstance(erro, Exception):
            raise TypeError(
                "O erro deve ser uma exceção."
            )

        tipos_permitidos = {
            ValueError: "ValueError",
            TypeError: "TypeError",
            RuntimeError: "RuntimeError",
            PermissionError: "PermissionError",
            FileNotFoundError: "FileNotFoundError",
            TimeoutError: "TimeoutError",
            OSError: "OSError"
        }

        tipo_erro = "OtherError"

        for classe, nome in tipos_permitidos.items():
            if isinstance(erro, classe):
                tipo_erro = nome
                break

        return self._registrar(
            "execution_error",
            {
                "stage": etapa,
                "error_type": tipo_erro
            }
        )


    def registrar_verificacao(
        self,
        executados,
        aprovados
    ):
        if (
            type(executados) is not bool
            or type(aprovados) is not bool
        ):
            raise ValueError(
                "Resultados dos testes devem ser booleanos."
            )

        if aprovados and not executados:
            raise ValueError(
                "Testes não executados não podem passar."
            )

        return self._registrar(
            "verification",
            {
                "executed": executados,
                "passed": aprovados
            }
        )

    def registrar_reparo(self, tentativa, status):
        if type(tentativa) is not int or tentativa < 1:
            raise ValueError(
                "Número da tentativa inválido."
            )

        if status not in {
            "started", "passed", "failed"
        }:
            raise ValueError(
                "Status do reparo inválido."
            )

        return self._registrar(
            "repair_attempt",
            {
                "attempt": tentativa,
                "status": status
            }
        )
    
    def registrar_chamada_llm(
        self,
        etapa,
        sucesso=True
    ):
        """
        Registra uma chamada à LLM sem armazenar
        prompts, respostas ou credenciais.
        """

        if not isinstance(etapa, str) or not etapa.strip():
            raise ValueError(
                "A etapa da chamada à LLM deve ser informada."
            )

        if not isinstance(sucesso, bool):
            raise TypeError(
                "O sucesso da chamada deve ser booleano."
            )

        self._registrar(
            "llm_call",
            {
                "stage": etapa,
                "success": sucesso
            }
        )
