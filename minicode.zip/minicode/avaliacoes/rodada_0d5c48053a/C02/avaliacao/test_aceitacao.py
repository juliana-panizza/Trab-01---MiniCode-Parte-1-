from texto import eh_palindromo

def test_palindromo_simples():
    assert eh_palindromo("arara") is True

def test_nao_palindromo():
    assert eh_palindromo("python") is False

def test_palindromo_com_espacos():
    assert eh_palindromo(
        "A base do teto desaba"
    ) is True
