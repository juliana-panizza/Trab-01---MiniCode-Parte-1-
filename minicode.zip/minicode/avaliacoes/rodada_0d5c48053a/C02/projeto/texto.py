#!/usr/bin/env python
# -*- coding: utf-8 -*-


def eh_palindromo(texto):
    # Remover espaços e converter para minúsculas
    texto = ''.join(c for c in texto if c.isalnum()).lower()
    
    # Verificar se a string é igual à sua inversa
    return texto == texto[::-1]
