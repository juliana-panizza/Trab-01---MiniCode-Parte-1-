# Specification

## Objective

Implementar uma função que verifica se uma string é palíndromo, ignorando maiúsculas e espaços.

## Requirements

- A função deve ser chamada 'eh_palindromo'
- A função deve receber um único parâmetro: 'texto' (string)
- A função deve retornar True se a string for um palíndromo e False caso contrário
- Ignorar espaços e diferenciação entre maiúsculas e minúsculas ao verificar palíndromos

## Acceptance Criteria

- eh_palindromo('') deve retornar True
- eh_palindromo(' ') deve retornar True
- eh_palindromo('A man, a plan, a canal: Panama') deve retornar True
- eh_palindromo('No lemon, no melon') deve retornar True
- eh_palindromo('Hello World') deve retornar False
