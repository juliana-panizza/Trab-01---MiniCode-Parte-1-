from texto import eh_palindromo

def test_palindromo():
    assert eh_palindromo("Osso") is True

def test_nao_palindromo():
    assert eh_palindromo("casa") is False
