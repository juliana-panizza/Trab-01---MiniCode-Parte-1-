import unittest
from calculadora import fatorial

class TestFatorial(unittest.TestCase):
    def test_fatorial_5(self):
        self.assertEqual(fatorial(5), 120)

    def test_fatorial_negativo(self):
        with self.assertRaises(ValueError) as context:
            fatorial(-1)
        self.assertEqual(str(context.exception), 'Input must be a non-negative integer.')

    def test_fatorial_0(self):
        self.assertEqual(fatorial(0), 1)

if __name__ == '__main__':
    unittest.main()