# Implementation Plan

## Summary

O objetivo é implementar uma função chamada 'fatorial' que calcula o fatorial de um número inteiro não negativo e lança um ValueError para números negativos. A função será adicionada ao arquivo 'calculadora.py'. Testes serão criados para verificar se a função atende aos critérios de aceitação.

## Steps

1. Adicionar a função 'fatorial' ao arquivo 'calculadora.py'.
   - Arquivos: calculadora.py
2. Criar testes para a função 'fatorial' no arquivo 'tests/test_fatorial.py'.
   - Arquivos: tests/test_fatorial.py
3. Executar os testes para garantir que a função 'fatorial' funcione conforme esperado.
   - Arquivos: tests/test_fatorial.py

## Tests

- Testar se fatorial(5) retorna 120.
- Testar se fatorial(-1) lança um ValueError com a mensagem 'Input must be a non-negative integer.'
- Testar se fatorial(0) retorna 1.
