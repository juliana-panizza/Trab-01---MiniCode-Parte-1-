# Specification

## Objective

Implementar uma função fatorial que calcula o fatorial de um número inteiro não negativo e lança um ValueError para números negativos.

## Requirements

- A função deve ser chamada de 'fatorial'.
- A função deve aceitar apenas um parâmetro: n (um número inteiro).
- Para valores de n não negativos, a função deve retornar o valor do fatorial de n.
- Para valores de n negativos, a função deve lançar um ValueError.

## Acceptance Criteria

- fatorial(5) deve retornar 120.
- fatorial(-1) deve lançar um ValueError com a mensagem 'Input must be a non-negative integer.'
- fatorial(0) deve retornar 1.
