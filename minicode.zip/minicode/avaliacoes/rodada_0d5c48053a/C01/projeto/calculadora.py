def fatorial(n):
    if n < 0:
        raise ValueError('Input must be a non-negative integer.')
    elif n == 0:
        return 1
    else:
        result = 1
        for i in range(1, n + 1):
            result *= i
        return result