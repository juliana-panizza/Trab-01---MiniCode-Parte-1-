import pytest
from notas import calcular_media

def test_media_tres_notas():
    assert calcular_media([8, 7, 9]) == 8.0

def test_media_uma_nota():
    assert calcular_media([10]) == 10.0

def test_media_lista_vazia():
    with pytest.raises(ValueError):
        calcular_media([])
