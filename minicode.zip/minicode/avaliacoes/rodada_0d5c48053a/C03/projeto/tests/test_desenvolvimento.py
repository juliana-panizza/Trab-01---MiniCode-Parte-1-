import pytest
from notas import calcular_media

def test_media_basica():
    assert calcular_media([8, 7, 9]) == 8.0

def test_lista_vazia():
    with pytest.raises(ValueError):
        calcular_media([])
