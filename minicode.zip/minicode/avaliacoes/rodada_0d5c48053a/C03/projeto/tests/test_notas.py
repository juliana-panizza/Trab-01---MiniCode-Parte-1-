import pytest
from notas import calcular_media

def test_lista_cheia():
    assert calcular_media([5, 7, 9]) == 7.0
    assert calcular_media([8, 10, 6, 4]) == 7.0

def test_lista_vazia():
    with pytest.raises(ValueError):
        calcular_media([])
