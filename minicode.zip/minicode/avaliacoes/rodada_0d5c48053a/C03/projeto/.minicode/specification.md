# Specification

## Objective

Implementar uma função que calcula a média de uma lista de notas

## Requirements

- A função deve ser chamada 'calcular_media'
- A função deve receber um parâmetro: 'notas', que é uma lista de números
- A função deve retornar o valor da média aritmética das notas fornecidas

## Acceptance Criteria

- Ao passar a lista [5, 7, 9] para a função calcular_media, deve retornar 7.0
- Ao passar a lista [8, 10, 6, 4] para a função calcular_media, deve retornar 7.0
- Ao passar a lista vazia [] para a função calcular_media, deve retornar None ou lançar uma exceção adequada
