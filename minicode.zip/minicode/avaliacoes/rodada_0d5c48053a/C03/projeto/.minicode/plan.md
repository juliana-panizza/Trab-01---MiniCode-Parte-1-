# Implementation Plan

## Summary

O objetivo é implementar a função 'calcular_media' que recebe uma lista de notas e retorna a média dessas notas. Serão realizados testes para garantir que a função funcione conforme os critérios de aceitação.

## Steps

1. Criar a função 'calcular_media' no arquivo 'notas.py'.
   - Arquivos: notas.py
2. Adicionar testes para a função 'calcular_media' no arquivo 'tests/test_notas.py'.
   - Arquivos: tests/test_notas.py
3. Executar os testes para verificar se a função 'calcular_media' está funcionando corretamente.
   - Arquivos: tests/test_notas.py, notas.py

## Tests

- Testar se a função calcular_media([5, 7, 9]) retorna 7.0
- Testar se a função calcular_media([8, 10, 6, 4]) retorna 7.0
- Testar se a função calcular_media([]) retorna None ou lança uma exceção adequada
