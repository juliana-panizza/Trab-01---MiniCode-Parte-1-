from saudacao import saudar

def test_compatibilidade_antiga():
    assert saudar("Ana") == "Olá, Ana!"

def test_parametro_falso():
    assert saudar("Ana", False) == "Olá, Ana!"

def test_parametro_verdadeiro():
    assert saudar("Ana", True) == "Saudações, Ana."

def test_parametro_nomeado():
    assert saudar(
        "João", formal=True
    ) == "Saudações, João."
