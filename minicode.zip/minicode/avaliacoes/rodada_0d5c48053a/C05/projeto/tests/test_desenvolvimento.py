from saudacao import saudar

def test_compativel():
    assert saudar("Bia") == "Olá, Bia!"

def test_formal():
    assert saudar("Bia", formal=True) == "Saudações, Bia."
