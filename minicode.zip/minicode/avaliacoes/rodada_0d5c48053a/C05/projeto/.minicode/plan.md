# Implementation Plan

## Summary

O objetivo é expandir a função saudar(nome) para aceitar um parâmetro opcional formal=False. A função será modificada para incluir a lógica condicional com base no valor do parâmetro formal. Testes serão adicionados para garantir a funcionalidade conforme os critérios de aceitação.

## Steps

1. Modificar a função saudar(nome) em saudacao.py para incluir o parâmetro opcional formal=False.
   - Arquivos: saudacao.py
2. Adicionar testes para verificar se a função saudar(nome) está funcionando corretamente com diferentes valores de parâmetro formal.
   - Arquivos: tests/test_desenvolvimento.py

## Tests

- Verificar se a função retorna 'Olá, [nome]!' quando chamada sem o parâmetro 'formal'.
- Verificar se a função retorna 'Olá, [nome]!' quando chamada com 'formal=False'.
- Verificar se a função retorna 'Saudações, [nome].' quando chamada com 'formal=True'.
- Verificar se a função funciona corretamente com qualquer valor fornecido para o parâmetro 'nome'.
