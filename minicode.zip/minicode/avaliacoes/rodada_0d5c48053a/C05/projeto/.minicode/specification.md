# Specification

## Objective

Ampliar a função saudar(nome) para aceitar um parâmetro opcional formal=False.

## Requirements

- A função deve aceitar um parâmetro opcional chamado 'formal' que seja False por padrão.
- Quando 'formal' for True, a função deve retornar a string 'Saudações, {nome}.', substituindo {nome} pelo valor fornecido no parâmetro 'nome'.
- Quando 'formal' for False ou o parâmetro for omitido, a função deve retornar a string 'Olá, {nome}!', substituindo {nome} pelo valor fornecido no parâmetro 'nome'.
- Manter o nome da função e a compatibilidade com chamadas antigas.

## Acceptance Criteria

- Chamar a função sem o parâmetro 'formal' deve retornar 'Olá, [nome]!'
- Chamar a função com 'formal=False' deve retornar 'Olá, [nome]!'
- Chamar a função com 'formal=True' deve retornar 'Saudações, [nome].'
- A função deve funcionar corretamente com qualquer valor fornecido para o parâmetro 'nome'.
