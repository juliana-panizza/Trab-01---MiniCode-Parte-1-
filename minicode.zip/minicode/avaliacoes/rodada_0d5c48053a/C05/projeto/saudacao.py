def saudar(nome, formal=False):
    if formal:
        return f'Saudações, {nome}.'
    else:
        return f'Olá, {nome}!'
