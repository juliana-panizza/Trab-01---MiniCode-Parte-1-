from desconto import aplicar_desconto


def test_desconto_dez_por_cento():
    assert aplicar_desconto(100, 10) == 90


def test_desconto_zero():
    assert aplicar_desconto(80, 0) == 80


def test_desconto_cinquenta_por_cento():
    assert aplicar_desconto(200, 50) == 100


def test_desconto_total():
    assert aplicar_desconto(75, 100) == 0
