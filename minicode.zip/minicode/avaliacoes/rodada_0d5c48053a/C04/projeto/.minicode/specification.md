# Specification

## Objective

Corrigir a função aplicar_desconto para calcular corretamente o desconto aplicado ao preço original.

## Requirements

- A função deve receber dois parâmetros: preco (float) e percentual (float).
- A função deve retornar o preço com o desconto aplicado.

## Acceptance Criteria

- Se aplicar_desconto(100, 10) for chamada, deve retornar 90.
- Se aplicar_desconto(50, 20) for chamada, deve retornar 40.
