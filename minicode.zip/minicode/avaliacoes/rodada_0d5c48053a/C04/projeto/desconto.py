def aplicar_desconto(preco, percentual):
    return preco - percentual
