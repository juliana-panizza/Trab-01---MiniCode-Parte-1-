from desconto import aplicar_desconto

def test_percentual():
    assert aplicar_desconto(80, 25) == 60
