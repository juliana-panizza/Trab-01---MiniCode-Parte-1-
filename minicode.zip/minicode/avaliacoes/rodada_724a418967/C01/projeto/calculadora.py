def fatorial(n):
    if n < 0:
        raise ValueError('Entrada inválida: o número deve ser não negativo')
    elif n == 0:
        return 1
    else:
        fat = 1
        for i in range(1, n + 1):
            fat *= i
        return fat