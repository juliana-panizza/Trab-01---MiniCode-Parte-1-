#!/usr/bin/env python
# Arquivo inicial para implementação.
def eh_palindromo(texto):
    # Removendo espaços e convertendo para minúsculas
    texto = ''.join(e for e in texto if e.isalnum()).lower()
    # Verificando se a string é igual à sua inversa
    return texto == texto[::-1]

# Adicionando testes para a função eh_palindromo
import unittest

class TestEhPalindromo(unittest.TestCase):
    def test_eh_palindromo(self):
        self.assertTrue(eh_palindromo(''))
        self.assertTrue(eh_palindromo(' '))
        self.assertTrue(eh_palindromo('A man, a plan, a canal: Panama'))
        self.assertTrue(eh_palindromo('No lemon, no melon'))
        self.assertFalse(eh_palindromo('Hello World'))

if __name__ == '__main__':
    unittest.main()