# Implementation Plan

## Summary

Implementar a função fatorial(n) no arquivo calculadora.py conforme especificações e requisitos. Incluir testes para garantir que a função atenda aos critérios de aceitação.

## Steps

1. Implementar a função fatorial(n) no arquivo calculadora.py.
   - Arquivos: calculadora.py
2. Adicionar testes para verificar se a função fatorial(n) está funcionando corretamente.
   - Arquivos: calculadora.py

## Tests

- Verificar se fatorial(0) retorna 1
- Verificar se fatorial(5) retorna 120
- Verificar se a função lança uma exceção ou retorna None para valores negativos de entrada
