#!/usr/bin/env python
# Arquivo para implementação da função fatorial

def fatorial(n):
    if n < 0:
        return None
    elif n == 0:
        return 1
    else:
        fat = 1
        for i in range(1, n + 1):
            fat *= i
        return fat
