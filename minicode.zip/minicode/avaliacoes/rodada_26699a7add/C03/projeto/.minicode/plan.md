# Implementation Plan

## Summary

O objetivo é implementar a função 'calcular_media' que recebe uma lista de notas e retorna a média dessas notas. Serão realizados testes para garantir que a função funcione conforme os critérios de aceitação.

## Steps

1. Implementar a função 'calcular_media' na pasta 'notas.py'.
   - Arquivos: notas.py
2. Adicionar testes para verificar se a função 'calcular_media' está funcionando corretamente.
   - Arquivos: notas_test.py

## Tests

- Testar se a função calcular_media([5, 7, 9]) retorna 7.0
- Testar se a função calcular_media([8, 10, 6, 4]) retorna 7.0
- Testar se a função calcular_media([]) retorna None ou lança uma exceção adequada
