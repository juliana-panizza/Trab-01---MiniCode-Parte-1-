def calcular_media(notas):
    if not notas:
        return None
    return sum(notas) / len(notas)