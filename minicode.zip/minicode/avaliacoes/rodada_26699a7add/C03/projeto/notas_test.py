import unittest
from notas import calcular_media

class TestCalcularMedia(unittest.TestCase):
    def test_media_notas(self):
        self.assertEqual(calcular_media([5, 7, 9]), 7.0)
        self.assertEqual(calcular_media([8, 10, 6, 4]), 7.0)
        self.assertIsNone(calcular_media([]))

if __name__ == '__main__':
    unittest.main()