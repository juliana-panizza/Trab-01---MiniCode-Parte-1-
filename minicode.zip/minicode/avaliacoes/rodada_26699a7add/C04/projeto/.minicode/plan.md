# Implementation Plan

## Summary

O objetivo é corrigir a função aplicar_desconto em desconto.py para garantir que ela calcule corretamente o desconto aplicado ao preço original. A função deve receber dois parâmetros: preco (float) e percentual (float), e retornar o preço com o desconto aplicado. Os critérios de aceitação incluem casos de teste específicos.

## Steps

1. Verificar a implementação atual da função aplicar_desconto em desconto.py.
   - Arquivos: desconto.py
2. Corrigir a função aplicar_desconto se necessário, garantindo que ela receba dois parâmetros e retorne o preço com o desconto aplicado.
   - Arquivos: desconto.py
3. Executar os testes de aceitação para verificar se a função está funcionando corretamente.
   - Arquivos: desconto.py

## Tests

- assert aplicar_desconto(100, 10) == 90
- assert aplicar_desconto(50, 20) == 40
