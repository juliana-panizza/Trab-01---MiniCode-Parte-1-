# Implementation Plan

## Summary

O objetivo é modificar a função saudar(nome) para aceitar um parâmetro opcional formal=False. A função será alterada para retornar mensagens diferentes dependendo do valor do parâmetro formal.

## Steps

1. Modificar a função saudar(nome) para incluir o parâmetro opcional formal=False.
   - Arquivos: saudacao.py
2. Executar testes para verificar se a função atende aos critérios de aceitação.
   - Arquivos: saudacao.py

## Tests

- Chamar a função saudar('João') deve retornar 'Olá, João!'.
- Chamar a função saudar('Maria', formal=False) deve retornar 'Olá, Maria!'.
- Chamar a função saudar('Carlos', formal=True) deve retornar 'Saudações, Carlos.'.
- Chamar a função saudar('Ana') deve retornar 'Olá, Ana!'.
