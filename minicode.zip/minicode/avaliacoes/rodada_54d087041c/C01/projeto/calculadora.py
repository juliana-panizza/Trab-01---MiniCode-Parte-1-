# Arquivo inicial para implementação.


def fatorial(n):
    if not isinstance(n, int) or n < 0:
        raise ValueError('Entrada inválida: o valor deve ser um número inteiro não negativo.')
    elif n == 0:
        return 1
    else:
        result = 1
        for i in range(1, n + 1):
            result *= i
        return result