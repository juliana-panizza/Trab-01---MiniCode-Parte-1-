import pytest
from calculadora import fatorial

def test_fatorial_basico():
    assert fatorial(4) == 24

def test_negativo_deve_gerar_erro():
    assert fatorial(-2) is None

def test_fatorial_zero():
    assert fatorial(0) == 1

def test_fatorial_cinco():
    assert fatorial(5) == 120
