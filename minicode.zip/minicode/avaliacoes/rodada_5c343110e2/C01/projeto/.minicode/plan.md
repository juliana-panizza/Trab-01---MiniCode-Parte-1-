# Implementation Plan

## Summary

Implementar a função fatorial(n) no arquivo calculadora.py conforme especificações e incluir testes para validação.

## Steps

1. Adicionar a função fatorial(n) ao arquivo calculadora.py.
   - Arquivos: calculadora.py
2. Incluir testes para a função fatorial(n) no arquivo tests/test_desenvolvimento.py.
   - Arquivos: tests/test_desenvolvimento.py
3. Executar os testes para validar a implementação da função fatorial(n).
   - Arquivos: tests/test_desenvolvimento.py

## Tests

- def test_fatorial_zero(): assert fatorial(0) == 1
- def test_fatorial_cinco(): assert fatorial(5) == 120
- def test_fatorial_negativo(): assert fatorial(-1) is None
