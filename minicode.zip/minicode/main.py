"""Entrada interativa do MiniCode para um projeto com testes de desenvolvimento.

O agente implementa e repara; os testes sao executados no Docker.
Para medir sucesso independente, use executar_avaliacao.py.
"""

from pathlib import Path

from agent import MiniCodeAgent
from executor_isolado import verificar_docker
from states import Estado


MAX_PASSOS = 8
MAX_REPAROS = 2


def main():
    print("=== MiniCode v1 ===")
    diretorio = input("Informe o diretorio do projeto: ").strip().strip('"')
    tarefa = input("Digite a tarefa de programacao: ").strip()

    if not diretorio or not tarefa:
        print("Informe o diretorio e a tarefa.")
        return

    projeto = Path(diretorio).expanduser()
    if not projeto.is_dir():
        print("O diretorio do projeto nao existe.")
        return

    try:
        agente = MiniCodeAgent(projeto)
        resultado = agente.preparar(tarefa)
        print(f"\nStatus: {resultado['status']}")
        print(f"Estado: {resultado['state']}")
        if resultado["status"] != "prepared":
            print("Nao foi possivel preparar a tarefa.")
            return

        print("\nEspecificacao e planejamento gerados.")
        if input("Executar implementacao e testes? (s/N): ").strip().lower() != "s":
            print("Tarefa preparada. Execucao nao iniciada.")
            return

        # Verificacao antes de qualquer implementacao: o teste sempre sera isolado.
        if not verificar_docker()["available"]:
            print("Docker indisponivel. Execucao cancelada.")
            return
        if not (projeto / "tests").is_dir():
            print("Crie testes de desenvolvimento em tests/ antes de executar o ciclo.")
            print("Sem esses testes, o MiniCode nao pode validar a tarefa.")
            return

        agente.executar_implementacao(max_passos=MAX_PASSOS)
        verificacao = agente.executar_verificacao()
        reparos = 0

        while verificacao["status"] == "REPAIRING" and reparos < MAX_REPAROS:
            reparos += 1
            print(f"\nReparo {reparos}/{MAX_REPAROS}...")
            verificacao = agente.executar_reparo(
                verificacao["verification"], max_passos=MAX_PASSOS
            )

        if agente.maquina.estado == Estado.REPAIRING:
            agente.maquina.falhar()
            agente.salvar_estado()

        estado = agente.maquina.estado.value
        print(f"\nEstado final: {estado}")
        print(f"Reparos executados: {reparos}")
        if verificacao["status"] == "REPAIRING":
            print("Os testes ainda falham. Limite de reparos atingido.")
        print(f"Registros da execucao: {projeto / '.minicode'}")
        print("Observacao: testes locais aprovados nao substituem a aceitacao independente.")

    except Exception as erro:
        # Evita imprimir textos do provedor, que podem conter detalhes sensiveis.
        print(f"Falha durante a execucao ({type(erro).__name__}).")
        print("Consulte os registros locais em .minicode para diagnostico.")


if __name__ == "__main__":
    main()
