
CENARIOS = [
    {
        "id": "C01",
        "name": "Função fatorial",
        "difficulty": "easy",
        "task": (
            "Implementar uma função fatorial(n) em "
            "calculadora.py, para inteiros não negativos."
        ),
        "target_file": "calculadora.py",
        "acceptance_criteria": [
            "fatorial(0) retorna 1",
            "fatorial(1) retorna 1",
            "fatorial(5) retorna 120",
            "Entradas negativas geram ValueError"
        ]
    },
    {
        "id": "C02",
        "name": "Verificação de palíndromos",
        "difficulty": "medium",
        "task": (
            "Implementar uma função eh_palindromo(texto) "
            "em texto.py, ignorando maiúsculas e espaços."
        ),
        "target_file": "texto.py",
        "acceptance_criteria": [
            "'arara' retorna True",
            "'python' retorna False",
            "'A base do teto desaba' retorna True"
        ]
    },
    {
        "id": "C03",
        "name": "Média de notas",
        "difficulty": "medium",
        "task": (
            "Implementar uma função calcular_media(notas) "
            "em notas.py, recebendo uma lista de números."
        ),
        "target_file": "notas.py",
        
        "acceptance_criteria": [
            "[8, 7, 9] retorna 8.0",
            "[10] retorna 10.0",
            "Lista vazia gera ValueError"
        ]
    },
    {
        "id": "C04",
        "name": "Correção de cálculo de desconto",
        "difficulty": "medium",
        "task": (
            "O arquivo desconto.py já contém a função "
            "aplicar_desconto(preco, percentual), mas "
            "o cálculo está incorreto. Corrija o bug "
            "para que o percentual seja aplicado sobre "
            "o preço original. Preserve o nome da "
            "função e os dois parâmetros existentes."
        ),
        "target_file": "desconto.py",
        "acceptance_criteria": [
            "aplicar_desconto(100, 10) retorna 90",
            "aplicar_desconto(80, 0) retorna 80",
            "aplicar_desconto(200, 50) retorna 100",
            "aplicar_desconto(75, 100) retorna 0"
        ]
    },

    
    {
        "id": "C05",
        "name": "Ampliação de API de saudação",
        "difficulty": "medium",
        "task": (
            "O arquivo saudacao.py contém a função "
            "saudar(nome). Amplie a API para aceitar "
            "um parâmetro opcional formal=False. "
            "Quando formal=True, retorne a string "
            "'Saudações, {nome}.'. Quando formal=False "
            "ou o parâmetro for omitido, preserve "
            "exatamente o comportamento original "
            "'Olá, {nome}!'. Mantenha o nome da função "
            "e a compatibilidade com chamadas antigas."
        ),
        "target_file": "saudacao.py",
        "acceptance_criteria": [
            "saudar('Ana') retorna 'Olá, Ana!'",
            "saudar('Ana', False) retorna 'Olá, Ana!'",
            "saudar('Ana', True) retorna 'Saudações, Ana.'",
            "saudar('João', formal=True) retorna 'Saudações, João.'"
        ]
    }

]



def validar_cenario(cenario):
    campos = {
        "id",
        "name",
        "difficulty",
        "task",
        "target_file",
        "acceptance_criteria"
    }

    if not isinstance(cenario, dict):
        raise ValueError("O cenário deve ser um objeto.")

    if set(cenario) != campos:
        raise ValueError(
            "Campos inválidos no cenário."
        )

    for campo in (
        "id",
        "name",
        "task",
        "target_file"
    ):
        valor = cenario[campo]

        if not isinstance(valor, str) or not valor.strip():
            raise ValueError(
                f"Campo inválido: {campo}"
            )

    if cenario["difficulty"] not in {
        "easy", "medium", "hard"
    }:
        raise ValueError(
            "Dificuldade inválida."
        )

    criterios = cenario["acceptance_criteria"]

    if (
        not isinstance(criterios, list)
        or not criterios
        or not all(
            isinstance(item, str) and item.strip()
            for item in criterios
        )
    ):
        raise ValueError(
            "Critérios de aceitação inválidos."
        )

    if not cenario["target_file"].endswith(".py"):
        raise ValueError(
            "O arquivo-alvo deve ser Python."
        )

    return True
