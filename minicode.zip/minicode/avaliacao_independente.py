"""Avaliação independente sem expor os testes ao diretório do agente."""

from pathlib import Path
from tempfile import TemporaryDirectory
import shutil

from executor_isolado import (
    executar_testes_isolados,
    preparar_arquivos_isolados,
)


def avaliar_aceitacao(diretorio_projeto, arquivo_aceitacao, timeout=30):
    """Executa os testes externos no Docker sobre uma cópia descartável.

    Nunca escreve os testes de aceitação no projeto acessível ao agente.
    Resultado destinado ao avaliador, não ao feedback de reparação.
    """
    if (
        not isinstance(timeout, int)
        or isinstance(timeout, bool)
        or not 1 <= timeout <= 120
    ):
        raise ValueError("O timeout deve ser um inteiro entre 1 e 120.")

    projeto = Path(diretorio_projeto).resolve(strict=True)
    testes = Path(arquivo_aceitacao)
    if testes.is_symlink() or not testes.is_file():
        raise ValueError("Arquivo de aceitação inválido.")
    testes = testes.resolve(strict=True)
    if projeto == testes or projeto in testes.parents:
        raise ValueError("Testes de aceitação devem ficar fora do projeto.")
    if testes.suffix != ".py" or testes.stat().st_size > 50_000:
        raise ValueError("Arquivo de aceitação inválido.")

    conteudo = testes.read_bytes()
    if len(conteudo) > 50_000:
        raise ValueError("Arquivo de aceitação excede o tamanho permitido.")

    with TemporaryDirectory(prefix="minicode_aceitacao_") as temporario:
        destino = Path(temporario) / "projeto"
        preparar_arquivos_isolados(
            projeto, destino, exigir_testes=False
        )

        # A avaliação deve usar APENAS os testes externos, não os do agente.
        pasta_testes = destino / "tests"
        if pasta_testes.exists():
            shutil.rmtree(pasta_testes)
        pasta_testes.mkdir()
        (pasta_testes / "test_aceitacao.py").write_bytes(conteudo)

        # O executor usa outra cópia controlada antes de montar no Docker.
        return executar_testes_isolados(destino, timeout=timeout)
