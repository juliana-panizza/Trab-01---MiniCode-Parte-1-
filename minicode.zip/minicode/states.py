
from enum import Enum


class Estado(Enum):
    RECEIVED = "RECEIVED"
    SPECIFIED = "SPECIFIED"
    PLANNED = "PLANNED"
    IMPLEMENTING = "IMPLEMENTING"
    VERIFYING = "VERIFYING"
    REPAIRING = "REPAIRING"
    DONE = "DONE"
    FAILED = "FAILED"


TRANSICOES = {
    Estado.RECEIVED: {
        Estado.SPECIFIED,
        Estado.FAILED
    },

    Estado.SPECIFIED: {
        Estado.PLANNED,
        Estado.FAILED
    },

    Estado.PLANNED: {
        Estado.IMPLEMENTING,
        Estado.FAILED
    },

    Estado.IMPLEMENTING: {
        Estado.VERIFYING,
        Estado.FAILED
    },

    Estado.VERIFYING: {
        Estado.DONE,
        Estado.REPAIRING,
        Estado.FAILED
    },

    Estado.REPAIRING: {
        Estado.IMPLEMENTING,
        Estado.FAILED
    },

    Estado.DONE: set(),
    Estado.FAILED: set()
}


class MaquinaEstados:

    def __init__(self, max_tentativas=3):
        if max_tentativas < 1:
            raise ValueError(
                "O número máximo de tentativas deve ser positivo."
            )

        self.estado = Estado.RECEIVED
        self.max_tentativas = max_tentativas
        self.tentativas_reparo = 0
        self.reparo_iniciado = False

        self.spec_valida = False
        self.plan_valido = False
        self.testes_executados = False
        self.testes_aprovados = False

        self.historico = [self.estado.value]

    def registrar_spec(self, spec):
        from spec import validar_spec

        if self.estado != Estado.RECEIVED:
            raise RuntimeError(
                "A SPEC só pode ser registrada no estado RECEIVED."
            )

        validar_spec(spec)
        self.spec_valida = True
        self.transicionar(Estado.SPECIFIED)

    def registrar_plan(self, plan):
        from plan import validar_plan

        if self.estado != Estado.SPECIFIED:
            raise RuntimeError(
                "O PLAN só pode ser registrado após a SPEC."
            )

        validar_plan(plan)
        self.plan_valido = True
        self.transicionar(Estado.PLANNED)

    def registrar_testes(self, executados, aprovados):

        if self.estado != Estado.VERIFYING:
            raise RuntimeError(
                "Os testes só podem ser registrados durante VERIFYING."
            )

        if not isinstance(executados, bool):
            raise ValueError("executados deve ser booleano.")

        if not isinstance(aprovados, bool):
            raise ValueError("aprovados deve ser booleano.")

        if aprovados and not executados:
            raise ValueError(
                "Não é possível aprovar testes que não foram executados."
            )

        self.testes_executados = executados
        self.testes_aprovados = aprovados

    
    def transicionar(self, novo_estado):

        # 1. Verificar se a transição é permitida
        if novo_estado not in TRANSICOES[self.estado]:
            raise RuntimeError(
                f"Transição inválida: "
                f"{self.estado.value} -> {novo_estado.value}"
            )

        # 2. Verificar a especificação
        if novo_estado == Estado.SPECIFIED:
            if not self.spec_valida:
                raise RuntimeError(
                    "Não é possível avançar sem uma SPEC válida."
                )

        # 3. Verificar o planejamento
        if novo_estado == Estado.PLANNED:
            if not self.spec_valida or not self.plan_valido:
                raise RuntimeError(
                    "Não é possível avançar sem SPEC e PLAN válidos."
                )

        # 4. Controlar a implementação
        if novo_estado == Estado.IMPLEMENTING:
            if not self.spec_valida or not self.plan_valido:
                raise RuntimeError(
                    "A implementação exige SPEC e PLAN válidos."
                )

            # Nova implementação invalida resultados anteriores
            self.testes_executados = False
            self.testes_aprovados = False

        # 5. Controlar o início de um reparo
        
        # Entrar em REPAIRING não conta como
        # uma tentativa efetivamente iniciada.
        if novo_estado == Estado.REPAIRING:
            if not self.testes_executados:
                raise RuntimeError(
                    "Não é possível reparar sem executar testes."
                )

            if self.testes_aprovados:
                raise RuntimeError(
                    "Não é necessário reparar testes aprovados."
                )



        # 6. Controlar a finalização
        if novo_estado == Estado.DONE:

            if not self.testes_executados:
                raise RuntimeError(
                    "Não é possível finalizar sem executar testes."
                )

            if not self.testes_aprovados:
                raise RuntimeError(
                    "Não é possível finalizar com testes reprovados."
                )

        if novo_estado == Estado.REPAIRING:
            self.reparo_iniciado = False

        # 7. Atualizar o estado
        self.estado = novo_estado
        self.historico.append(novo_estado.value)

    
    
    def iniciar_reparo(self):
        """
        Inicia uma única tentativa por passagem
        pelo estado REPAIRING.
        """

        if self.estado != Estado.REPAIRING:
            raise RuntimeError(
                "O reparo exige o estado REPAIRING."
            )

        if self.reparo_iniciado:
            raise RuntimeError(
                "O reparo já foi iniciado neste estado."
            )

        if self.tentativas_reparo >= self.max_tentativas:
            raise RuntimeError(
                "Limite de reparos atingido."
            )

        self.tentativas_reparo += 1
        self.reparo_iniciado = True

        return self.tentativas_reparo


    
    
    def iniciar_reparo(self):
        """
        Inicia uma única tentativa por passagem
        pelo estado REPAIRING.
        """

        if self.estado != Estado.REPAIRING:
            raise RuntimeError(
                "O reparo exige o estado REPAIRING."
            )

        if self.reparo_iniciado:
            raise RuntimeError(
                "O reparo já foi iniciado neste estado."
            )

        if self.tentativas_reparo >= self.max_tentativas:
            raise RuntimeError(
                "Limite de reparos atingido."
            )

        self.tentativas_reparo += 1
        self.reparo_iniciado = True

        return self.tentativas_reparo



    def finalizar(self):
        self.transicionar(Estado.DONE)

    def falhar(self):
        self.transicionar(Estado.FAILED)
