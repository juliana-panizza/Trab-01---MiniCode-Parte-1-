
import os
from openai import OpenAI

from contextvars import ContextVar
from contextlib import contextmanager

from logger import RegistroEventos

BASE_URL = "https://llm.liaufms.org/v1/qwen2-5-14b-instruct-awq"
MODELO = "Qwen/Qwen2.5-14B-Instruct-AWQ"


_contexto_llm = ContextVar(
    "minicode_contexto_llm",
    default=None
)


@contextmanager
def contexto_llm(diretorio, run_id, etapa):
    """
    Associa temporariamente uma execução do MiniCode
    às chamadas feitas ao modelo.
    """

    if etapa not in {
        "spec",
        "plan",
        "implementation",
        "repair"
    }:
        raise ValueError("Etapa da LLM inválida.")

    logger = RegistroEventos(
        diretorio,
        run_id=run_id
    )

    token = _contexto_llm.set({
        "logger": logger,
        "stage": etapa
    })

    try:
        yield
    finally:
        _contexto_llm.reset(token)


def registrar_resultado_llm(sucesso):
    """
    Registra uma tentativa de chamada ao Qwen
    quando existe um contexto ativo.
    """

    contexto = _contexto_llm.get()

    if contexto is None:
        return

    contexto["logger"].registrar_chamada_llm(
        etapa=contexto["stage"],
        sucesso=sucesso
    )


def criar_cliente():
    api_key = os.getenv("MINICODE_API_KEY")

    if not api_key:
        raise RuntimeError(
            "A variável de ambiente MINICODE_API_KEY não foi configurada."
        )

    return OpenAI(
        base_url=BASE_URL,
        api_key=api_key,
        timeout=60.0,
    )




def chat(mensagens, temperature=0, **kwargs):
    client = criar_cliente()

    try:
        resposta = client.chat.completions.create(
            model=MODELO,
            messages=mensagens,
            temperature=temperature,
            **kwargs
        )

        if not resposta.choices:
            raise RuntimeError(
                "A LLM não retornou nenhuma resposta."
            )

        conteudo = resposta.choices[0].message.content

        if not conteudo:
            raise RuntimeError(
                "A LLM retornou uma resposta vazia."
            )

    except Exception:
        registrar_resultado_llm(sucesso=False)
        raise

    registrar_resultado_llm(sucesso=True)

    return conteudo


