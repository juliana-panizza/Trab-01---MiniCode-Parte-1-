
import shutil
import subprocess
from pathlib import Path
import os
import stat
import tempfile
from contextlib import contextmanager
from uuid import uuid4

def verificar_docker():
    """
    Verifica se o Docker está instalado
    e se o serviço está acessível.

    Não executa código do projeto.
    Não inicia contêineres.
    """

    executavel = shutil.which("docker")

    if executavel is None:
        return {
            "available": False,
            "reason": "Docker não encontrado."
        }

    try:
        resultado = subprocess.run(
            [
                executavel,
                "info",
                "--format",
                "{{.ServerVersion}}"
            ],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )

    except (OSError, subprocess.TimeoutExpired):
        return {
            "available": False,
            "reason": "Docker não está acessível."
        }

    if resultado.returncode != 0:
        return {
            "available": False,
            "reason": "Docker não está acessível."
        }

    if not resultado.stdout.strip():
        return {
            "available": False,
            "reason": "Resposta inválida do Docker."
        }

    return {
        "available": True,
        "reason": None
    }


def construir_comando_docker(
    diretorio_projeto,
    timeout=30,
    nome_container=None
):
    """
    Constrói o comando para executar pytest
    em um contêiner com restrições.

    Não executa o comando.
    """

    if (
        not isinstance(timeout, int)
        or isinstance(timeout, bool)
        or not 1 <= timeout <= 120
    ):
        raise ValueError(
            "O timeout deve ser um inteiro entre 1 e 120."
        )

    projeto = Path(diretorio_projeto).resolve(
        strict=True
    )

    if not projeto.is_dir():
        raise ValueError(
            "O projeto deve ser um diretório."
        )

    if not (projeto / "tests").is_dir():
        raise ValueError(
            "Pasta tests não encontrada."
        )

    if nome_container is not None and (
        not isinstance(nome_container, str)
        or not nome_container.startswith("minicode-")
        or not nome_container[9:].replace("-", "").isalnum()
    ):
        raise ValueError("Nome do contêiner inválido.")

    comando = [
        "docker",
        "run",
        "--rm",
        "--network", "none",
        "--pull", "never",
        "--ipc", "none",
        "--memory", "256m",
        "--cpus", "1",
        "--pids-limit", "64",
        "--cap-drop", "ALL",
        "--security-opt", "no-new-privileges",
        "--read-only",
        "--user", "65534:65534",
        "--tmpfs", "/tmp:rw,noexec,nosuid,size=64m",
        "--ulimit", "nofile=128:128",
        "--mount",
        (
            "type=bind,"
            f"source={projeto},"
            "target=/app,"
            "readonly"
        ),
        "--workdir", "/app",
        "--env", "PYTEST_DISABLE_PLUGIN_AUTOLOAD=1",
        "--env", "PYTHONDONTWRITEBYTECODE=1",
        "--env", "PYTHONPATH=/app",
        "minicode-pytest:local",
        "python",
        "-m",
        "pytest",
        "tests",
        "-q",
        "-p",
        "no:cacheprovider",
    ]

    if nome_container is not None:
        comando[3:3] = ["--name", nome_container]

    return comando


def preparar_arquivos_isolados(
    diretorio_projeto,
    diretorio_destino,
    exigir_testes=True
):
    """
    Copia apenas arquivos Python permitidos
    para uma área temporária de avaliação.

    Não executa código do projeto.
    Não segue links simbólicos.
    """

    projeto = Path(diretorio_projeto).resolve(strict=True)
    destino = Path(diretorio_destino).resolve()

    if not projeto.is_dir():
        raise ValueError("Projeto inválido.")

    if destino.exists():
        raise FileExistsError(
            "O destino de avaliação já existe."
        )

    
    # Impede copiar para dentro do projeto original.
    if destino == projeto or projeto in destino.parents:
        raise ValueError(
            "O destino não pode ficar dentro do projeto."
        )

    # Impede usar uma pasta ancestral do projeto
    # como destino da cópia.
    if destino in projeto.parents:
        raise ValueError(
            "O destino não pode conter o projeto original."
        )

    arquivos = []
    total_bytes = 0


    
    for raiz_atual, diretorios, nomes in os.walk(
        projeto,
        followlinks=False
    ):
        raiz_atual = Path(raiz_atual)

        # Verifica links simbólicos em diretórios.
        for nome in diretorios:
            caminho = raiz_atual / nome

            if caminho.is_symlink():
                raise ValueError(
                    "Links simbólicos não são permitidos."
                )

        # Não percorre pastas ocultas nem caches.
        diretorios[:] = [
            nome
            for nome in diretorios
            if not nome.startswith(".")
            and nome != "__pycache__"
        ]

        for nome in nomes:
            caminho = raiz_atual / nome
            relativo = caminho.relative_to(projeto)

            if caminho.is_symlink():
                raise ValueError(
                    "Links simbólicos não são permitidos."
                )

            # Ignora arquivos ocultos.
            if nome.startswith("."):
                continue

            # Copia somente arquivos Python.
            if caminho.suffix != ".py":
                continue

            informacoes = caminho.stat(
                follow_symlinks=False
            )

            if not stat.S_ISREG(informacoes.st_mode):
                raise ValueError(
                    "Tipo de arquivo não permitido."
                )

            tamanho = informacoes.st_size

            if tamanho > 50_000:
                raise ValueError(
                    "Arquivo excede o tamanho permitido."
                )

            total_bytes += tamanho

            if total_bytes > 500_000:
                raise ValueError(
                    "Projeto excede o tamanho permitido."
                )

            arquivos.append((caminho, relativo))

            if len(arquivos) > 100:
                raise ValueError(
                    "Quantidade de arquivos excedida."
                )


    if exigir_testes and not any(
        len(relativo.parts) >= 2
        and relativo.parts[0] == "tests"
        for _, relativo in arquivos
    ):
        raise ValueError(
            "Nenhum teste Python encontrado."
        )

    
    destino.mkdir(parents=True)
    bytes_copiados_total = 0

    for origem, relativo in arquivos:
        arquivo_destino = destino / relativo
        arquivo_destino.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        # No Windows, esta verificação é apenas
        # uma mitigação, não isolamento completo.
        if origem.is_symlink():
            raise ValueError(
                "Links simbólicos não são permitidos."
            )

        with origem.open("rb") as entrada:
            informacoes = os.fstat(entrada.fileno())

            if not stat.S_ISREG(informacoes.st_mode):
                raise ValueError(
                    "Tipo de arquivo não permitido."
                )

            bytes_copiados_arquivo = 0
            with arquivo_destino.open("xb") as saida:
                while True:
                    bloco = entrada.read(8192)

                    if not bloco:
                        break

                    bytes_copiados_arquivo += len(bloco)
                    bytes_copiados_total += len(bloco)
                    if bytes_copiados_arquivo > 50_000:
                        raise ValueError("Arquivo excede o tamanho permitido.")
                    if bytes_copiados_total > 500_000:
                        raise ValueError("Projeto excede o tamanho permitido.")
                    saida.write(bloco)

    return destino



@contextmanager
def area_temporaria_isolada(diretorio_projeto):
    """
    Cria uma cópia temporária controlada do projeto.

    Remove automaticamente a cópia quando o bloco
    with termina, inclusive em caso de exceção.

    Não executa Docker nem código do projeto.
    """

    with tempfile.TemporaryDirectory(
        prefix="minicode_sandbox_"
    ) as diretorio_temporario:

        destino = (
            Path(diretorio_temporario) / "projeto"
        )

        preparar_arquivos_isolados(
            diretorio_projeto,
            destino
        )

        yield destino


def executar_testes_isolados(diretorio_projeto, timeout=30):
    """Executa pytest exclusivamente em Docker, nunca no Python do host.

    Falhas de infraestrutura retornam executed=False. Uma reprovação real
    do pytest retorna executed=True e passed=False.
    """
    if (
        not isinstance(timeout, int)
        or isinstance(timeout, bool)
        or not 1 <= timeout <= 120
    ):
        raise ValueError("O timeout deve ser um inteiro entre 1 e 120.")

    projeto = Path(diretorio_projeto).resolve(strict=True)
    if not (projeto / "tests").is_dir():
        return {
            "executed": False, "passed": False, "exit_code": None,
            "output": "Pasta tests não encontrada."
        }

    disponibilidade = verificar_docker()
    if not disponibilidade["available"]:
        return {
            "executed": False, "passed": False, "exit_code": None,
            "output": "Execução bloqueada: ambiente isolado indisponível."
        }

    nome = "minicode-" + uuid4().hex
    try:
        with area_temporaria_isolada(projeto) as copia:
            comando = construir_comando_docker(
                copia, timeout=timeout, nome_container=nome
            )
            try:
                resultado = subprocess.run(
                    comando,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=timeout + 10,
                    check=False,
                )
            except subprocess.TimeoutExpired:
                # O cliente Docker pode parar antes do contêiner; remover
                # pelo nome também encerra o processo do pytest isolado.
                try:
                    subprocess.run(
                        ["docker", "rm", "--force", nome],
                        capture_output=True, timeout=10, check=False
                    )
                except (OSError, subprocess.TimeoutExpired):
                    pass
                return {
                    "executed": True, "passed": False, "exit_code": None,
                    "output": "Os testes excederam o limite de tempo."
                }

            # Docker retorna 125+ em falhas da ferramenta ou da inicialização.
            # Não interpretar isso como um teste Python reprovado.
            if resultado.returncode in (125, 126, 127):
                return {
                    "executed": False, "passed": False, "exit_code": None,
                    "output": "Falha ao iniciar contêiner de testes."
                }

            saida = (resultado.stdout + "\n" + resultado.stderr)[-10000:]
            return {
                "executed": True,
                "passed": resultado.returncode == 0,
                "exit_code": resultado.returncode,
                "output": saida,
            }
    except (OSError, ValueError, FileNotFoundError):
        return {
            "executed": False, "passed": False, "exit_code": None,
            "output": "Execução bloqueada: preparação isolada indisponível."
        }
