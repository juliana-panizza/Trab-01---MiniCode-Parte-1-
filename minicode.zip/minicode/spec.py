# Arquivo responsável por gerar, validar e salvar a especificação

import json
from pathlib import Path

from llm import chat


SPEC_PROMPT = """
Você é responsável por gerar especificações de tarefas
de programação para o agente MiniCode.

Transforme a solicitação do usuário em uma especificação
clara e verificável.

Retorne exclusivamente um objeto JSON contendo:

{
    "objective": "objetivo da tarefa",
    "requirements": [
        "requisito 1",
        "requisito 2"
    ],
    "acceptance_criteria": [
        "critério verificável 1",
        "critério verificável 2"
    ]
}

Regras:
- Não implemente código.
- Não produza um plano de implementação.
- Não invente funcionalidades não solicitadas.
- Inclua critérios de aceitação objetivos e testáveis.
- Responda em português.
"""

# Verifica se a especificação possui a estrutura obrigatória
def validar_spec(spec):
    if not isinstance(spec, dict):
        raise ValueError("A especificação deve ser um objeto JSON.")

    campos = [
        "objective",
        "requirements",
        "acceptance_criteria"
    ]

    for campo in campos:
        if campo not in spec:
            raise ValueError(f"Campo obrigatório ausente: {campo}")

    if not isinstance(spec["objective"], str):
        raise ValueError("O objetivo deve ser uma string.")

    if not spec["objective"].strip():
        raise ValueError("O objetivo não pode estar vazio.")

    for campo in ["requirements", "acceptance_criteria"]:
        valores = spec[campo]

        if not isinstance(valores, list) or not valores:
            raise ValueError(
                f"O campo {campo} deve ser uma lista não vazia."
            )

        if not all(
            isinstance(valor, str) and valor.strip()
            for valor in valores
        ):
            raise ValueError(
                f"O campo {campo} deve conter textos não vazios."
            )

    return True

# Envia a solicitação ao Qwen e converte a resposta em JSON
def gerar_spec(tarefa):
    if not isinstance(tarefa, str) or not tarefa.strip():
        raise ValueError("A tarefa não pode estar vazia.")

    mensagens = [
        {"role": "system", "content": SPEC_PROMPT},
        {"role": "user", "content": tarefa}
    ]

    resposta = chat(
        mensagens,
        response_format={"type": "json_object"}
    )

    try:
        spec = json.loads(resposta)
    except json.JSONDecodeError as erro:
        raise ValueError(
            "A LLM não retornou um JSON válido."
        ) from erro

    validar_spec(spec)

    return spec

# Transforma a especificação em Markdown e salva no projeto
def salvar_spec(spec, diretorio_projeto):
    validar_spec(spec)

    pasta = Path(diretorio_projeto) / ".minicode"
    pasta.mkdir(parents=True, exist_ok=True)

    caminho = pasta / "specification.md"

    requisitos = "\n".join(
        f"- {requisito}"
        for requisito in spec["requirements"]
    )

    criterios = "\n".join(
        f"- {criterio}"
        for criterio in spec["acceptance_criteria"]
    )

    conteudo = (
        "# Specification\n\n"
        f"## Objective\n\n{spec['objective']}\n\n"
        f"## Requirements\n\n{requisitos}\n\n"
        f"## Acceptance Criteria\n\n{criterios}\n"
    )

    caminho.write_text(conteudo, encoding="utf-8")

    return caminho