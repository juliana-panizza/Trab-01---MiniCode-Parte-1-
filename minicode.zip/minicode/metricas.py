
import json
from pathlib import Path



def calcular_metricas(diretorio_projeto, run_id=None):
    """
    Calcula métricas a partir de .minicode/events.jsonl.

    Não executa código e não consulta a LLM.

    Uma iteração corresponde a um ciclo que
    chegou à etapa de verificação.
    """

    raiz = Path(diretorio_projeto).resolve()
    arquivo = raiz / ".minicode" / "events.jsonl"

    metricas = {
        "total_events": 0,
        "tool_calls": 0,
        "tool_successes": 0,
        "tool_failures": 0,
        "tool_usage": {
            "list_files": 0,
            "read_file": 0,
            "write_file": 0,
            "run_tests": 0
        },
        "verifications": 0,
        "passed_verifications": 0,
        "failed_verifications": 0,
        "repairs_started": 0,
        "llm_calls": 0,
        "successful_llm_calls": 0,
        "failed_llm_calls": 0,
        "iterations": 0,
        "final_state": None,
        "task_success": False
    }

    if not arquivo.exists():
        return metricas

    if arquivo.is_symlink():
        raise ValueError(
            "Arquivo de eventos não pode ser um link simbólico."
        )

    for numero_linha, linha in enumerate(
        arquivo.read_text(encoding="utf-8").splitlines(),
        start=1
    ):
        if not linha.strip():
            continue

        try:
            evento = json.loads(linha)
        except json.JSONDecodeError as erro:
            raise ValueError(
                f"JSON inválido na linha {numero_linha}."
            ) from erro

        if not isinstance(evento, dict):
            raise ValueError(
                f"Evento inválido na linha {numero_linha}."
            )

        if run_id is not None:
            if evento.get("run_id") != run_id:
                continue

        tipo = evento.get("type")
        dados = evento.get("data")

        if not isinstance(dados, dict):
            raise ValueError(
                f"Dados inválidos na linha {numero_linha}."
            )

        metricas["total_events"] += 1

        if tipo == "tool_execution":
            ferramenta = dados.get("tool")
            sucesso = dados.get("success")

            if (
                ferramenta not in metricas["tool_usage"]
                or type(sucesso) is not bool
            ):
                raise ValueError(
                    f"Ferramenta inválida na linha {numero_linha}."
                )

            metricas["tool_calls"] += 1
            metricas["tool_usage"][ferramenta] += 1

            if sucesso:
                metricas["tool_successes"] += 1
            else:
                metricas["tool_failures"] += 1

        elif tipo == "verification":
            executados = dados.get("executed")
            aprovados = dados.get("passed")

            if (
                type(executados) is not bool
                or type(aprovados) is not bool
                or (aprovados and not executados)
            ):
                raise ValueError(
                    f"Verificação inválida na linha {numero_linha}."
                )

            metricas["verifications"] += 1

            if executados and aprovados:
                metricas["passed_verifications"] += 1
            else:
                metricas["failed_verifications"] += 1

        elif tipo == "repair_attempt":
            if dados.get("status") == "started":
                metricas["repairs_started"] += 1

        elif tipo == "llm_call":
            sucesso = dados.get("success")
            etapa = dados.get("stage")

            if (
                type(sucesso) is not bool
                or etapa not in {
                    "spec",
                    "plan",
                    "implementation",
                    "repair"
                }
            ):
                raise ValueError(
                    f"Chamada à LLM inválida "
                    f"na linha {numero_linha}."
                )

            metricas["llm_calls"] += 1

            if sucesso:
                metricas["successful_llm_calls"] += 1
            else:
                metricas["failed_llm_calls"] += 1

        elif tipo == "state_transition":
            estado = dados.get("state")

            if estado not in {
                "RECEIVED",
                "SPECIFIED",
                "PLANNED",
                "IMPLEMENTING",
                "VERIFYING",
                "REPAIRING",
                "DONE",
                "FAILED"
            }:
                raise ValueError(
                    f"Estado inválido na linha {numero_linha}."
                )

            metricas["final_state"] = estado

    # Nossa convenção atual:
    # uma iteração = um ciclo com verificação.
    metricas["iterations"] = metricas["verifications"]

    metricas["task_success"] = (
        metricas["final_state"] == "DONE"
    )

    return metricas

