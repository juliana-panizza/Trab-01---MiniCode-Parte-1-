# Specification

## Objective

Implementar uma função fatorial(n) que retorna o fatorial de um número inteiro não negativo.

## Requirements

- A função deve ser definida no arquivo calculadora.py.
- A função deve receber um único parâmetro, n, que é um número inteiro não negativo.
- A função deve retornar o valor do fatorial de n.

## Acceptance Criteria

- fatorial(0) deve retornar 1
- fatorial(5) deve retornar 120
- A função deve lançar uma exceção ou retornar None para valores negativos de n.
