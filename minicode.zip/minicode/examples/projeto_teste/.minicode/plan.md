# Implementation Plan

## Summary

Implementar a função fatorial(n) no arquivo calculadora.py conforme especificações e garantir que ela passe nos testes de aceitação.

## Steps

1. Adicionar a implementação da função fatorial(n) ao arquivo calculadora.py.
   - Arquivos: calculadora.py
2. Executar os testes de aceitação para verificar se a função fatorial(n) está funcionando corretamente.
   - Arquivos: test_calculadora.py

## Tests

- Verificar se fatorial(0) retorna 1
- Verificar se fatorial(5) retorna 120
- Verificar se a função lança uma exceção ou retorna None para valores negativos de n
