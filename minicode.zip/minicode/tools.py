
from pathlib import Path
import os
import subprocess
import sys
from executor_isolado import executar_testes_isolados


class FerramentasProjeto:

    def __init__(self, diretorio_projeto):
        self.raiz = Path(diretorio_projeto).resolve()

        if not self.raiz.is_dir():
            raise ValueError(
                "O diretório do projeto não existe."
            )

    
    def validar_caminho(self, caminho):
        """
        Valida caminhos antes de permitir acesso a arquivos.
        """

        if not isinstance(caminho, str) or not caminho.strip():
            raise ValueError("Caminho inválido.")

        caminho_relativo = Path(caminho)

        # Bloqueia caminhos absolutos e navegação com ..
        if caminho_relativo.is_absolute() or ".." in caminho_relativo.parts:
            raise PermissionError(
                "Acesso negado: caminho não permitido."
            )

        pastas_proibidas = {
            ".git",
            ".venv",
            ".minicode",
            "__pycache__",
            ".pytest_cache",
        }

        arquivos_proibidos = {
            ".env",
            ".env.local",
            ".env.production",
            ".env.development",
            "id_rsa",
            "id_ed25519",
        }

        extensoes_proibidas = {
            ".pem",
            ".key",
            ".p12",
            ".pfx",
        }

        # Bloqueia diretórios e arquivos sensíveis
        if any(
            parte in pastas_proibidas
            for parte in caminho_relativo.parts
        ):
            raise PermissionError(
                "Acesso negado: diretório protegido."
            )

        if (
            caminho_relativo.name in arquivos_proibidos
            or caminho_relativo.name.startswith(".env.")
            or caminho_relativo.suffix.lower() in extensoes_proibidas
        ):
            raise PermissionError(
                "Acesso negado: arquivo sensível."
            )

        destino = self.raiz / caminho_relativo

        # Bloqueia links simbólicos, inclusive nos diretórios pais
        atual = self.raiz

        for parte in caminho_relativo.parts:
            atual = atual / parte

            if atual.is_symlink():
                raise PermissionError(
                    "Acesso negado: link simbólico."
                )

        destino = destino.resolve()

        # Garante que o caminho permaneça dentro do projeto
        if not destino.is_relative_to(self.raiz):
            raise PermissionError(
                "Acesso negado: arquivo fora do projeto."
            )

        return destino


    def list_files(self):
        """
        Lista os arquivos permitidos do projeto.
        """

        arquivos = []

        for caminho in self.raiz.rglob("*"):
            if not caminho.is_file():
                continue

            try:
                relativo = caminho.relative_to(
                    self.raiz
                ).as_posix()

                self.validar_caminho(relativo)
                arquivos.append(relativo)

            except (PermissionError, ValueError):
                continue

        return sorted(arquivos)

    def read_file(self, caminho):
        """
        Lê um arquivo dentro do projeto.
        """

        destino = self.validar_caminho(caminho)

        if not destino.is_file():
            raise FileNotFoundError(
                f"Arquivo não encontrado: {caminho}"
            )

        return destino.read_text(encoding="utf-8")

    def write_file(self, caminho, conteudo):
        """
        Cria ou modifica um arquivo dentro do projeto.
        """

        destino = self.validar_caminho(caminho)

        if not isinstance(conteudo, str):
            raise ValueError(
                "O conteúdo deve ser uma string."
            )

        destino.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        destino.write_text(
            conteudo,
            encoding="utf-8"
        )

        return {
            "success": True,
            "file": caminho
        }
    
    
    
    def run_tests(self, timeout=30):
        """
        Executa os testes exclusivamente pelo Docker.

        Se o ambiente isolado estiver indisponível,
        a execução será bloqueada.
        """
        return executar_testes_isolados(
            self.raiz,
            timeout=timeout
        )
