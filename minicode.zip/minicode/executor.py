
from pathlib import Path

from states import Estado
from tools import FerramentasProjeto

from logger import RegistroEventos

class Executor:

    def __init__(self, diretorio_projeto, maquina):
        self.ferramentas = FerramentasProjeto(
            diretorio_projeto
        )

        self.maquina = maquina

    
    
    def executar_acao(self, acao):
        """
        Executa uma ação e registra seu resultado.

        Para read_file e write_file, registra apenas
        o caminho relativo, nunca o conteúdo.
        """

        nome = None
        caminho = None

        if isinstance(acao, dict):
            nome = acao.get("action")

            if nome in {"read_file", "write_file"}:
                argumentos = acao.get("arguments")

                if isinstance(argumentos, dict):
                    caminho = argumentos.get("caminho")

        ferramentas_permitidas = {
            "list_files",
            "read_file",
            "write_file"
        }

        def registrar(sucesso):
            if nome not in ferramentas_permitidas:
                return

            logger = RegistroEventos(
                self.ferramentas.raiz,
                run_id=getattr(
                    self.maquina,
                    "run_id",
                    None
                )
            )

            # O caminho é registrado somente após
            # uma operação validada com sucesso.
            caminho_log = None

            if (
                sucesso
                and nome in {"read_file", "write_file"}
                and isinstance(caminho, str)
            ):
                caminho_log = caminho

            logger.registrar_ferramenta(
                nome,
                sucesso,
                caminho=caminho_log
            )

        
        try:
            resultado = self._executar_acao_validada(acao)

        except Exception as erro:
            registrar(False)

            logger = RegistroEventos(
                self.ferramentas.raiz,
                run_id=getattr(
                    self.maquina,
                    "run_id",
                    None
                )
            )

            logger.registrar_erro(
                "implementation",
                erro
            )

            raise

        registrar(True)

        return resultado




    def _executar_acao_validada(self, acao):
        """
        Executa somente ações permitidas durante
        o estado IMPLEMENTING.
        """

        if self.maquina.estado != Estado.IMPLEMENTING:
            raise RuntimeError(
                "Ferramentas de implementação só podem "
                "ser usadas no estado IMPLEMENTING."
            )

        if not isinstance(acao, dict):
            raise ValueError("A ação deve ser um objeto.")

        if set(acao) != {"action", "arguments"}:
            raise ValueError("Estrutura da ação inválida.")

        nome = acao["action"]
        argumentos = acao["arguments"]

        if not isinstance(argumentos, dict):
            raise ValueError(
                "Os argumentos devem ser um objeto."
            )

        if nome == "list_files":
            if argumentos:
                raise ValueError(
                    "list_files não recebe argumentos."
                )

            return self.ferramentas.list_files()

        if nome == "read_file":
            if set(argumentos) != {"caminho"}:
                raise ValueError(
                    "Argumentos inválidos para read_file."
                )

            return self.ferramentas.read_file(
                argumentos["caminho"]
            )

        if nome == "write_file":
            if set(argumentos) != {
                "caminho", "conteudo"
            }:
                raise ValueError(
                    "Argumentos inválidos para write_file."
                )

            caminho = argumentos["caminho"]
            conteudo = argumentos["conteudo"]

            if not isinstance(caminho, str):
                raise ValueError(
                    "O caminho deve ser uma string."
                )

            
            tamanho = len(conteudo.encode("utf-8"))

            if tamanho > 50_000:
                raise ValueError(
                    "O conteúdo excede o limite de 50.000 bytes."
                )


            if not isinstance(conteudo, str):
                raise ValueError(
                    "O conteúdo deve ser uma string."
                )

            if Path(caminho).suffix.lower() not in {
                ".py", ".md"
            }:
                raise PermissionError(
                    "A escrita está limitada a arquivos "
                    "Python e Markdown."
                )

            return self.ferramentas.write_file(
                caminho,
                conteudo
            )

        raise ValueError(
            f"Ação não autorizada: {nome}"
        )
